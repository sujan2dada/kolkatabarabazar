
CREATE TABLE public.buyer_requirements (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  buyer_user_id UUID,
  buyer_name TEXT NOT NULL,
  buyer_phone TEXT NOT NULL,
  buyer_city TEXT,
  raw_query TEXT NOT NULL,
  normalized_product TEXT,
  quantity INTEGER,
  max_price NUMERIC,
  category_hint TEXT,
  area_hint TEXT,
  matched_shop_ids UUID[] NOT NULL DEFAULT '{}',
  status TEXT NOT NULL DEFAULT 'new',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT ON public.buyer_requirements TO authenticated;
GRANT INSERT ON public.buyer_requirements TO anon;
GRANT ALL ON public.buyer_requirements TO service_role;

ALTER TABLE public.buyer_requirements ENABLE ROW LEVEL SECURITY;

CREATE POLICY "br_public_insert" ON public.buyer_requirements
  FOR INSERT WITH CHECK (true);

CREATE POLICY "br_admin_read" ON public.buyer_requirements
  FOR SELECT USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "br_admin_update" ON public.buyer_requirements
  FOR UPDATE USING (has_role(auth.uid(), 'admin'::app_role));

CREATE INDEX idx_br_created ON public.buyer_requirements(created_at DESC);
