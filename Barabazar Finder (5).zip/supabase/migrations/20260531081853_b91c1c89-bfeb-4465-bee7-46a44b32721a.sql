
-- Enum for opportunity types
CREATE TYPE public.opportunity_type AS ENUM (
  'franchise','distributor','dealer','super_stockist','cnf_agent','wholesale_supplier','brand_partnership'
);

CREATE TYPE public.lead_status AS ENUM ('new','contacted','converted','rejected');

-- BRANDS
CREATE TABLE public.brands (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text NOT NULL UNIQUE,
  name text NOT NULL,
  logo_url text,
  category text,
  description text,
  website text,
  verified boolean NOT NULL DEFAULT false,
  featured boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT ON public.brands TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.brands TO authenticated;
GRANT ALL ON public.brands TO service_role;

ALTER TABLE public.brands ENABLE ROW LEVEL SECURITY;

CREATE POLICY brands_public_read ON public.brands FOR SELECT USING (true);
CREATE POLICY brands_admin_all ON public.brands FOR ALL
  USING (has_role(auth.uid(),'admin'::app_role))
  WITH CHECK (has_role(auth.uid(),'admin'::app_role));

CREATE TRIGGER brands_updated_at BEFORE UPDATE ON public.brands
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- OPPORTUNITIES
CREATE TABLE public.opportunities (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  brand_id uuid REFERENCES public.brands(id) ON DELETE CASCADE,
  type public.opportunity_type NOT NULL,
  title text NOT NULL,
  slug text NOT NULL UNIQUE,
  category text,
  investment_min numeric,
  investment_max numeric,
  margin_min numeric,
  margin_max numeric,
  territory text,
  area_required_sqft integer,
  experience_required text,
  description text,
  highlights text[] NOT NULL DEFAULT '{}',
  image_url text,
  approved boolean NOT NULL DEFAULT true,
  featured boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_opps_type ON public.opportunities(type);
CREATE INDEX idx_opps_category ON public.opportunities(category);

GRANT SELECT ON public.opportunities TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.opportunities TO authenticated;
GRANT ALL ON public.opportunities TO service_role;

ALTER TABLE public.opportunities ENABLE ROW LEVEL SECURITY;

CREATE POLICY opps_public_read ON public.opportunities FOR SELECT USING (approved = true OR has_role(auth.uid(),'admin'::app_role));
CREATE POLICY opps_admin_all ON public.opportunities FOR ALL
  USING (has_role(auth.uid(),'admin'::app_role))
  WITH CHECK (has_role(auth.uid(),'admin'::app_role));

CREATE TRIGGER opps_updated_at BEFORE UPDATE ON public.opportunities
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- LEADS
CREATE TABLE public.opportunity_leads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  opportunity_id uuid REFERENCES public.opportunities(id) ON DELETE SET NULL,
  brand_id uuid REFERENCES public.brands(id) ON DELETE SET NULL,
  name text NOT NULL,
  city text NOT NULL,
  phone text NOT NULL,
  email text,
  investment_capacity text,
  business_experience text,
  message text,
  status public.lead_status NOT NULL DEFAULT 'new',
  created_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.opportunity_leads TO authenticated;
GRANT INSERT ON public.opportunity_leads TO anon;
GRANT ALL ON public.opportunity_leads TO service_role;

ALTER TABLE public.opportunity_leads ENABLE ROW LEVEL SECURITY;

CREATE POLICY leads_public_insert ON public.opportunity_leads FOR INSERT WITH CHECK (true);
CREATE POLICY leads_admin_read ON public.opportunity_leads FOR SELECT USING (has_role(auth.uid(),'admin'::app_role));
CREATE POLICY leads_admin_update ON public.opportunity_leads FOR UPDATE USING (has_role(auth.uid(),'admin'::app_role));
