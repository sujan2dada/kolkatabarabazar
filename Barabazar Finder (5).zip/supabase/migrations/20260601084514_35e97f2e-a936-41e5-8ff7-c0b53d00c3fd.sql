
-- 1. Re-point shops from legacy → canonical
UPDATE public.shops SET category_id = (SELECT id FROM public.categories WHERE slug='ready-made-garments')
  WHERE category_id = (SELECT id FROM public.categories WHERE slug='clothing');
UPDATE public.shops SET category_id = (SELECT id FROM public.categories WHERE slug='fmcg-grocery')
  WHERE category_id = (SELECT id FROM public.categories WHERE slug='groceries');
UPDATE public.shops SET category_id = (SELECT id FROM public.categories WHERE slug='hardware-tools')
  WHERE category_id = (SELECT id FROM public.categories WHERE slug='hardware');
UPDATE public.shops SET category_id = (SELECT id FROM public.categories WHERE slug='stationery-office-supplies')
  WHERE category_id = (SELECT id FROM public.categories WHERE slug='stationery');

-- 2. Re-point products from legacy → canonical
UPDATE public.products SET category_id = (SELECT id FROM public.categories WHERE slug='ready-made-garments')
  WHERE category_id = (SELECT id FROM public.categories WHERE slug='clothing');
UPDATE public.products SET category_id = (SELECT id FROM public.categories WHERE slug='fmcg-grocery')
  WHERE category_id = (SELECT id FROM public.categories WHERE slug='groceries');
UPDATE public.products SET category_id = (SELECT id FROM public.categories WHERE slug='hardware-tools')
  WHERE category_id = (SELECT id FROM public.categories WHERE slug='hardware');
UPDATE public.products SET category_id = (SELECT id FROM public.categories WHERE slug='stationery-office-supplies')
  WHERE category_id = (SELECT id FROM public.categories WHERE slug='stationery');

-- 3. Delete legacy duplicate root categories
DELETE FROM public.categories WHERE slug IN ('clothing','groceries','hardware','stationery');

-- 4. Add Business Services with children
WITH ins AS (
  INSERT INTO public.categories (name, slug, parent_id) VALUES ('Business Services','business-services',NULL)
  RETURNING id
)
INSERT INTO public.categories (name, slug, parent_id)
SELECT v.name, v.slug, ins.id FROM ins, (VALUES
  ('Chartered Accountants','chartered-accountants'),
  ('GST Consultants','gst-consultants'),
  ('Company Registration','company-registration'),
  ('Insurance Services','insurance-services'),
  ('Digital Marketing','digital-marketing'),
  ('Website Development','website-development'),
  ('Import Export Consultants','import-export-consultants'),
  ('Legal Services','legal-services')
) AS v(name, slug);
