ALTER TABLE public.shops
  ADD COLUMN IF NOT EXISTS gst_verified boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS mobile_verified boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS warehouse_verified boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS top_seller boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS fast_responder boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS response_rate integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS avg_response_minutes integer,
  ADD COLUMN IF NOT EXISTS total_views integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS last_active_at timestamp with time zone NOT NULL DEFAULT now();