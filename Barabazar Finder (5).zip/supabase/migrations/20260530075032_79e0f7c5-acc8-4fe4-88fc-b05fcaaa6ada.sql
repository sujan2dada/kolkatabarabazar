
ALTER TABLE public.shops ALTER COLUMN owner_id DROP NOT NULL;
ALTER TABLE public.shops DROP CONSTRAINT shops_owner_id_fkey;
ALTER TABLE public.shops ADD CONSTRAINT shops_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES auth.users(id) ON DELETE SET NULL;
