
-- Enums
CREATE TYPE public.stock_status AS ENUM ('available','low','out');
CREATE TYPE public.report_target AS ENUM ('shop','product','shop_product');

-- shops additions
ALTER TABLE public.shops
  ADD COLUMN IF NOT EXISTS verified boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS owner_name text,
  ADD COLUMN IF NOT EXISTS years_in_business integer,
  ADD COLUMN IF NOT EXISTS photos text[] NOT NULL DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS area text;

-- shop_products additions
ALTER TABLE public.shop_products
  ADD COLUMN IF NOT EXISTS moq integer NOT NULL DEFAULT 1,
  ADD COLUMN IF NOT EXISTS stock_status public.stock_status NOT NULL DEFAULT 'available';

-- products additions
ALTER TABLE public.products
  ADD COLUMN IF NOT EXISTS synonyms text[] NOT NULL DEFAULT '{}';

-- categories subcategory support
ALTER TABLE public.categories
  ADD COLUMN IF NOT EXISTS parent_id uuid REFERENCES public.categories(id) ON DELETE SET NULL;

-- Favorites
CREATE TABLE public.favorites (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  shop_id uuid NOT NULL REFERENCES public.shops(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, shop_id)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.favorites TO authenticated;
GRANT ALL ON public.favorites TO service_role;
ALTER TABLE public.favorites ENABLE ROW LEVEL SECURITY;
CREATE POLICY favorites_select_own ON public.favorites FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY favorites_insert_own ON public.favorites FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY favorites_delete_own ON public.favorites FOR DELETE USING (auth.uid() = user_id);

-- Enquiries (buyer can be anonymous)
CREATE TABLE public.enquiries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  shop_id uuid NOT NULL REFERENCES public.shops(id) ON DELETE CASCADE,
  product_id uuid REFERENCES public.products(id) ON DELETE SET NULL,
  buyer_user_id uuid,
  buyer_name text NOT NULL,
  buyer_phone text NOT NULL,
  quantity integer,
  budget numeric,
  message text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT ON public.enquiries TO anon, authenticated;
GRANT ALL ON public.enquiries TO service_role;
ALTER TABLE public.enquiries ENABLE ROW LEVEL SECURITY;
-- anyone can create an enquiry
CREATE POLICY enquiries_public_insert ON public.enquiries FOR INSERT WITH CHECK (true);
-- shop owners (and admins) read their leads
CREATE POLICY enquiries_owner_read ON public.enquiries FOR SELECT USING (
  EXISTS (SELECT 1 FROM public.shops s WHERE s.id = enquiries.shop_id AND (s.owner_id = auth.uid() OR public.has_role(auth.uid(),'admin')))
);

-- Reports
CREATE TABLE public.reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  target_type public.report_target NOT NULL,
  target_id uuid NOT NULL,
  reason text NOT NULL,
  reporter_user_id uuid,
  reporter_contact text,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT ON public.reports TO anon, authenticated;
GRANT ALL ON public.reports TO service_role;
ALTER TABLE public.reports ENABLE ROW LEVEL SECURITY;
CREATE POLICY reports_public_insert ON public.reports FOR INSERT WITH CHECK (true);
CREATE POLICY reports_admin_read ON public.reports FOR SELECT USING (public.has_role(auth.uid(),'admin'));

-- Trigger for shop_products updated_at already exists? Add one.
DROP TRIGGER IF EXISTS shop_products_updated_at ON public.shop_products;
CREATE TRIGGER shop_products_updated_at BEFORE UPDATE ON public.shop_products
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

DROP TRIGGER IF EXISTS shops_updated_at ON public.shops;
CREATE TRIGGER shops_updated_at BEFORE UPDATE ON public.shops
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Index for synonyms search
CREATE INDEX IF NOT EXISTS products_synonyms_gin ON public.products USING GIN (synonyms);
CREATE INDEX IF NOT EXISTS shops_area_idx ON public.shops (area);
