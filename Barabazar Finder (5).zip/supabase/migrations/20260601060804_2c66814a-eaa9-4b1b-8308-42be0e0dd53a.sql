
DO $$ BEGIN
  CREATE TYPE public.enquiry_status AS ENUM ('new','contacted','quoted','won','lost');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

ALTER TABLE public.enquiries
  ADD COLUMN IF NOT EXISTS status public.enquiry_status NOT NULL DEFAULT 'new',
  ADD COLUMN IF NOT EXISTS seller_notes text,
  ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();

DROP POLICY IF EXISTS enquiries_owner_update ON public.enquiries;
CREATE POLICY enquiries_owner_update ON public.enquiries
  FOR UPDATE USING (
    EXISTS (SELECT 1 FROM public.shops s
      WHERE s.id = enquiries.shop_id
        AND (s.owner_id = auth.uid() OR public.has_role(auth.uid(),'admin')))
  );

CREATE INDEX IF NOT EXISTS enquiries_shop_id_idx ON public.enquiries(shop_id);
CREATE INDEX IF NOT EXISTS enquiries_created_at_idx ON public.enquiries(created_at DESC);
