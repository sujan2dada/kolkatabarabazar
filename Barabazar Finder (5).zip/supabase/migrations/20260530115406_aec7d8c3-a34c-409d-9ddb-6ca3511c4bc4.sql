
-- 1. Saved searches
CREATE TABLE public.saved_searches (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  name TEXT NOT NULL,
  query TEXT,
  category_slug TEXT,
  filters JSONB NOT NULL DEFAULT '{}'::jsonb,
  alert_channels TEXT[] NOT NULL DEFAULT '{}'::text[],
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.saved_searches TO authenticated;
GRANT ALL ON public.saved_searches TO service_role;
ALTER TABLE public.saved_searches ENABLE ROW LEVEL SECURITY;
CREATE POLICY saved_searches_own_all ON public.saved_searches FOR ALL
  USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- 2. Stock alerts
CREATE TABLE public.stock_alerts (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  product_id UUID NOT NULL,
  shop_id UUID,
  alert_channels TEXT[] NOT NULL DEFAULT '{}'::text[],
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, product_id, shop_id)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.stock_alerts TO authenticated;
GRANT ALL ON public.stock_alerts TO service_role;
ALTER TABLE public.stock_alerts ENABLE ROW LEVEL SECURITY;
CREATE POLICY stock_alerts_own_all ON public.stock_alerts FOR ALL
  USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- 3. Shop reviews
CREATE TABLE public.shop_reviews (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  shop_id UUID NOT NULL,
  user_id UUID NOT NULL,
  rating SMALLINT NOT NULL CHECK (rating BETWEEN 1 AND 5),
  fast_response SMALLINT CHECK (fast_response BETWEEN 1 AND 5),
  accurate_stock SMALLINT CHECK (accurate_stock BETWEEN 1 AND 5),
  trusted_seller SMALLINT CHECK (trusted_seller BETWEEN 1 AND 5),
  comment TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (shop_id, user_id)
);
GRANT SELECT ON public.shop_reviews TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.shop_reviews TO authenticated;
GRANT ALL ON public.shop_reviews TO service_role;
ALTER TABLE public.shop_reviews ENABLE ROW LEVEL SECURITY;
CREATE POLICY shop_reviews_public_read ON public.shop_reviews FOR SELECT USING (true);
CREATE POLICY shop_reviews_insert_own ON public.shop_reviews FOR INSERT
  WITH CHECK (auth.uid() = user_id);
CREATE POLICY shop_reviews_update_own ON public.shop_reviews FOR UPDATE
  USING (auth.uid() = user_id);
CREATE POLICY shop_reviews_delete_own ON public.shop_reviews FOR DELETE
  USING (auth.uid() = user_id OR has_role(auth.uid(), 'admin'::app_role));

CREATE INDEX idx_shop_reviews_shop ON public.shop_reviews(shop_id);
CREATE INDEX idx_stock_alerts_product ON public.stock_alerts(product_id);
