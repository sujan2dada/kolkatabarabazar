-- Create public bucket for shop photos
insert into storage.buckets (id, name, public)
values ('shop-photos', 'shop-photos', true)
on conflict (id) do nothing;

-- Public read
create policy "shop_photos_public_read"
on storage.objects for select
using (bucket_id = 'shop-photos');

-- Authenticated users can upload to their own folder (userId/...)
create policy "shop_photos_auth_insert"
on storage.objects for insert
to authenticated
with check (bucket_id = 'shop-photos' and auth.uid()::text = (storage.foldername(name))[1]);

create policy "shop_photos_auth_update"
on storage.objects for update
to authenticated
using (bucket_id = 'shop-photos' and auth.uid()::text = (storage.foldername(name))[1]);

create policy "shop_photos_auth_delete"
on storage.objects for delete
to authenticated
using (bucket_id = 'shop-photos' and auth.uid()::text = (storage.foldername(name))[1]);