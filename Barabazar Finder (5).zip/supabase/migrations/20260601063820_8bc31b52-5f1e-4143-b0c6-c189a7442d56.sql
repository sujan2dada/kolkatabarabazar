-- Product wishlist
CREATE TABLE public.product_favorites (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  product_id uuid NOT NULL,
  shop_id uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, product_id, shop_id)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.product_favorites TO authenticated;
GRANT ALL ON public.product_favorites TO service_role;
ALTER TABLE public.product_favorites ENABLE ROW LEVEL SECURITY;
CREATE POLICY pf_select_own ON public.product_favorites FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY pf_insert_own ON public.product_favorites FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY pf_delete_own ON public.product_favorites FOR DELETE USING (auth.uid() = user_id);

-- Price-drop alerts
CREATE TABLE public.price_alerts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  product_id uuid NOT NULL,
  shop_id uuid,
  target_price numeric,
  alert_channels text[] NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.price_alerts TO authenticated;
GRANT ALL ON public.price_alerts TO service_role;
ALTER TABLE public.price_alerts ENABLE ROW LEVEL SECURITY;
CREATE POLICY pa_own_all ON public.price_alerts FOR ALL USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);