import { createServerFn } from "@tanstack/react-start";
import { createHash, randomInt } from "crypto";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

const hash = (code: string, userId: string) =>
  createHash("sha256").update(`${userId}:${code}`).digest("hex");

const phoneSchema = z
  .string()
  .trim()
  .regex(/^\+?[0-9]{10,15}$/, "Enter a valid phone number (10-15 digits)");

export const sendPhoneOtp = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ phone: phoneSchema, shopId: z.string().uuid().optional() }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { userId } = context;

    // Simple in-DB throttle: max 5 codes per phone per hour for this user
    const since = new Date(Date.now() - 60 * 60 * 1000).toISOString();
    const { count } = await supabaseAdmin
      .from("phone_verifications")
      .select("id", { count: "exact", head: true })
      .eq("user_id", userId)
      .eq("phone", data.phone)
      .gte("created_at", since);
    if ((count ?? 0) >= 5) {
      throw new Error("Too many codes requested. Try again in an hour.");
    }

    const code = String(randomInt(0, 1_000_000)).padStart(6, "0");
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000).toISOString();

    const { error } = await supabaseAdmin.from("phone_verifications").insert({
      user_id: userId,
      shop_id: data.shopId ?? null,
      phone: data.phone,
      code_hash: hash(code, userId),
      expires_at: expiresAt,
    });
    if (error) throw new Error(error.message);

    const digits = data.phone.replace(/[^0-9]/g, "");
    const message = encodeURIComponent(
      `Your Kolkatabarabazar verification code is ${code}. It expires in 10 minutes.`,
    );
    return {
      ok: true,
      whatsappUrl: `https://wa.me/${digits}?text=${message}`,
      expiresInSeconds: 600,
    };
  });

export const verifyPhoneOtp = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        phone: phoneSchema,
        code: z.string().trim().regex(/^[0-9]{6}$/),
        shopId: z.string().uuid().optional(),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { userId } = context;

    const { data: rows, error } = await supabaseAdmin
      .from("phone_verifications")
      .select("*")
      .eq("user_id", userId)
      .eq("phone", data.phone)
      .is("verified_at", null)
      .gt("expires_at", new Date().toISOString())
      .order("created_at", { ascending: false })
      .limit(1);
    if (error) throw new Error(error.message);
    const row = rows?.[0];
    if (!row) throw new Error("No active code. Request a new one.");
    if (row.attempts >= 5) throw new Error("Too many attempts. Request a new code.");

    const matches = row.code_hash === hash(data.code, userId);
    if (!matches) {
      await supabaseAdmin
        .from("phone_verifications")
        .update({ attempts: row.attempts + 1 })
        .eq("id", row.id);
      throw new Error("Incorrect code");
    }

    await supabaseAdmin
      .from("phone_verifications")
      .update({ verified_at: new Date().toISOString() })
      .eq("id", row.id);

    // Mark shop mobile_verified if a shop was provided and the user owns it
    if (data.shopId) {
      const { data: shop } = await supabaseAdmin
        .from("shops")
        .select("id, owner_id, phone")
        .eq("id", data.shopId)
        .maybeSingle();
      if (shop && shop.owner_id === userId) {
        await supabaseAdmin
          .from("shops")
          .update({
            mobile_verified: true,
            phone: shop.phone ?? data.phone,
            last_active_at: new Date().toISOString(),
          })
          .eq("id", data.shopId);
      }
    }

    // Also store on profile for cross-shop reuse
    await supabaseAdmin
      .from("profiles")
      .update({ phone: data.phone })
      .eq("id", userId);

    return { ok: true, verified: true };
  });
