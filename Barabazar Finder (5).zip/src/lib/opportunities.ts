import type { LucideIcon } from "lucide-react";
import { Store, Truck, Handshake, Boxes, Building2, Briefcase, Sparkles } from "lucide-react";

export type OpportunityType =
  | "franchise" | "distributor" | "dealer" | "super_stockist"
  | "cnf_agent" | "wholesale_supplier" | "brand_partnership";

export const OPP_META: Record<OpportunityType, { label: string; icon: LucideIcon; color: string }> = {
  franchise:          { label: "Franchise",          icon: Store,     color: "from-orange-500 to-pink-500" },
  distributor:        { label: "Distributor",        icon: Truck,     color: "from-sky-500 to-indigo-500" },
  dealer:             { label: "Dealer",             icon: Handshake, color: "from-emerald-500 to-teal-500" },
  super_stockist:     { label: "Super Stockist",     icon: Boxes,     color: "from-purple-500 to-fuchsia-500" },
  cnf_agent:          { label: "C&F Agent",          icon: Building2, color: "from-amber-500 to-orange-500" },
  wholesale_supplier: { label: "Wholesale Supplier", icon: Briefcase, color: "from-rose-500 to-red-500" },
  brand_partnership:  { label: "Brand Partnership",  icon: Sparkles,  color: "from-cyan-500 to-blue-500" },
};

export function formatInvestment(min?: number | null, max?: number | null): string {
  const f = (n: number) =>
    n >= 10_000_000 ? `₹${(n / 10_000_000).toFixed(n % 10_000_000 ? 1 : 0)} Cr`
    : n >= 100_000   ? `₹${(n / 100_000).toFixed(n % 100_000 ? 1 : 0)} L`
    : `₹${n.toLocaleString("en-IN")}`;
  if (min && max) return `${f(min)} – ${f(max)}`;
  if (min) return `${f(min)}+`;
  if (max) return `Up to ${f(max)}`;
  return "On request";
}
