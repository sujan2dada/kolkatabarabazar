import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

const GATEWAY_URL = "https://ai.gateway.lovable.dev/v1/chat/completions";
const MODEL = "google/gemini-3-flash-preview";

async function callAI(body: any) {
  const key = process.env.LOVABLE_API_KEY;
  if (!key) throw new Error("AI service not configured");
  const res = await fetch(GATEWAY_URL, {
    method: "POST",
    headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (res.status === 429) throw new Error("Rate limit exceeded — please try again in a moment.");
  if (res.status === 402) throw new Error("AI credits exhausted. Top up in Workspace Settings.");
  if (!res.ok) {
    const t = await res.text().catch(() => "");
    console.error("AI gateway error", res.status, t);
    throw new Error("AI service error. Please retry.");
  }
  return res.json();
}

/* =========================================================
 * AI STOCK MATCHER
 * Parse free-text intent → structured filters → supplier matches
 * ========================================================= */

const matchParseTool = {
  type: "function" as const,
  function: {
    name: "parse_buyer_intent",
    description: "Extract structured wholesale buying intent from a free-text query.",
    parameters: {
      type: "object",
      properties: {
        keywords: { type: "array", items: { type: "string" }, description: "Core product keywords / synonyms to search (English, lowercase, max 6)." },
        quantity: { type: "number", description: "Desired quantity in units. 0 if unspecified." },
        max_price: { type: "number", description: "Maximum acceptable per-unit price in INR. 0 if unspecified." },
        category_hint: { type: "string", description: "Single best matching category slug guess (e.g. 'electronics', 'apparel', 'home') or empty string." },
        normalized_product: { type: "string", description: "Short canonical product description (e.g. 'mobile back covers')." },
      },
      required: ["keywords", "quantity", "max_price", "category_hint", "normalized_product"],
      additionalProperties: false,
    },
  },
};

export const aiStockMatch = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) =>
    z.object({ query: z.string().trim().min(3).max(300) }).parse(input),
  )
  .handler(async ({ data }) => {
    // 1) AI parses intent
    const parsed = await callAI({
      model: MODEL,
      messages: [
        {
          role: "system",
          content:
            "You convert wholesale buyer requests (often in Hinglish) into structured search filters for an Indian B2B clearance marketplace. Always respond by calling the tool.",
        },
        { role: "user", content: data.query },
      ],
      tools: [matchParseTool],
      tool_choice: { type: "function", function: { name: "parse_buyer_intent" } },
    });

    const call = parsed.choices?.[0]?.message?.tool_calls?.[0];
    if (!call) throw new Error("Could not understand request. Try rephrasing.");
    const intent = JSON.parse(call.function.arguments) as {
      keywords: string[];
      quantity: number;
      max_price: number;
      category_hint: string;
      normalized_product: string;
    };

    // 2) Query supply
    const keywords = (intent.keywords ?? []).filter(Boolean).slice(0, 6);
    const orFilters = keywords
      .map((k) => `name.ilike.%${k.replace(/[%,]/g, "")}%,synonyms.cs.{${k.replace(/[},]/g, "")}}`)
      .join(",");

    let productsQ = supabaseAdmin.from("products").select("id, name, slug, image_url").limit(20);
    if (orFilters) productsQ = productsQ.or(orFilters);
    const { data: products } = await productsQ;
    const productIds = (products ?? []).map((p) => p.id);

    let offers: any[] = [];
    if (productIds.length) {
      let q = supabaseAdmin
        .from("shop_products")
        .select(
          "id, price, stock, moq, stock_status, updated_at, products(id, name, slug, image_url), shops!inner(id, name, slug, area, verified, gst_verified, mobile_verified, approved, whatsapp, phone)",
        )
        .in("product_id", productIds)
        .eq("shops.approved", true)
        .order("price", { ascending: true })
        .limit(12);
      if (intent.max_price > 0) q = q.lte("price", intent.max_price);
      const { data } = await q;
      offers = data ?? [];
    }

    // 3) Compute insights
    const prices = offers.map((o) => Number(o.price)).filter((n) => n > 0);
    const minPrice = prices.length ? Math.min(...prices) : 0;
    const maxPrice = prices.length ? Math.max(...prices) : 0;
    const avgPrice = prices.length ? prices.reduce((a, b) => a + b, 0) / prices.length : 0;

    const moqValues = offers.map((o) => Number(o.moq ?? 1)).filter((n) => n > 0);
    const suggestedMoq = moqValues.length ? Math.min(...moqValues) : 0;

    const totalAvailable = offers.reduce((sum, o) => sum + Number(o.stock ?? 0), 0);
    const qtyOk = intent.quantity > 0 ? totalAvailable >= intent.quantity : true;

    return {
      intent,
      offers: offers.slice(0, 8).map((o) => ({
        id: o.id,
        price: Number(o.price),
        stock: o.stock,
        moq: o.moq,
        stock_status: o.stock_status,
        product: o.products,
        shop: o.shops,
      })),
      insights: {
        minPrice,
        maxPrice,
        avgPrice: Math.round(avgPrice),
        suggestedMoq,
        totalAvailable,
        canFulfill: qtyOk,
        supplierCount: new Set(offers.map((o) => o.shop?.id)).size,
      },
    };
  });

/* =========================================================
 * AI PRICE INTELLIGENCE
 * Returns market price range + commentary for a product
 * ========================================================= */

const priceTool = {
  type: "function" as const,
  function: {
    name: "price_intelligence",
    description: "Return wholesale market price intelligence for a product.",
    parameters: {
      type: "object",
      properties: {
        market_min: { type: "number", description: "Typical wholesale market minimum in INR per unit." },
        market_max: { type: "number", description: "Typical wholesale market maximum in INR per unit." },
        fair_price: { type: "number", description: "A fair buy price for a serious bulk buyer in INR per unit." },
        assessment: {
          type: "string",
          enum: ["below_market", "fair", "above_market"],
          description: "How the marketplace's best price compares to typical market.",
        },
        commentary: { type: "string", description: "One short sentence (max 140 chars) explaining the price context for buyers." },
      },
      required: ["market_min", "market_max", "fair_price", "assessment", "commentary"],
      additionalProperties: false,
    },
  },
};

export const aiPriceIntel = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) =>
    z
      .object({
        productName: z.string().trim().min(2).max(200),
        category: z.string().optional(),
        bestPrice: z.number().nonnegative(),
        offerCount: z.number().int().nonnegative(),
      })
      .parse(input),
  )
  .handler(async ({ data }) => {
    const userMsg = `Product: ${data.productName}
Category: ${data.category ?? "unspecified"}
Marketplace best price on Kolkatabarabazar (INR/unit): ₹${data.bestPrice}
Number of supplier offers: ${data.offerCount}

Estimate the typical Indian wholesale / clearance market price range for this product and assess the marketplace's best price.`;

    const res = await callAI({
      model: MODEL,
      messages: [
        {
          role: "system",
          content:
            "You are a wholesale price analyst for the Indian B2B clearance market (Kolkata Burrabazar, surplus, liquidation). Be conservative and realistic. Always respond via the tool.",
        },
        { role: "user", content: userMsg },
      ],
      tools: [priceTool],
      tool_choice: { type: "function", function: { name: "price_intelligence" } },
    });

    const call = res.choices?.[0]?.message?.tool_calls?.[0];
    if (!call) throw new Error("Price intelligence unavailable.");
    return JSON.parse(call.function.arguments) as {
      market_min: number;
      market_max: number;
      fair_price: number;
      assessment: "below_market" | "fair" | "above_market";
      commentary: string;
    };
  });
