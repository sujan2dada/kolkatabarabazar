import { timeAgo } from "./format";

export type TrustShop = {
  verified?: boolean | null;
  gst_verified?: boolean | null;
  mobile_verified?: boolean | null;
  warehouse_verified?: boolean | null;
  top_seller?: boolean | null;
  fast_responder?: boolean | null;
  response_rate?: number | null;
  avg_response_minutes?: number | null;
  years_in_business?: number | null;
  photos?: string[] | null;
  description?: string | null;
  phone?: string | null;
  whatsapp?: string | null;
  address?: string | null;
  lat?: number | null;
  lng?: number | null;
  logo_url?: string | null;
  created_at?: string | null;
  last_active_at?: string | null;
};

export function trustScore(shop: TrustShop): number {
  let s = 0;
  if (shop.verified) s += 20;
  if (shop.gst_verified) s += 15;
  if (shop.mobile_verified) s += 10;
  if (shop.warehouse_verified || (shop.photos && shop.photos.length > 0)) s += 10;
  // completeness
  let comp = 0;
  if (shop.description) comp++;
  if (shop.phone) comp++;
  if (shop.whatsapp) comp++;
  if (shop.address) comp++;
  if (shop.lat != null && shop.lng != null) comp++;
  if (shop.logo_url) comp++;
  s += Math.round((comp / 6) * 15);
  // response
  const rr = shop.response_rate ?? 0;
  s += Math.round((rr / 100) * 15);
  if (shop.fast_responder) s += 5;
  // age
  if (shop.years_in_business != null) s += Math.min(10, shop.years_in_business);
  else if (shop.created_at) {
    const yrs = (Date.now() - new Date(shop.created_at).getTime()) / (365 * 86_400_000);
    s += Math.min(10, Math.floor(yrs * 2));
  }
  return Math.max(0, Math.min(100, s));
}

export function trustTier(score: number): { label: string; cls: string } {
  if (score >= 80) return { label: "Excellent", cls: "bg-emerald-500/15 text-emerald-700 border-emerald-500/30 dark:text-emerald-400" };
  if (score >= 60) return { label: "Trusted", cls: "bg-primary/15 text-primary border-primary/30" };
  if (score >= 40) return { label: "Building trust", cls: "bg-amber-500/15 text-amber-700 border-amber-500/30 dark:text-amber-400" };
  return { label: "New supplier", cls: "bg-muted text-muted-foreground border-border" };
}

export function lastActiveLabel(s: TrustShop): string {
  if (!s.last_active_at) return "Recently active";
  const mins = (Date.now() - new Date(s.last_active_at).getTime()) / 60000;
  if (mins < 60) return "Active now";
  if (mins < 24 * 60) return "Last active today";
  return `Last active ${timeAgo(s.last_active_at)}`;
}

export function responseTimeLabel(mins?: number | null): string {
  if (mins == null) return "—";
  if (mins < 60) return `~${Math.max(1, Math.round(mins))} min`;
  const h = mins / 60;
  if (h < 24) return `~${h.toFixed(1).replace(/\.0$/, "")} hr`;
  return `~${Math.round(h / 24)} d`;
}
