import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

const GATEWAY_URL = "https://ai.gateway.lovable.dev/v1/chat/completions";
const MODEL = "google/gemini-3-flash-preview";

async function callAI(body: any) {
  const key = process.env.LOVABLE_API_KEY;
  if (!key) throw new Error("AI service not configured");
  const res = await fetch(GATEWAY_URL, {
    method: "POST",
    headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (res.status === 429) throw new Error("Too many requests — please try again in a moment.");
  if (res.status === 402) throw new Error("AI credits exhausted. Top up in Workspace Settings.");
  if (!res.ok) {
    console.error("AI gateway error", res.status, await res.text().catch(() => ""));
    throw new Error("AI service error. Please retry.");
  }
  return res.json();
}

const intentTool = {
  type: "function" as const,
  function: {
    name: "parse_requirement",
    description: "Extract structured B2B buying intent from a free-text wholesale buyer requirement.",
    parameters: {
      type: "object",
      properties: {
        keywords: { type: "array", items: { type: "string" }, description: "Product keywords / synonyms, max 6, lowercase English." },
        normalized_product: { type: "string", description: "Canonical product name e.g. 'cotton kurti'." },
        quantity: { type: "number", description: "Units required. 0 if unspecified." },
        max_price: { type: "number", description: "Max per-unit price INR. 0 if unspecified." },
        category_hint: { type: "string", description: "Best guess category slug (apparel, fmcg, electronics, etc.) or ''." },
        area_hint: { type: "string", description: "Locality / area mentioned (e.g. 'Burrabazar', 'Howrah') or ''." },
      },
      required: ["keywords", "normalized_product", "quantity", "max_price", "category_hint", "area_hint"],
      additionalProperties: false,
    },
  },
};

const inputSchema = z.object({
  query: z.string().trim().min(5).max(500),
  buyerName: z.string().trim().min(2).max(80),
  buyerPhone: z.string().trim().min(7).max(20).regex(/^[0-9+\-\s]+$/, "Invalid phone"),
  buyerCity: z.string().trim().max(60).optional(),
});

export const aiMatchSuppliers = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => inputSchema.parse(input))
  .handler(async ({ data }) => {
    // 1) Parse intent
    const parsed = await callAI({
      model: MODEL,
      messages: [
        {
          role: "system",
          content:
            "You convert Indian wholesale buyer requirements (often Hinglish/Bengali-English mix) into structured filters for the Kolkatabarabazar marketplace (Burrabazar / Barabazar wholesale lanes). Always respond by calling the tool.",
        },
        { role: "user", content: data.query },
      ],
      tools: [intentTool],
      tool_choice: { type: "function", function: { name: "parse_requirement" } },
    });

    const call = parsed.choices?.[0]?.message?.tool_calls?.[0];
    if (!call) throw new Error("Could not understand requirement. Please rephrase.");
    const intent = JSON.parse(call.function.arguments) as {
      keywords: string[];
      normalized_product: string;
      quantity: number;
      max_price: number;
      category_hint: string;
      area_hint: string;
    };

    // 2) Find candidate products by keyword
    const keywords = (intent.keywords ?? []).filter(Boolean).slice(0, 6);
    const orFilters = keywords
      .map((k) => {
        const safe = k.replace(/[%,{}]/g, "");
        return `name.ilike.%${safe}%,synonyms.cs.{${safe}}`;
      })
      .join(",");

    let productIds: string[] = [];
    if (orFilters) {
      const { data: products } = await supabaseAdmin
        .from("products")
        .select("id")
        .or(orFilters)
        .limit(30);
      productIds = (products ?? []).map((p) => p.id);
    }

    // 3) Pull offers + shop info
    let offers: any[] = [];
    if (productIds.length) {
      let q = supabaseAdmin
        .from("shop_products")
        .select(
          "id, price, stock, moq, stock_status, updated_at, products(id, name, slug, image_url), shops!inner(id, name, slug, area, address, verified, gst_verified, mobile_verified, warehouse_verified, approved, whatsapp, phone, response_rate, avg_response_minutes, years_in_business, last_active_at, photos, description, logo_url, top_seller, fast_responder, created_at)",
        )
        .in("product_id", productIds)
        .eq("shops.approved", true)
        .order("price", { ascending: true })
        .limit(40);
      if (intent.max_price > 0) q = q.lte("price", intent.max_price * 1.15); // ~15% slack
      const { data: rows } = await q;
      offers = rows ?? [];
    }

    // 4) Group best offer per shop & rank
    const byShop = new Map<string, any>();
    for (const o of offers) {
      if (!o.shops?.id) continue;
      const prev = byShop.get(o.shops.id);
      if (!prev || Number(o.price) < Number(prev.price)) byShop.set(o.shops.id, o);
    }

    const area = (intent.area_hint || "").toLowerCase().trim();
    const ranked = Array.from(byShop.values())
      .map((o) => {
        const s = o.shops;
        let score = 50;
        // verification
        if (s.verified) score += 12;
        if (s.gst_verified) score += 8;
        if (s.mobile_verified) score += 5;
        if (s.warehouse_verified) score += 5;
        if (s.top_seller) score += 6;
        if (s.fast_responder) score += 4;
        // response
        score += Math.round(((s.response_rate ?? 0) / 100) * 15);
        // freshness (active in last 7 days)
        if (s.last_active_at) {
          const days = (Date.now() - new Date(s.last_active_at).getTime()) / 86_400_000;
          if (days < 1) score += 8;
          else if (days < 7) score += 4;
        }
        // tenure
        if (s.years_in_business != null) score += Math.min(8, s.years_in_business);
        // area match
        const shopArea = ((s.area || "") + " " + (s.address || "")).toLowerCase();
        if (area && shopArea.includes(area)) score += 18;
        // MOQ fit
        if (intent.quantity > 0 && o.moq && o.moq <= intent.quantity) score += 6;
        else if (intent.quantity > 0 && o.moq > intent.quantity) score -= 6;
        // price fit
        if (intent.max_price > 0) {
          if (Number(o.price) <= intent.max_price) score += 10;
          else score -= 4;
        }
        return { ...o, _score: Math.max(0, Math.min(100, score)) };
      })
      .sort((a, b) => b._score - a._score)
      .slice(0, 10);

    // 5) Save lead
    const matchedIds = ranked.map((o) => o.shops.id);
    await supabaseAdmin.from("buyer_requirements").insert({
      buyer_name: data.buyerName,
      buyer_phone: data.buyerPhone,
      buyer_city: data.buyerCity || null,
      raw_query: data.query,
      normalized_product: intent.normalized_product || null,
      quantity: intent.quantity || null,
      max_price: intent.max_price || null,
      category_hint: intent.category_hint || null,
      area_hint: intent.area_hint || null,
      matched_shop_ids: matchedIds,
    });

    return {
      intent,
      matches: ranked.map((o) => ({
        score: o._score,
        offer: {
          id: o.id,
          price: Number(o.price),
          moq: o.moq,
          stock: o.stock,
          stock_status: o.stock_status,
          updated_at: o.updated_at,
        },
        product: o.products,
        shop: o.shops,
      })),
      summary: {
        matchCount: ranked.length,
        minPrice: ranked.length ? Math.min(...ranked.map((o) => Number(o.price))) : 0,
        maxPrice: ranked.length ? Math.max(...ranked.map((o) => Number(o.price))) : 0,
      },
    };
  });
