const KEY = "bb-recent-products-v2";
const MAX = 8;

export interface RecentProduct {
  slug: string;
  name: string;
  image_url?: string | null;
  category?: string | null;
  viewedAt: number;
}

export function getRecent(): RecentProduct[] {
  if (typeof window === "undefined") return [];
  try {
    return JSON.parse(localStorage.getItem(KEY) || "[]") as RecentProduct[];
  } catch {
    return [];
  }
}

export function pushRecent(p: Omit<RecentProduct, "viewedAt">) {
  if (typeof window === "undefined") return;
  const list = getRecent().filter((x) => x.slug !== p.slug);
  list.unshift({ ...p, viewedAt: Date.now() });
  localStorage.setItem(KEY, JSON.stringify(list.slice(0, MAX)));
}
