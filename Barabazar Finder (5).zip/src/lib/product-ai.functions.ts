import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

const GATEWAY_URL = "https://ai.gateway.lovable.dev/v1/chat/completions";
const MODEL = "google/gemini-3-flash-preview";

async function callAI(body: any) {
  const key = process.env.LOVABLE_API_KEY;
  if (!key) throw new Error("AI service not configured");
  const res = await fetch(GATEWAY_URL, {
    method: "POST",
    headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (res.status === 429) throw new Error("Too many requests — please retry in a moment.");
  if (res.status === 402) throw new Error("AI credits exhausted. Top up in Workspace Settings.");
  if (!res.ok) {
    console.error("AI gateway error", res.status, await res.text().catch(() => ""));
    throw new Error("AI service error. Please retry.");
  }
  return res.json();
}

const descTool = {
  type: "function" as const,
  function: {
    name: "write_product_description",
    description: "Write an SEO-friendly wholesale product description for an Indian B2B marketplace (Kolkata Burrabazar).",
    parameters: {
      type: "object",
      properties: {
        description: {
          type: "string",
          description: "120-200 word SEO-friendly wholesale product description. Plain text, no markdown. Mention typical use, key features, bulk/wholesale context for Kolkata Burrabazar buyers. Natural keyword placement.",
        },
        keywords: {
          type: "array",
          items: { type: "string" },
          description: "5-8 short SEO keywords / synonyms (lowercase, English) buyers might search.",
        },
      },
      required: ["description", "keywords"],
      additionalProperties: false,
    },
  },
};

async function generate(name: string, category?: string | null) {
  const res = await callAI({
    model: MODEL,
    messages: [
      {
        role: "system",
        content:
          "You write concise, SEO-optimised wholesale product descriptions for kolkatabarabazar.in, a Kolkata Burrabazar B2B marketplace. Tone: clear, factual, trustworthy for bulk buyers, distributors and retailers. Always respond by calling the tool.",
      },
      {
        role: "user",
        content: `Product name: ${name}\nCategory: ${category || "unspecified"}\n\nWrite an SEO-friendly wholesale description and keywords.`,
      },
    ],
    tools: [descTool],
    tool_choice: { type: "function", function: { name: "write_product_description" } },
  });
  const call = res.choices?.[0]?.message?.tool_calls?.[0];
  if (!call) throw new Error("Could not generate description. Please retry.");
  return JSON.parse(call.function.arguments) as { description: string; keywords: string[] };
}

/** Generate description preview only (does not save). */
export const aiGenerateProductDescription = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        name: z.string().trim().min(2).max(200),
        category: z.string().trim().max(120).optional(),
      })
      .parse(input),
  )
  .handler(async ({ data }) => generate(data.name, data.category));

const priceTool = {
  type: "function" as const,
  function: {
    name: "suggest_wholesale_price",
    description: "Suggest a realistic wholesale per-unit price (INR) for a product on Kolkata Burrabazar B2B marketplace.",
    parameters: {
      type: "object",
      properties: {
        suggested_price: { type: "number", description: "Recommended typical wholesale per-unit price in INR." },
        min_price: { type: "number", description: "Lower bound of fair wholesale per-unit price in INR." },
        max_price: { type: "number", description: "Upper bound of fair wholesale per-unit price in INR." },
        suggested_moq: { type: "number", description: "Typical minimum order quantity for wholesale buyers." },
        rationale: { type: "string", description: "One short sentence (max 160 chars) explaining the price." },
      },
      required: ["suggested_price", "min_price", "max_price", "suggested_moq", "rationale"],
      additionalProperties: false,
    },
  },
};

/** Suggest a wholesale price for a product (no save). */
export const aiSuggestProductPrice = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        name: z.string().trim().min(2).max(200),
        category: z.string().trim().max(120).optional(),
        brand: z.string().trim().max(120).optional(),
      })
      .parse(input),
  )
  .handler(async ({ data }) => {
    const res = await callAI({
      model: MODEL,
      messages: [
        {
          role: "system",
          content:
            "You are a wholesale pricing analyst for the Indian B2B market (Kolkata Burrabazar). Give realistic per-unit wholesale INR prices for bulk buyers. Be conservative; reflect typical surplus/wholesale rates, not MRP. Always respond via the tool.",
        },
        {
          role: "user",
          content: `Product: ${data.name}\nCategory: ${data.category || "unspecified"}\nBrand: ${data.brand || "unspecified"}\n\nSuggest a realistic wholesale per-unit price in INR for a Burrabazar seller listing this product.`,
        },
      ],
      tools: [priceTool],
      tool_choice: { type: "function", function: { name: "suggest_wholesale_price" } },
    });
    const call = res.choices?.[0]?.message?.tool_calls?.[0];
    if (!call) throw new Error("Could not suggest price. Please retry.");
    return JSON.parse(call.function.arguments) as {
      suggested_price: number;
      min_price: number;
      max_price: number;
      suggested_moq: number;
      rationale: string;
    };
  });

/** Generate AND save to an existing catalog product (any authenticated seller). */
export const aiUpdateProductDescription = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ productId: z.string().uuid(), overwrite: z.boolean().optional() }).parse(input),
  )
  .handler(async ({ data }) => {
    const { data: prod, error } = await supabaseAdmin
      .from("products")
      .select("id, name, description, synonyms, categories(name)")
      .eq("id", data.productId)
      .maybeSingle();
    if (error || !prod) throw new Error("Product not found");
    if (prod.description && !data.overwrite) {
      return { description: prod.description, keywords: prod.synonyms ?? [], skipped: true };
    }
    const cat = (prod as any).categories?.name as string | undefined;
    const out = await generate(prod.name, cat);
    const mergedSynonyms = Array.from(
      new Set([...(prod.synonyms ?? []), ...out.keywords.map((k) => k.toLowerCase())]),
    ).slice(0, 20);
    const { error: upErr } = await supabaseAdmin
      .from("products")
      .update({ description: out.description, synonyms: mergedSynonyms })
      .eq("id", data.productId);
    if (upErr) throw new Error(upErr.message);
    return { description: out.description, keywords: mergedSynonyms, skipped: false };
  });
