export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      advertisements: {
        Row: {
          active: boolean
          advertiser_name: string | null
          created_at: string
          description: string | null
          ends_at: string | null
          id: string
          image_url: string | null
          link_url: string | null
          placement: string
          priority: number
          shop_id: string | null
          starts_at: string | null
          title: string
          updated_at: string
        }
        Insert: {
          active?: boolean
          advertiser_name?: string | null
          created_at?: string
          description?: string | null
          ends_at?: string | null
          id?: string
          image_url?: string | null
          link_url?: string | null
          placement?: string
          priority?: number
          shop_id?: string | null
          starts_at?: string | null
          title: string
          updated_at?: string
        }
        Update: {
          active?: boolean
          advertiser_name?: string | null
          created_at?: string
          description?: string | null
          ends_at?: string | null
          id?: string
          image_url?: string | null
          link_url?: string | null
          placement?: string
          priority?: number
          shop_id?: string | null
          starts_at?: string | null
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      brands: {
        Row: {
          category: string | null
          created_at: string
          description: string | null
          featured: boolean
          id: string
          logo_url: string | null
          name: string
          slug: string
          updated_at: string
          verified: boolean
          website: string | null
        }
        Insert: {
          category?: string | null
          created_at?: string
          description?: string | null
          featured?: boolean
          id?: string
          logo_url?: string | null
          name: string
          slug: string
          updated_at?: string
          verified?: boolean
          website?: string | null
        }
        Update: {
          category?: string | null
          created_at?: string
          description?: string | null
          featured?: boolean
          id?: string
          logo_url?: string | null
          name?: string
          slug?: string
          updated_at?: string
          verified?: boolean
          website?: string | null
        }
        Relationships: []
      }
      buyer_requirements: {
        Row: {
          area_hint: string | null
          buyer_city: string | null
          buyer_name: string
          buyer_phone: string
          buyer_user_id: string | null
          category_hint: string | null
          created_at: string
          id: string
          matched_shop_ids: string[]
          max_price: number | null
          normalized_product: string | null
          quantity: number | null
          raw_query: string
          status: string
        }
        Insert: {
          area_hint?: string | null
          buyer_city?: string | null
          buyer_name: string
          buyer_phone: string
          buyer_user_id?: string | null
          category_hint?: string | null
          created_at?: string
          id?: string
          matched_shop_ids?: string[]
          max_price?: number | null
          normalized_product?: string | null
          quantity?: number | null
          raw_query: string
          status?: string
        }
        Update: {
          area_hint?: string | null
          buyer_city?: string | null
          buyer_name?: string
          buyer_phone?: string
          buyer_user_id?: string | null
          category_hint?: string | null
          created_at?: string
          id?: string
          matched_shop_ids?: string[]
          max_price?: number | null
          normalized_product?: string | null
          quantity?: number | null
          raw_query?: string
          status?: string
        }
        Relationships: []
      }
      categories: {
        Row: {
          created_at: string
          icon: string | null
          id: string
          name: string
          parent_id: string | null
          slug: string
        }
        Insert: {
          created_at?: string
          icon?: string | null
          id?: string
          name: string
          parent_id?: string | null
          slug: string
        }
        Update: {
          created_at?: string
          icon?: string | null
          id?: string
          name?: string
          parent_id?: string | null
          slug?: string
        }
        Relationships: [
          {
            foreignKeyName: "categories_parent_id_fkey"
            columns: ["parent_id"]
            isOneToOne: false
            referencedRelation: "categories"
            referencedColumns: ["id"]
          },
        ]
      }
      enquiries: {
        Row: {
          budget: number | null
          buyer_name: string
          buyer_phone: string
          buyer_user_id: string | null
          created_at: string
          id: string
          message: string
          product_id: string | null
          quantity: number | null
          seller_notes: string | null
          shop_id: string
          status: Database["public"]["Enums"]["enquiry_status"]
          updated_at: string
        }
        Insert: {
          budget?: number | null
          buyer_name: string
          buyer_phone: string
          buyer_user_id?: string | null
          created_at?: string
          id?: string
          message: string
          product_id?: string | null
          quantity?: number | null
          seller_notes?: string | null
          shop_id: string
          status?: Database["public"]["Enums"]["enquiry_status"]
          updated_at?: string
        }
        Update: {
          budget?: number | null
          buyer_name?: string
          buyer_phone?: string
          buyer_user_id?: string | null
          created_at?: string
          id?: string
          message?: string
          product_id?: string | null
          quantity?: number | null
          seller_notes?: string | null
          shop_id?: string
          status?: Database["public"]["Enums"]["enquiry_status"]
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "enquiries_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "enquiries_shop_id_fkey"
            columns: ["shop_id"]
            isOneToOne: false
            referencedRelation: "shops"
            referencedColumns: ["id"]
          },
        ]
      }
      favorites: {
        Row: {
          created_at: string
          id: string
          shop_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          shop_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          shop_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "favorites_shop_id_fkey"
            columns: ["shop_id"]
            isOneToOne: false
            referencedRelation: "shops"
            referencedColumns: ["id"]
          },
        ]
      }
      feedback: {
        Row: {
          created_at: string
          email: string
          id: string
          message: string
          name: string
          subject: string | null
          user_id: string | null
        }
        Insert: {
          created_at?: string
          email: string
          id?: string
          message: string
          name: string
          subject?: string | null
          user_id?: string | null
        }
        Update: {
          created_at?: string
          email?: string
          id?: string
          message?: string
          name?: string
          subject?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      opportunities: {
        Row: {
          approved: boolean
          area_required_sqft: number | null
          brand_id: string | null
          category: string | null
          created_at: string
          description: string | null
          experience_required: string | null
          featured: boolean
          highlights: string[]
          id: string
          image_url: string | null
          investment_max: number | null
          investment_min: number | null
          margin_max: number | null
          margin_min: number | null
          slug: string
          territory: string | null
          title: string
          type: Database["public"]["Enums"]["opportunity_type"]
          updated_at: string
        }
        Insert: {
          approved?: boolean
          area_required_sqft?: number | null
          brand_id?: string | null
          category?: string | null
          created_at?: string
          description?: string | null
          experience_required?: string | null
          featured?: boolean
          highlights?: string[]
          id?: string
          image_url?: string | null
          investment_max?: number | null
          investment_min?: number | null
          margin_max?: number | null
          margin_min?: number | null
          slug: string
          territory?: string | null
          title: string
          type: Database["public"]["Enums"]["opportunity_type"]
          updated_at?: string
        }
        Update: {
          approved?: boolean
          area_required_sqft?: number | null
          brand_id?: string | null
          category?: string | null
          created_at?: string
          description?: string | null
          experience_required?: string | null
          featured?: boolean
          highlights?: string[]
          id?: string
          image_url?: string | null
          investment_max?: number | null
          investment_min?: number | null
          margin_max?: number | null
          margin_min?: number | null
          slug?: string
          territory?: string | null
          title?: string
          type?: Database["public"]["Enums"]["opportunity_type"]
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "opportunities_brand_id_fkey"
            columns: ["brand_id"]
            isOneToOne: false
            referencedRelation: "brands"
            referencedColumns: ["id"]
          },
        ]
      }
      opportunity_leads: {
        Row: {
          brand_id: string | null
          business_experience: string | null
          city: string
          created_at: string
          email: string | null
          id: string
          investment_capacity: string | null
          message: string | null
          name: string
          opportunity_id: string | null
          phone: string
          status: Database["public"]["Enums"]["lead_status"]
        }
        Insert: {
          brand_id?: string | null
          business_experience?: string | null
          city: string
          created_at?: string
          email?: string | null
          id?: string
          investment_capacity?: string | null
          message?: string | null
          name: string
          opportunity_id?: string | null
          phone: string
          status?: Database["public"]["Enums"]["lead_status"]
        }
        Update: {
          brand_id?: string | null
          business_experience?: string | null
          city?: string
          created_at?: string
          email?: string | null
          id?: string
          investment_capacity?: string | null
          message?: string | null
          name?: string
          opportunity_id?: string | null
          phone?: string
          status?: Database["public"]["Enums"]["lead_status"]
        }
        Relationships: [
          {
            foreignKeyName: "opportunity_leads_brand_id_fkey"
            columns: ["brand_id"]
            isOneToOne: false
            referencedRelation: "brands"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "opportunity_leads_opportunity_id_fkey"
            columns: ["opportunity_id"]
            isOneToOne: false
            referencedRelation: "opportunities"
            referencedColumns: ["id"]
          },
        ]
      }
      phone_verifications: {
        Row: {
          attempts: number
          code_hash: string
          created_at: string
          expires_at: string
          id: string
          phone: string
          shop_id: string | null
          user_id: string
          verified_at: string | null
        }
        Insert: {
          attempts?: number
          code_hash: string
          created_at?: string
          expires_at: string
          id?: string
          phone: string
          shop_id?: string | null
          user_id: string
          verified_at?: string | null
        }
        Update: {
          attempts?: number
          code_hash?: string
          created_at?: string
          expires_at?: string
          id?: string
          phone?: string
          shop_id?: string | null
          user_id?: string
          verified_at?: string | null
        }
        Relationships: []
      }
      price_alerts: {
        Row: {
          alert_channels: string[]
          created_at: string
          id: string
          product_id: string
          shop_id: string | null
          target_price: number | null
          user_id: string
        }
        Insert: {
          alert_channels?: string[]
          created_at?: string
          id?: string
          product_id: string
          shop_id?: string | null
          target_price?: number | null
          user_id: string
        }
        Update: {
          alert_channels?: string[]
          created_at?: string
          id?: string
          product_id?: string
          shop_id?: string | null
          target_price?: number | null
          user_id?: string
        }
        Relationships: []
      }
      product_favorites: {
        Row: {
          created_at: string
          id: string
          product_id: string
          shop_id: string | null
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          product_id: string
          shop_id?: string | null
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          product_id?: string
          shop_id?: string | null
          user_id?: string
        }
        Relationships: []
      }
      products: {
        Row: {
          approved: boolean
          category_id: string | null
          created_at: string
          description: string | null
          id: string
          image_url: string | null
          name: string
          slug: string
          synonyms: string[]
        }
        Insert: {
          approved?: boolean
          category_id?: string | null
          created_at?: string
          description?: string | null
          id?: string
          image_url?: string | null
          name: string
          slug: string
          synonyms?: string[]
        }
        Update: {
          approved?: boolean
          category_id?: string | null
          created_at?: string
          description?: string | null
          id?: string
          image_url?: string | null
          name?: string
          slug?: string
          synonyms?: string[]
        }
        Relationships: [
          {
            foreignKeyName: "products_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "categories"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          created_at: string
          full_name: string | null
          id: string
          phone: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          full_name?: string | null
          id: string
          phone?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          full_name?: string | null
          id?: string
          phone?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      reports: {
        Row: {
          created_at: string
          id: string
          reason: string
          reporter_contact: string | null
          reporter_user_id: string | null
          target_id: string
          target_type: Database["public"]["Enums"]["report_target"]
        }
        Insert: {
          created_at?: string
          id?: string
          reason: string
          reporter_contact?: string | null
          reporter_user_id?: string | null
          target_id: string
          target_type: Database["public"]["Enums"]["report_target"]
        }
        Update: {
          created_at?: string
          id?: string
          reason?: string
          reporter_contact?: string | null
          reporter_user_id?: string | null
          target_id?: string
          target_type?: Database["public"]["Enums"]["report_target"]
        }
        Relationships: []
      }
      saved_searches: {
        Row: {
          alert_channels: string[]
          category_slug: string | null
          created_at: string
          filters: Json
          id: string
          name: string
          query: string | null
          user_id: string
        }
        Insert: {
          alert_channels?: string[]
          category_slug?: string | null
          created_at?: string
          filters?: Json
          id?: string
          name: string
          query?: string | null
          user_id: string
        }
        Update: {
          alert_channels?: string[]
          category_slug?: string | null
          created_at?: string
          filters?: Json
          id?: string
          name?: string
          query?: string | null
          user_id?: string
        }
        Relationships: []
      }
      shop_products: {
        Row: {
          brand: string | null
          condition: string
          created_at: string
          dispatch_time: string | null
          id: string
          lot_size: number | null
          moq: number
          mrp: number | null
          price: number
          product_id: string
          shop_id: string
          stock: number
          stock_status: Database["public"]["Enums"]["stock_status"]
          updated_at: string
        }
        Insert: {
          brand?: string | null
          condition?: string
          created_at?: string
          dispatch_time?: string | null
          id?: string
          lot_size?: number | null
          moq?: number
          mrp?: number | null
          price: number
          product_id: string
          shop_id: string
          stock?: number
          stock_status?: Database["public"]["Enums"]["stock_status"]
          updated_at?: string
        }
        Update: {
          brand?: string | null
          condition?: string
          created_at?: string
          dispatch_time?: string | null
          id?: string
          lot_size?: number | null
          moq?: number
          mrp?: number | null
          price?: number
          product_id?: string
          shop_id?: string
          stock?: number
          stock_status?: Database["public"]["Enums"]["stock_status"]
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "shop_products_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "shop_products_shop_id_fkey"
            columns: ["shop_id"]
            isOneToOne: false
            referencedRelation: "shops"
            referencedColumns: ["id"]
          },
        ]
      }
      shop_reviews: {
        Row: {
          accurate_stock: number | null
          comment: string | null
          created_at: string
          fast_response: number | null
          id: string
          rating: number
          shop_id: string
          trusted_seller: number | null
          user_id: string
        }
        Insert: {
          accurate_stock?: number | null
          comment?: string | null
          created_at?: string
          fast_response?: number | null
          id?: string
          rating: number
          shop_id: string
          trusted_seller?: number | null
          user_id: string
        }
        Update: {
          accurate_stock?: number | null
          comment?: string | null
          created_at?: string
          fast_response?: number | null
          id?: string
          rating?: number
          shop_id?: string
          trusted_seller?: number | null
          user_id?: string
        }
        Relationships: []
      }
      shops: {
        Row: {
          address: string
          approved: boolean
          area: string | null
          avg_response_minutes: number | null
          category_id: string | null
          created_at: string
          description: string | null
          fast_responder: boolean
          gst_verified: boolean
          hours: string | null
          id: string
          last_active_at: string
          lat: number | null
          lng: number | null
          logo_url: string | null
          mobile_verified: boolean
          name: string
          owner_id: string | null
          owner_name: string | null
          phone: string | null
          photos: string[]
          response_rate: number
          slug: string
          top_seller: boolean
          total_views: number
          updated_at: string
          verified: boolean
          warehouse_verified: boolean
          whatsapp: string | null
          years_in_business: number | null
        }
        Insert: {
          address: string
          approved?: boolean
          area?: string | null
          avg_response_minutes?: number | null
          category_id?: string | null
          created_at?: string
          description?: string | null
          fast_responder?: boolean
          gst_verified?: boolean
          hours?: string | null
          id?: string
          last_active_at?: string
          lat?: number | null
          lng?: number | null
          logo_url?: string | null
          mobile_verified?: boolean
          name: string
          owner_id?: string | null
          owner_name?: string | null
          phone?: string | null
          photos?: string[]
          response_rate?: number
          slug: string
          top_seller?: boolean
          total_views?: number
          updated_at?: string
          verified?: boolean
          warehouse_verified?: boolean
          whatsapp?: string | null
          years_in_business?: number | null
        }
        Update: {
          address?: string
          approved?: boolean
          area?: string | null
          avg_response_minutes?: number | null
          category_id?: string | null
          created_at?: string
          description?: string | null
          fast_responder?: boolean
          gst_verified?: boolean
          hours?: string | null
          id?: string
          last_active_at?: string
          lat?: number | null
          lng?: number | null
          logo_url?: string | null
          mobile_verified?: boolean
          name?: string
          owner_id?: string | null
          owner_name?: string | null
          phone?: string | null
          photos?: string[]
          response_rate?: number
          slug?: string
          top_seller?: boolean
          total_views?: number
          updated_at?: string
          verified?: boolean
          warehouse_verified?: boolean
          whatsapp?: string | null
          years_in_business?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "shops_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "categories"
            referencedColumns: ["id"]
          },
        ]
      }
      stock_alerts: {
        Row: {
          alert_channels: string[]
          created_at: string
          id: string
          product_id: string
          shop_id: string | null
          user_id: string
        }
        Insert: {
          alert_channels?: string[]
          created_at?: string
          id?: string
          product_id: string
          shop_id?: string | null
          user_id: string
        }
        Update: {
          alert_channels?: string[]
          created_at?: string
          id?: string
          product_id?: string
          shop_id?: string | null
          user_id?: string
        }
        Relationships: []
      }
      subscriptions: {
        Row: {
          amount: number | null
          billing_cycle: string
          created_at: string
          currency: string
          current_period_end: string | null
          id: string
          notes: string | null
          owner_id: string
          plan: string
          shop_id: string
          started_at: string
          status: string
          updated_at: string
        }
        Insert: {
          amount?: number | null
          billing_cycle?: string
          created_at?: string
          currency?: string
          current_period_end?: string | null
          id?: string
          notes?: string | null
          owner_id: string
          plan?: string
          shop_id: string
          started_at?: string
          status?: string
          updated_at?: string
        }
        Update: {
          amount?: number | null
          billing_cycle?: string
          created_at?: string
          currency?: string
          current_period_end?: string | null
          id?: string
          notes?: string | null
          owner_id?: string
          plan?: string
          shop_id?: string
          started_at?: string
          status?: string
          updated_at?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      show_limit: { Args: never; Returns: number }
      show_trgm: { Args: { "": string }; Returns: string[] }
    }
    Enums: {
      app_role: "admin" | "owner" | "moderator"
      enquiry_status: "new" | "contacted" | "quoted" | "won" | "lost"
      lead_status: "new" | "contacted" | "converted" | "rejected"
      opportunity_type:
        | "franchise"
        | "distributor"
        | "dealer"
        | "super_stockist"
        | "cnf_agent"
        | "wholesale_supplier"
        | "brand_partnership"
      report_target: "shop" | "product" | "shop_product"
      stock_status: "available" | "low" | "out"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "owner", "moderator"],
      enquiry_status: ["new", "contacted", "quoted", "won", "lost"],
      lead_status: ["new", "contacted", "converted", "rejected"],
      opportunity_type: [
        "franchise",
        "distributor",
        "dealer",
        "super_stockist",
        "cnf_agent",
        "wholesale_supplier",
        "brand_partnership",
      ],
      report_target: ["shop", "product", "shop_product"],
      stock_status: ["available", "low", "out"],
    },
  },
} as const
