import { useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Bell, BellRing, MessageCircle, Mail } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";

const CHANNELS = [
  { id: "whatsapp", label: "WhatsApp", icon: MessageCircle },
  { id: "email", label: "Email", icon: Mail },
  { id: "push", label: "Push notifications", icon: Bell },
];

export function StockAlertButton({ productId, productName, shopId }: { productId: string; productName?: string; shopId?: string | null }) {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [channels, setChannels] = useState<string[]>(["whatsapp", "email"]);
  const [saving, setSaving] = useState(false);

  const { data: existing, refetch } = useQuery({
    queryKey: ["stock-alert", productId, shopId ?? null, user?.id ?? null],
    enabled: !!user,
    queryFn: async () => {
      let q = supabase.from("stock_alerts").select("id, alert_channels").eq("user_id", user!.id).eq("product_id", productId);
      q = shopId ? q.eq("shop_id", shopId) : q.is("shop_id", null);
      const { data } = await q.maybeSingle();
      return data;
    },
  });

  const toggle = (id: string) => setChannels((c) => (c.includes(id) ? c.filter((x) => x !== id) : [...c, id]));

  const onClick = () => {
    if (!user) {
      toast.info("Sign in to get stock alerts");
      navigate({ to: "/login" });
      return;
    }
    setChannels(existing?.alert_channels?.length ? existing.alert_channels : ["whatsapp", "email"]);
    setOpen(true);
  };

  const save = async () => {
    if (!user) return;
    setSaving(true);
    if (existing) {
      const { error } = await supabase.from("stock_alerts").update({ alert_channels: channels }).eq("id", existing.id);
      setSaving(false);
      if (error) return toast.error(error.message);
      toast.success("Alert updated");
    } else {
      const { error } = await supabase.from("stock_alerts").insert({
        user_id: user.id, product_id: productId, shop_id: shopId ?? null, alert_channels: channels,
      });
      setSaving(false);
      if (error) return toast.error(error.message);
      toast.success(`We'll notify you when ${productName ?? "this product"} is back in stock`);
    }
    refetch();
    setOpen(false);
  };

  const remove = async () => {
    if (!existing) return;
    const { error } = await supabase.from("stock_alerts").delete().eq("id", existing.id);
    if (error) return toast.error(error.message);
    toast.success("Alert removed");
    refetch();
    setOpen(false);
  };

  const subscribed = !!existing;

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button type="button" variant={subscribed ? "default" : "outline"} size="sm" onClick={onClick} className="rounded-full gap-2">
          {subscribed ? <BellRing className="h-4 w-4" /> : <Bell className="h-4 w-4" />}
          {subscribed ? "Alert on" : "Notify me on new stock"}
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Notify me when new stock arrives</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <Label>Send the alert via</Label>
          {CHANNELS.map((c) => (
            <label key={c.id} className="flex items-center gap-2 cursor-pointer text-sm">
              <Checkbox checked={channels.includes(c.id)} onCheckedChange={() => toggle(c.id)} />
              <c.icon className="h-4 w-4 text-primary" /> {c.label}
            </label>
          ))}
        </div>
        <DialogFooter className="gap-2">
          {subscribed && <Button variant="ghost" onClick={remove}>Turn off</Button>}
          <Button onClick={save} disabled={saving || channels.length === 0}>
            {saving ? "Saving…" : subscribed ? "Update" : "Notify me"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
