import { useState, type FormEvent } from "react";
import { MessageSquarePlus } from "lucide-react";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { toast } from "sonner";

const schema = z.object({
  buyer_name: z.string().trim().min(1).max(100),
  buyer_phone: z.string().trim().min(6).max(20),
  quantity: z.number().int().positive().optional(),
  budget: z.number().positive().optional(),
  message: z.string().trim().min(3).max(1000),
});

export function EnquiryDialog({
  shopId,
  productId,
  productName,
  trigger,
}: {
  shopId: string;
  productId?: string;
  productName?: string;
  trigger?: React.ReactNode;
}) {
  const { user } = useAuth();
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [v, setV] = useState({
    buyer_name: "",
    buyer_phone: "",
    quantity: "",
    budget: "",
    message: productName ? `Hi, I'm interested in ${productName}. Please share availability and best price.` : "",
  });

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    try {
      const parsed = schema.parse({
        buyer_name: v.buyer_name,
        buyer_phone: v.buyer_phone,
        quantity: v.quantity ? Number(v.quantity) : undefined,
        budget: v.budget ? Number(v.budget) : undefined,
        message: v.message,
      });
      const { error } = await supabase.from("enquiries").insert({
        shop_id: shopId,
        product_id: productId ?? null,
        buyer_user_id: user?.id ?? null,
        ...parsed,
      });
      if (error) throw error;
      toast.success("Enquiry sent");
      setOpen(false);
    } catch (err: any) {
      toast.error(err.errors?.[0]?.message ?? err.message ?? "Failed");
    } finally {
      setBusy(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger ?? (
          <Button variant="outline">
            <MessageSquarePlus className="h-4 w-4 mr-1" />Send enquiry
          </Button>
        )}
      </DialogTrigger>
      <DialogContent>
        <DialogHeader><DialogTitle>Send enquiry</DialogTitle></DialogHeader>
        <form onSubmit={submit} className="space-y-3">
          <div className="grid sm:grid-cols-2 gap-3">
            <div><Label>Your name</Label><Input value={v.buyer_name} maxLength={100} onChange={(e) => setV({ ...v, buyer_name: e.target.value })} required /></div>
            <div><Label>Phone</Label><Input value={v.buyer_phone} maxLength={20} onChange={(e) => setV({ ...v, buyer_phone: e.target.value })} required /></div>
          </div>
          <div className="grid sm:grid-cols-2 gap-3">
            <div><Label>Quantity</Label><Input type="number" min="1" value={v.quantity} onChange={(e) => setV({ ...v, quantity: e.target.value })} /></div>
            <div><Label>Budget (₹)</Label><Input type="number" min="0" step="0.01" value={v.budget} onChange={(e) => setV({ ...v, budget: e.target.value })} /></div>
          </div>
          <div><Label>Requirement</Label><Textarea rows={4} maxLength={1000} value={v.message} onChange={(e) => setV({ ...v, message: e.target.value })} required /></div>
          <Button type="submit" disabled={busy} className="w-full">{busy ? "Sending…" : "Send enquiry"}</Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
