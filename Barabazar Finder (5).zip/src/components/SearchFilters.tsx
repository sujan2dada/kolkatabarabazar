import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";

export type SortKey = "best" | "price_asc" | "price_desc" | "newest" | "trust";

export interface FilterValues {
  category?: string;
  area?: string;
  minPrice?: number;
  maxPrice?: number;
  maxMoq?: number;
  condition?: string;
  brand?: string;
  dispatchTime?: string;
  minTrustScore?: number;
  verifiedOnly?: boolean;
  inStockOnly?: boolean;
  nearMe?: boolean;
  sort?: SortKey;
}

const PRICE_CHIPS: Array<{ label: string; min?: number; max?: number }> = [
  { label: "Under ₹50", max: 50 },
  { label: "₹50–₹200", min: 50, max: 200 },
  { label: "₹200–₹1k", min: 200, max: 1000 },
  { label: "₹1k+", min: 1000 },
];

export function countActiveFilters(v: FilterValues): number {
  let n = 0;
  if (v.category) n++;
  if (v.area) n++;
  if (v.minPrice != null) n++;
  if (v.maxPrice != null) n++;
  if (v.maxMoq != null) n++;
  if (v.condition) n++;
  if (v.brand) n++;
  if (v.dispatchTime) n++;
  if (v.minTrustScore && v.minTrustScore > 0) n++;
  if (v.verifiedOnly) n++;
  if (v.inStockOnly) n++;
  if (v.nearMe) n++;
  if (v.sort && v.sort !== "best") n++;
  return n;
}

export function SearchFilters({
  value,
  onChange,
  onReset,
  variant = "sidebar",
  onApply,
}: {
  value: FilterValues;
  onChange: (v: FilterValues) => void;
  onReset: () => void;
  variant?: "sidebar" | "drawer";
  onApply?: () => void;
}) {
  const { data: categories } = useQuery({
    queryKey: ["categories-filter"],
    queryFn: async () => (await supabase.from("categories").select("slug, name, icon").order("name")).data ?? [],
  });
  const { data: areas } = useQuery({
    queryKey: ["areas-filter"],
    queryFn: async () => {
      const { data } = await supabase.from("shops").select("area").not("area", "is", null);
      return Array.from(new Set((data ?? []).map((r: any) => r.area).filter(Boolean))).sort();
    },
  });
  const { data: facets } = useQuery({
    queryKey: ["sp-facets"],
    queryFn: async () => {
      const { data } = await supabase
        .from("shop_products")
        .select("condition, brand, dispatch_time")
        .limit(2000);
      const conditions = Array.from(new Set((data ?? []).map((r: any) => r.condition).filter(Boolean))).sort();
      const brands = Array.from(new Set((data ?? []).map((r: any) => r.brand).filter(Boolean))).sort();
      const dispatch = Array.from(new Set((data ?? []).map((r: any) => r.dispatch_time).filter(Boolean))).sort();
      return { conditions, brands, dispatch };
    },
  });

  const set = <K extends keyof FilterValues>(k: K, v: FilterValues[K]) => onChange({ ...value, [k]: v });

  const isDrawer = variant === "drawer";
  const trust = value.minTrustScore ?? 0;

  return (
    <aside
      className={
        isDrawer
          ? "flex h-full flex-col bg-card"
          : "rounded-xl border-2 border-border bg-card p-5 space-y-4 h-fit sticky top-20"
      }
    >
      {!isDrawer && (
        <div className="flex items-center justify-between">
          <h3 className="font-display text-xl">Filters</h3>
          <Button type="button" variant="ghost" size="sm" onClick={onReset}>Reset</Button>
        </div>
      )}

      <div className={isDrawer ? "flex-1 overflow-y-auto p-5 space-y-4" : "contents"}>
        <div>
          <Label>Sort by</Label>
          <select
            value={value.sort ?? "best"}
            onChange={(e) => set("sort", e.target.value as SortKey)}
            className="w-full h-10 rounded-md border border-input bg-background px-3 text-sm"
          >
            <option value="best">Best match</option>
            <option value="price_asc">Price: low to high</option>
            <option value="price_desc">Price: high to low</option>
            <option value="newest">Recently updated</option>
            <option value="trust">Highest trust score</option>
          </select>
        </div>

        <div>
          <Label>Category</Label>
          <select value={value.category ?? ""} onChange={(e) => set("category", e.target.value || undefined)}
            className="w-full h-10 rounded-md border border-input bg-background px-3 text-sm">
            <option value="">All categories</option>
            {categories?.map((c: any) => <option key={c.slug} value={c.slug}>{c.icon} {c.name}</option>)}
          </select>
        </div>

        <div>
          <Label>Area</Label>
          <select value={value.area ?? ""} onChange={(e) => set("area", e.target.value || undefined)}
            className="w-full h-10 rounded-md border border-input bg-background px-3 text-sm">
            <option value="">All areas</option>
            {areas?.map((a: any) => <option key={a} value={a}>{a}</option>)}
          </select>
        </div>

        <div>
          <Label>Price (₹)</Label>
          <div className="grid grid-cols-2 gap-2">
            <Input type="number" min="0" placeholder="Min" value={value.minPrice ?? ""}
              onChange={(e) => set("minPrice", e.target.value ? Number(e.target.value) : undefined)} />
            <Input type="number" min="0" placeholder="Max" value={value.maxPrice ?? ""}
              onChange={(e) => set("maxPrice", e.target.value ? Number(e.target.value) : undefined)} />
          </div>
          <div className="mt-2 flex flex-wrap gap-1.5">
            {PRICE_CHIPS.map((c) => {
              const active = value.minPrice === c.min && value.maxPrice === c.max;
              return (
                <button
                  key={c.label}
                  type="button"
                  onClick={() => onChange({ ...value, minPrice: c.min, maxPrice: c.max })}
                  className={`px-2.5 py-1 rounded-full text-[11px] border transition ${
                    active
                      ? "bg-primary text-primary-foreground border-primary"
                      : "bg-background border-border text-muted-foreground hover:border-primary/40"
                  }`}
                >
                  {c.label}
                </button>
              );
            })}
          </div>
        </div>

        <div>
          <Label>Max MOQ</Label>
          <Input type="number" min="1" placeholder="Any" value={value.maxMoq ?? ""}
            onChange={(e) => set("maxMoq", e.target.value ? Number(e.target.value) : undefined)} />
        </div>

        <div>
          <Label>Condition</Label>
          <select value={value.condition ?? ""} onChange={(e) => set("condition", e.target.value || undefined)}
            className="w-full h-10 rounded-md border border-input bg-background px-3 text-sm">
            <option value="">Any condition</option>
            {(facets?.conditions ?? ["New", "Surplus", "Refurbished", "Used"]).map((c: string) => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
        </div>

        <div>
          <Label>Brand</Label>
          <Input
            list="brand-options"
            placeholder="Any brand"
            value={value.brand ?? ""}
            onChange={(e) => set("brand", e.target.value || undefined)}
          />
          <datalist id="brand-options">
            {facets?.brands?.map((b: string) => <option key={b} value={b} />)}
          </datalist>
        </div>

        <div>
          <Label>Dispatch time</Label>
          <select value={value.dispatchTime ?? ""} onChange={(e) => set("dispatchTime", e.target.value || undefined)}
            className="w-full h-10 rounded-md border border-input bg-background px-3 text-sm">
            <option value="">Any dispatch</option>
            {facets?.dispatch?.map((d: string) => <option key={d} value={d}>{d}</option>)}
          </select>
        </div>

        <div>
          <div className="flex items-center justify-between">
            <Label>Min trust score</Label>
            <span className="text-xs font-mono text-muted-foreground">{trust}+</span>
          </div>
          <input
            type="range"
            min={0}
            max={100}
            step={5}
            value={trust}
            onChange={(e) => set("minTrustScore", Number(e.target.value) || undefined)}
            className="w-full accent-primary"
          />
          <div className="flex justify-between text-[10px] text-muted-foreground">
            <span>Any</span><span>50</span><span>Excellent</span>
          </div>
        </div>

        <label className="flex items-center gap-2 text-sm cursor-pointer">
          <Checkbox checked={!!value.verifiedOnly} onCheckedChange={(c) => set("verifiedOnly", !!c)} /> Verified shops only
        </label>
        <label className="flex items-center gap-2 text-sm cursor-pointer">
          <Checkbox checked={!!value.inStockOnly} onCheckedChange={(c) => set("inStockOnly", !!c)} /> In stock only
        </label>
        <label className="flex items-center gap-2 text-sm cursor-pointer">
          <Checkbox checked={!!value.nearMe} onCheckedChange={(c) => set("nearMe", !!c)} /> Sort by nearest
        </label>
      </div>

      {isDrawer && (
        <div className="border-t border-border p-4 flex gap-2 bg-card">
          <Button type="button" variant="outline" className="flex-1" onClick={onReset}>Clear All</Button>
          <Button type="button" className="flex-1" onClick={onApply}>Apply Filters</Button>
        </div>
      )}
    </aside>
  );
}
