import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Heart } from "lucide-react";
import { useNavigate } from "@tanstack/react-router";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface Props {
  productId: string;
  shopId?: string | null;
  variant?: "default" | "icon";
  className?: string;
}

export function ProductFavoriteButton({ productId, shopId = null, variant = "default", className }: Props) {
  const { user } = useAuth();
  const qc = useQueryClient();
  const navigate = useNavigate();

  const { data: fav } = useQuery({
    enabled: !!user,
    queryKey: ["product-fav", productId, shopId, user?.id],
    queryFn: async () => {
      let q = supabase.from("product_favorites").select("id").eq("user_id", user!.id).eq("product_id", productId);
      q = shopId ? q.eq("shop_id", shopId) : q.is("shop_id", null);
      const { data } = await q.maybeSingle();
      return data;
    },
  });

  const toggle = async (e?: React.MouseEvent) => {
    e?.preventDefault();
    e?.stopPropagation();
    if (!user) { navigate({ to: "/login" }); return; }
    if (fav) {
      await supabase.from("product_favorites").delete().eq("id", fav.id);
      toast.success("Removed from wishlist");
    } else {
      const { error } = await supabase.from("product_favorites").insert({
        user_id: user.id, product_id: productId, shop_id: shopId,
      });
      if (error) return toast.error(error.message);
      toast.success("Saved to wishlist");
    }
    qc.invalidateQueries({ queryKey: ["product-fav", productId] });
    qc.invalidateQueries({ queryKey: ["wishlist"] });
  };

  if (variant === "icon") {
    return (
      <button
        type="button"
        onClick={toggle}
        aria-label={fav ? "Remove from wishlist" : "Save to wishlist"}
        className={cn(
          "h-8 w-8 rounded-full bg-background/90 backdrop-blur flex items-center justify-center shadow-float transition hover:scale-110",
          className,
        )}
      >
        <Heart className={cn("h-4 w-4", fav ? "fill-primary text-primary" : "text-foreground")} />
      </button>
    );
  }

  return (
    <Button variant="outline" size="sm" onClick={toggle} aria-pressed={!!fav} className={cn("rounded-full gap-1.5", className)}>
      <Heart className={cn("h-4 w-4", fav && "fill-primary text-primary")} />
      {fav ? "Saved" : "Save"}
    </Button>
  );
}
