import { useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { Bookmark, MessageCircle, Mail, Bell } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import type { FilterValues } from "@/components/SearchFilters";

interface Props {
  query?: string;
  filters: FilterValues;
}

const CHANNELS: Array<{ id: string; label: string; icon: any }> = [
  { id: "whatsapp", label: "WhatsApp", icon: MessageCircle },
  { id: "email", label: "Email", icon: Mail },
  { id: "push", label: "Push notifications", icon: Bell },
];

export function SaveSearchButton({ query, filters }: Props) {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [channels, setChannels] = useState<string[]>(["email"]);
  const [saving, setSaving] = useState(false);

  const toggle = (id: string) =>
    setChannels((c) => (c.includes(id) ? c.filter((x) => x !== id) : [...c, id]));

  const onClick = () => {
    if (!user) {
      toast.info("Sign in to save searches");
      navigate({ to: "/login" });
      return;
    }
    const auto = [query, filters.category, filters.area, filters.maxMoq ? `MOQ ≤ ${filters.maxMoq}` : null,
      filters.maxPrice ? `Under ₹${filters.maxPrice}` : null].filter(Boolean).join(" · ");
    setName(auto || "My search");
    setOpen(true);
  };

  const save = async () => {
    if (!user) return;
    setSaving(true);
    const { error } = await supabase.from("saved_searches").insert({
      user_id: user.id,
      name: name.trim() || "My search",
      query: query || null,
      category_slug: filters.category || null,
      filters: filters as any,
      alert_channels: channels,
    });
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success("Search saved — we'll alert you on new matches");
    setOpen(false);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button type="button" variant="outline" size="sm" onClick={onClick} className="rounded-full gap-2">
          <Bookmark className="h-4 w-4" /> Save search
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Save this search</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <Label>Name</Label>
            <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Mobile accessories MOQ <100" />
          </div>
          <div>
            <Label>Alert me on new matches via</Label>
            <div className="mt-2 space-y-2">
              {CHANNELS.map((c) => (
                <label key={c.id} className="flex items-center gap-2 cursor-pointer text-sm">
                  <Checkbox checked={channels.includes(c.id)} onCheckedChange={() => toggle(c.id)} />
                  <c.icon className="h-4 w-4 text-primary" /> {c.label}
                </label>
              ))}
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={() => setOpen(false)}>Cancel</Button>
          <Button onClick={save} disabled={saving}>{saving ? "Saving…" : "Save search"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
