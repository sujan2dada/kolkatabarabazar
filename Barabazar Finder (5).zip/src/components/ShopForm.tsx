import { useEffect, useRef, useState, type FormEvent } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { LocationPicker } from "@/components/ShopMap";
import { CategoryPicker } from "@/components/CategoryPicker";
import { slugify } from "@/lib/slug";
import { toast } from "sonner";
import { Upload, Loader2 } from "lucide-react";

export interface ShopFormValues {
  name: string;
  slug: string;
  description: string;
  address: string;
  area: string;
  phone: string;
  whatsapp: string;
  hours: string;
  owner_name: string;
  years_in_business: number | null;
  photos: string[];
  category_id: string | null;
  lat: number | null;
  lng: number | null;
}

export function ShopForm({
  initial,
  onSubmit,
  submitLabel,
  busy,
}: {
  initial?: Partial<ShopFormValues>;
  onSubmit: (v: ShopFormValues) => void;
  submitLabel: string;
  busy?: boolean;
}) {
  const [v, setV] = useState<ShopFormValues>({
    name: initial?.name ?? "",
    slug: initial?.slug ?? "",
    description: initial?.description ?? "",
    address: initial?.address ?? "",
    area: initial?.area ?? "",
    phone: initial?.phone ?? "",
    whatsapp: initial?.whatsapp ?? "",
    hours: initial?.hours ?? "",
    owner_name: initial?.owner_name ?? "",
    years_in_business: initial?.years_in_business ?? null,
    photos: initial?.photos ?? [],
    category_id: initial?.category_id ?? null,
    lat: initial?.lat ?? null,
    lng: initial?.lng ?? null,
  });
  const [photoUrl, setPhotoUrl] = useState("");
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);




  useEffect(() => {
    if (!initial?.slug && v.name) setV((s) => ({ ...s, slug: slugify(v.name) }));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [v.name]);

  const submit = (e: FormEvent) => { e.preventDefault(); onSubmit(v); };
  const upd = <K extends keyof ShopFormValues>(k: K, val: ShopFormValues[K]) => setV((s) => ({ ...s, [k]: val }));

  return (
    <form onSubmit={submit} className="space-y-5">
      <div className="grid sm:grid-cols-2 gap-4">
        <div><Label>Shop name</Label><Input value={v.name} onChange={(e) => upd("name", e.target.value)} required /></div>
        <div><Label>URL slug</Label><Input value={v.slug} onChange={(e) => upd("slug", slugify(e.target.value))} required /></div>
      </div>
      <div className="grid sm:grid-cols-2 gap-4">
        <div><Label>Owner name</Label><Input value={v.owner_name} onChange={(e) => upd("owner_name", e.target.value)} /></div>
        <div><Label>Years in business</Label><Input type="number" min="0" value={v.years_in_business ?? ""} onChange={(e) => upd("years_in_business", e.target.value ? Number(e.target.value) : null)} /></div>
      </div>
      <div><Label>Description</Label><Textarea value={v.description} onChange={(e) => upd("description", e.target.value)} rows={3} /></div>
      <div className="grid sm:grid-cols-2 gap-4">
        <div><Label>Address</Label><Input value={v.address} onChange={(e) => upd("address", e.target.value)} required /></div>
        <div><Label>Area / Lane</Label><Input value={v.area} onChange={(e) => upd("area", e.target.value)} placeholder="e.g. Burrabazar" /></div>
      </div>
      <div className="grid sm:grid-cols-3 gap-4">
        <div><Label>Phone</Label><Input value={v.phone} onChange={(e) => upd("phone", e.target.value)} placeholder="+91 …" /></div>
        <div><Label>WhatsApp number</Label><Input value={v.whatsapp} onChange={(e) => upd("whatsapp", e.target.value)} placeholder="91XXXXXXXXXX" /></div>
        <div><Label>Hours</Label><Input value={v.hours} onChange={(e) => upd("hours", e.target.value)} placeholder="Mon–Sat 9am–9pm" /></div>
      </div>
      <CategoryPicker value={v.category_id} onChange={(leafId) => upd("category_id", leafId)} />
      <div>
        <Label>Shop photos</Label>
        <div className="flex flex-wrap gap-2 items-center">
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            multiple
            className="hidden"
            onChange={async (e) => {
              const files = Array.from(e.target.files ?? []);
              if (!files.length) return;
              setUploading(true);
              try {
                const { data: { user } } = await supabase.auth.getUser();
                if (!user) { toast.error("Please sign in to upload."); return; }
                const uploaded: string[] = [];
                for (const file of files) {
                  if (file.size > 5 * 1024 * 1024) { toast.error(`${file.name} is larger than 5MB`); continue; }
                  const ext = file.name.split(".").pop() || "jpg";
                  const path = `${user.id}/${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
                  const { error } = await supabase.storage.from("shop-photos").upload(path, file, { contentType: file.type });
                  if (error) { toast.error(error.message); continue; }
                  const { data: pub } = supabase.storage.from("shop-photos").getPublicUrl(path);
                  uploaded.push(pub.publicUrl);
                }
                if (uploaded.length) {
                  setV((s) => ({ ...s, photos: [...s.photos, ...uploaded] }));
                  toast.success(`${uploaded.length} photo${uploaded.length === 1 ? "" : "s"} uploaded`);
                }
              } finally {
                setUploading(false);
                if (fileInputRef.current) fileInputRef.current.value = "";
              }
            }}
          />
          <Button type="button" variant="outline" disabled={uploading} onClick={() => fileInputRef.current?.click()}>
            {uploading ? <Loader2 className="h-4 w-4 mr-1 animate-spin" /> : <Upload className="h-4 w-4 mr-1" />}
            {uploading ? "Uploading…" : "Upload photos"}
          </Button>
          <span className="text-xs text-muted-foreground">or paste a URL</span>
          <Input value={photoUrl} onChange={(e) => setPhotoUrl(e.target.value)} placeholder="https://…" className="flex-1 min-w-[180px]" />
          <Button type="button" variant="ghost" onClick={() => {
            if (!photoUrl.trim()) return;
            upd("photos", [...v.photos, photoUrl.trim()]);
            setPhotoUrl("");
          }}>Add URL</Button>
        </div>
        {v.photos.length > 0 && (
          <div className="grid grid-cols-3 sm:grid-cols-4 gap-2 mt-2">
            {v.photos.map((p, i) => (
              <div key={i} className="relative group">
                <img src={p} alt="" className="h-20 w-full object-cover rounded-md border border-border" />
                <button type="button" onClick={() => upd("photos", v.photos.filter((_, j) => j !== i))}
                  className="absolute top-1 right-1 bg-destructive text-destructive-foreground rounded-full h-5 w-5 text-xs opacity-100 sm:opacity-0 group-hover:opacity-100">×</button>
              </div>
            ))}
          </div>
        )}
      </div>
      <div>
        <Label>Location on map</Label>
        <LocationPicker
          value={v.lat != null && v.lng != null ? { lat: v.lat, lng: v.lng } : null}
          onChange={(p) => setV((s) => ({ ...s, lat: p.lat, lng: p.lng }))}
        />
        {v.lat != null && (<p className="text-xs text-muted-foreground mt-1">Pinned at {v.lat.toFixed(5)}, {v.lng!.toFixed(5)}</p>)}
      </div>
      <Button type="submit" disabled={busy}>{busy ? "Saving…" : submitLabel}</Button>
    </form>
  );
}
