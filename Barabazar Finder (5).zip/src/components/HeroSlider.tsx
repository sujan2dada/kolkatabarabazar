import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { ChevronLeft, ChevronRight, ArrowRight } from "lucide-react";
import heroImg from "@/assets/hero-warehouse.jpg";
import catApparel from "@/assets/cat-apparel.jpg";
import catElectronics from "@/assets/cat-electronics.jpg";

type Slide = {
  image: string;
  tag: string;
  title: string;
  subtitle: string;
  cta: string;
  to: string;
  badge?: string;
};

const SLIDES: Slide[] = [
  {
    image: heroImg,
    tag: "Mega Clearance",
    title: "Factory surplus stock — up to 70% off",
    subtitle: "Direct from manufacturers. WhatsApp the seller instantly.",
    cta: "Shop clearance lots",
    to: "/search",
    badge: "70% OFF",
  },
  {
    image: catApparel,
    tag: "Apparel Liquidation",
    title: "Branded apparel overstock at wholesale prices",
    subtitle: "Bulk lots ready to ship — MOQs from 50 pieces.",
    cta: "Browse apparel",
    to: "/search",
    badge: "NEW LOTS",
  },
  {
    image: catElectronics,
    tag: "Electronics Stock",
    title: "Mobile accessories & gadgets — bulk deals",
    subtitle: "Verified suppliers, transparent pricing, fast despatch.",
    cta: "Explore electronics",
    to: "/search",
    badge: "VERIFIED",
  },
];

export function HeroSlider() {
  const [i, setI] = useState(0);

  useEffect(() => {
    const t = setInterval(() => setI((v) => (v + 1) % SLIDES.length), 5000);
    return () => clearInterval(t);
  }, []);

  const go = (delta: number) =>
    setI((v) => (v + delta + SLIDES.length) % SLIDES.length);

  return (
    <section className="relative w-full overflow-hidden bg-secondary">
      <div
        className="flex transition-transform duration-700 ease-out"
        style={{ transform: `translateX(-${i * 100}%)` }}
      >
        {SLIDES.map((s, idx) => (
          <div key={idx} className="relative w-full shrink-0">
            <div className="relative aspect-[16/7] sm:aspect-[21/8] md:aspect-[24/8] w-full">
              <img
                src={s.image}
                alt={s.title}
                width={1920}
                height={640}
                loading={idx === 0 ? "eager" : "lazy"}
                fetchPriority={idx === 0 ? "high" : "auto"}
                className="absolute inset-0 h-full w-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-foreground/85 via-foreground/45 to-transparent" />
              <div className="absolute inset-0 flex items-center">
                <div className="container mx-auto px-4 sm:px-8">
                  <div className="max-w-xl text-background">
                    <div className="inline-flex items-center gap-2 rounded-full bg-accent text-accent-foreground px-3 py-1 text-[10px] sm:text-xs font-bold uppercase tracking-wider">
                      {s.tag}
                      {s.badge && <span className="rounded-full bg-background/90 text-foreground px-2 py-0.5">{s.badge}</span>}
                    </div>
                    <h2 className="mt-3 sm:mt-4 font-display text-2xl sm:text-4xl md:text-5xl leading-tight">
                      {s.title}
                    </h2>
                    <p className="mt-2 sm:mt-3 text-xs sm:text-base text-background/80 max-w-md">{s.subtitle}</p>
                    <Link
                      to={s.to}
                      search={{ q: "" }}
                      className="mt-4 sm:mt-5 inline-flex items-center gap-2 rounded-full bg-primary px-4 sm:px-5 py-2 sm:py-2.5 text-xs sm:text-sm font-semibold text-primary-foreground shadow-float hover:bg-primary/90 transition"
                    >
                      {s.cta} <ArrowRight className="h-4 w-4" />
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Arrows */}
      <button
        onClick={() => go(-1)}
        aria-label="Previous slide"
        className="hidden sm:flex absolute left-3 top-1/2 -translate-y-1/2 h-10 w-10 items-center justify-center rounded-full bg-background/80 backdrop-blur text-foreground hover:bg-background shadow-float"
      >
        <ChevronLeft className="h-5 w-5" />
      </button>
      <button
        onClick={() => go(1)}
        aria-label="Next slide"
        className="hidden sm:flex absolute right-3 top-1/2 -translate-y-1/2 h-10 w-10 items-center justify-center rounded-full bg-background/80 backdrop-blur text-foreground hover:bg-background shadow-float"
      >
        <ChevronRight className="h-5 w-5" />
      </button>

      {/* Dots */}
      <div className="absolute bottom-3 sm:bottom-5 left-1/2 -translate-x-1/2 flex gap-1.5">
        {SLIDES.map((_, idx) => (
          <button
            key={idx}
            onClick={() => setI(idx)}
            aria-label={`Go to slide ${idx + 1}`}
            className={`h-1.5 rounded-full transition-all ${
              i === idx ? "w-6 bg-accent" : "w-1.5 bg-background/70"
            }`}
          />
        ))}
      </div>
    </section>
  );
}
