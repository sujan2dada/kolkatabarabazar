import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Label } from "@/components/ui/label";

/**
 * 3-level cascading picker over the `categories` table (which is self-referential
 * via parent_id): Category → Subcategory → Product Type.
 *
 * `value` is the leaf-most selected category id (product type when available,
 * otherwise subcategory, otherwise top-level). `onChange` always receives the
 * deepest selected id so callers can store a single category_id.
 */
export function CategoryPicker({
  value,
  onChange,
  required,
}: {
  value: string | null;
  onChange: (leafId: string | null, path: { top: string | null; sub: string | null; type: string | null }) => void;
  required?: boolean;
}) {
  // Top-level categories
  const { data: tops } = useQuery({
    queryKey: ["cat-tops"],
    queryFn: async () =>
      (await supabase.from("categories").select("id, name, icon, parent_id").is("parent_id", null).order("name")).data ?? [],
  });

  // Resolve the ancestor path of the current value so the selects pre-fill on edit
  const { data: ancestry } = useQuery({
    enabled: !!value,
    queryKey: ["cat-ancestry", value],
    queryFn: async () => {
      let cur = value as string | null;
      const chain: { id: string; parent_id: string | null }[] = [];
      while (cur) {
        const { data } = await supabase.from("categories").select("id, parent_id").eq("id", cur).maybeSingle();
        if (!data) break;
        chain.unshift(data);
        cur = data.parent_id;
      }
      return chain;
    },
  });

  const topId = ancestry?.[0]?.id ?? null;
  const subId = ancestry && ancestry.length >= 2 ? ancestry[1].id : null;
  const typeId = ancestry && ancestry.length >= 3 ? ancestry[2].id : null;

  const { data: subs } = useQuery({
    enabled: !!topId,
    queryKey: ["cat-subs", topId],
    queryFn: async () =>
      (await supabase.from("categories").select("id, name").eq("parent_id", topId!).order("name")).data ?? [],
  });

  const { data: types } = useQuery({
    enabled: !!subId,
    queryKey: ["cat-types", subId],
    queryFn: async () =>
      (await supabase.from("categories").select("id, name").eq("parent_id", subId!).order("name")).data ?? [],
  });

  const selectCls = "w-full h-10 rounded-md border border-input bg-background px-3 text-sm";

  return (
    <div className="grid sm:grid-cols-3 gap-3">
      <div>
        <Label>Category</Label>
        <select
          required={required}
          value={topId ?? ""}
          onChange={(e) => {
            const id = e.target.value || null;
            onChange(id, { top: id, sub: null, type: null });
          }}
          className={selectCls}
        >
          <option value="">— Select —</option>
          {tops?.map((c: any) => (
            <option key={c.id} value={c.id}>{c.icon ? `${c.icon} ` : ""}{c.name}</option>
          ))}
        </select>
      </div>
      <div>
        <Label>Subcategory</Label>
        <select
          value={subId ?? ""}
          disabled={!topId || !subs || subs.length === 0}
          onChange={(e) => {
            const id = e.target.value || null;
            onChange(id ?? topId, { top: topId, sub: id, type: null });
          }}
          className={selectCls}
        >
          <option value="">{!topId ? "Pick category first" : (subs && subs.length ? "— Select —" : "None")}</option>
          {subs?.map((c: any) => <option key={c.id} value={c.id}>{c.name}</option>)}
        </select>
      </div>
      <div>
        <Label>Product type</Label>
        <select
          value={typeId ?? ""}
          disabled={!subId || !types || types.length === 0}
          onChange={(e) => {
            const id = e.target.value || null;
            onChange(id ?? subId ?? topId, { top: topId, sub: subId, type: id });
          }}
          className={selectCls}
        >
          <option value="">{!subId ? "Pick subcategory first" : (types && types.length ? "— Select —" : "None")}</option>
          {types?.map((c: any) => <option key={c.id} value={c.id}>{c.name}</option>)}
        </select>
      </div>
    </div>
  );
}
