import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Heart } from "lucide-react";
import { useNavigate } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

export function FavoriteButton({ shopId }: { shopId: string }) {
  const { user } = useAuth();
  const qc = useQueryClient();
  const navigate = useNavigate();

  const { data: fav } = useQuery({
    enabled: !!user,
    queryKey: ["favorite", shopId, user?.id],
    queryFn: async () => {
      const { data } = await supabase
        .from("favorites").select("id")
        .eq("user_id", user!.id).eq("shop_id", shopId).maybeSingle();
      return data;
    },
  });

  const toggle = async () => {
    if (!user) { navigate({ to: "/login" }); return; }
    if (fav) {
      await supabase.from("favorites").delete().eq("id", fav.id);
      toast.success("Removed from favorites");
    } else {
      const { error } = await supabase.from("favorites").insert({ user_id: user.id, shop_id: shopId });
      if (error) toast.error(error.message); else toast.success("Saved to favorites");
    }
    qc.invalidateQueries({ queryKey: ["favorite", shopId] });
    qc.invalidateQueries({ queryKey: ["favorites"] });
  };

  return (
    <Button variant="outline" size="sm" onClick={toggle} aria-pressed={!!fav}>
      <Heart className={`h-4 w-4 mr-1 ${fav ? "fill-primary text-primary" : ""}`} />
      {fav ? "Saved" : "Save"}
    </Button>
  );
}
