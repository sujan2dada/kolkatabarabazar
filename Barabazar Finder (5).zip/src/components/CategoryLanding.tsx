import { Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { ArrowRight, BadgeCheck, Flame, ShieldCheck, Truck, Zap } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { SiteHeader } from "@/components/SiteHeader";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

export interface CategoryLandingConfig {
  slug: string; // route slug (e.g. "mobile-accessories-wholesale")
  h1: string;
  tagline: string;
  intro: string;
  heroImage: string;
  /** Search params used for "Browse all" CTA and the product fetch */
  search: { q?: string; category?: string };
  benefits: { icon: "verified" | "fast" | "price" | "trust"; title: string; body: string }[];
  faqs: { q: string; a: string }[];
}

const ICONS = {
  verified: BadgeCheck,
  fast: Zap,
  price: Flame,
  trust: ShieldCheck,
  truck: Truck,
};

export function CategoryLanding({ config }: { config: CategoryLandingConfig }) {
  const { data: products = [], isLoading } = useQuery({
    queryKey: ["category-landing", config.slug],
    queryFn: async () => {
      let q = supabase
        .from("products")
        .select("id, name, slug, image_url, categories!inner(slug, name)")
        .limit(12);
      if (config.search.category) q = q.eq("categories.slug", config.search.category);
      if (config.search.q)
        q = q.or(`name.ilike.%${config.search.q}%,description.ilike.%${config.search.q}%`);
      const { data } = await q;
      return data ?? [];
    },
  });

  return (
    <div className="min-h-screen">
      <SiteHeader />
      <main>
        {/* HERO */}
        <section className="relative overflow-hidden border-b border-border bg-gradient-to-br from-primary/10 via-background to-accent/5">
          <div className="container mx-auto px-4 py-16 lg:py-24 grid lg:grid-cols-[1.1fr_1fr] gap-10 items-center">
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <Badge className="bg-accent text-accent-foreground mb-4">
                <Flame className="h-3 w-3 mr-1" /> Live clearance stock
              </Badge>
              <h1 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold leading-tight tracking-tight">
                {config.h1}
              </h1>
              <p className="mt-4 text-lg text-muted-foreground max-w-xl">{config.tagline}</p>
              <div className="mt-6 flex flex-wrap gap-3">
                <Button asChild size="lg" className="rounded-full">
                  <Link to="/search" search={config.search}>
                    Browse all lots <ArrowRight className="h-4 w-4 ml-1" />
                  </Link>
                </Button>
                <Button asChild size="lg" variant="outline" className="rounded-full">
                  <Link to="/pricing">Become a supplier</Link>
                </Button>
              </div>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, scale: 0.96 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="relative aspect-[4/3] rounded-3xl overflow-hidden shadow-2xl"
            >
              <img src={config.heroImage} alt={config.h1} className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-tr from-primary/30 to-transparent" />
            </motion.div>
          </div>
        </section>

        {/* INTRO */}
        <section className="container mx-auto px-4 py-12 max-w-3xl">
          <p className="text-lg text-muted-foreground leading-relaxed">{config.intro}</p>
        </section>

        {/* BENEFITS */}
        <section className="container mx-auto px-4 py-8">
          <h2 className="font-display text-2xl md:text-3xl font-bold mb-6">Why buy here</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
            {config.benefits.map((b, i) => {
              const Icon = ICONS[b.icon];
              return (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 12 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.4, delay: i * 0.05 }}
                  className="rounded-2xl border border-border bg-card p-5 shadow-sm hover:shadow-md transition-shadow"
                >
                  <div className="h-10 w-10 rounded-xl bg-primary/10 text-primary flex items-center justify-center mb-3">
                    <Icon className="h-5 w-5" />
                  </div>
                  <h3 className="font-semibold mb-1">{b.title}</h3>
                  <p className="text-sm text-muted-foreground">{b.body}</p>
                </motion.div>
              );
            })}
          </div>
        </section>

        {/* PRODUCTS */}
        <section className="container mx-auto px-4 py-12">
          <div className="flex items-end justify-between mb-6">
            <h2 className="font-display text-2xl md:text-3xl font-bold">Trending lots</h2>
            <Link
              to="/search"
              search={config.search}
              className="text-sm font-medium text-primary hover:underline"
            >
              View all →
            </Link>
          </div>
          {isLoading ? (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {Array.from({ length: 8 }).map((_, i) => (
                <div key={i} className="aspect-square rounded-2xl bg-muted animate-pulse" />
              ))}
            </div>
          ) : products.length === 0 ? (
            <div className="rounded-2xl border border-dashed border-border p-10 text-center text-muted-foreground">
              New stock arriving soon. <Link to="/search" className="text-primary underline">Browse all suppliers</Link>.
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {products.map((p: any) => (
                <Link
                  key={p.id}
                  to="/product/$slug"
                  params={{ slug: p.slug }}
                  className="group rounded-2xl overflow-hidden border border-border bg-card hover:shadow-lg transition-all hover:-translate-y-1"
                >
                  <div className="aspect-square bg-muted overflow-hidden">
                    {p.image_url ? (
                      <img
                        src={p.image_url}
                        alt={p.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                    ) : (
                      <div className="w-full h-full grid place-items-center text-muted-foreground text-xs">
                        No image
                      </div>
                    )}
                  </div>
                  <div className="p-3">
                    <div className="text-xs text-muted-foreground">{p.categories?.name}</div>
                    <div className="font-medium text-sm line-clamp-2">{p.name}</div>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </section>

        {/* FAQ */}
        <section className="container mx-auto px-4 py-12 max-w-3xl">
          <h2 className="font-display text-2xl md:text-3xl font-bold mb-6">Frequently asked questions</h2>
          <div className="space-y-3">
            {config.faqs.map((f, i) => (
              <details
                key={i}
                className="rounded-2xl border border-border bg-card p-5 group"
              >
                <summary className="font-medium cursor-pointer list-none flex justify-between items-center">
                  {f.q}
                  <span className="text-primary transition-transform group-open:rotate-45 text-2xl leading-none">+</span>
                </summary>
                <p className="mt-3 text-muted-foreground text-sm leading-relaxed">{f.a}</p>
              </details>
            ))}
          </div>
        </section>

        {/* CTA */}
        <section className="container mx-auto px-4 py-16">
          <div className="rounded-3xl bg-gradient-to-br from-primary to-primary/80 text-primary-foreground p-10 md:p-14 text-center">
            <h2 className="font-display text-3xl md:text-4xl font-bold mb-3">
              Ready to source {config.tagline.toLowerCase().replace(/\.$/, "")}?
            </h2>
            <p className="opacity-90 mb-6 max-w-xl mx-auto">
              Compare verified suppliers, MOQs, and live stock in one place.
            </p>
            <Button asChild size="lg" variant="secondary" className="rounded-full">
              <Link to="/search" search={config.search}>
                Browse live stock <ArrowRight className="h-4 w-4 ml-1" />
              </Link>
            </Button>
          </div>
        </section>
      </main>
    </div>
  );
}

export function categoryJsonLd(config: CategoryLandingConfig, url: string) {
  return {
    "@context": "https://schema.org",
    "@type": "CollectionPage",
    name: config.h1,
    description: config.tagline,
    url,
    mainEntity: {
      "@type": "FAQPage",
      mainEntity: config.faqs.map((f) => ({
        "@type": "Question",
        name: f.q,
        acceptedAnswer: { "@type": "Answer", text: f.a },
      })),
    },
  };
}
