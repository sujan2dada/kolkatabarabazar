import { useEffect, useRef } from "react";
import { loadGoogleMaps } from "@/lib/google-maps-loader";

export function ShopMap({ lat, lng, name }: { lat: number; lng: number; name: string }) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let cancelled = false;
    loadGoogleMaps().then((google) => {
      if (cancelled || !ref.current) return;
      const map = new google.maps.Map(ref.current, {
        center: { lat, lng },
        zoom: 15,
        disableDefaultUI: false,
        clickableIcons: false,
      });
      new google.maps.Marker({ position: { lat, lng }, map, title: name });
    }).catch((e) => console.error(e));
    return () => { cancelled = true; };
  }, [lat, lng, name]);

  return <div ref={ref} className="w-full h-80 rounded-lg border border-border" />;
}

export function LocationPicker({
  value,
  onChange,
}: {
  value: { lat: number; lng: number } | null;
  onChange: (v: { lat: number; lng: number }) => void;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const markerRef = useRef<any>(null);
  const mapRef = useRef<any>(null);

  useEffect(() => {
    let cancelled = false;
    loadGoogleMaps().then((google) => {
      if (cancelled || !ref.current) return;
      const center = value ?? { lat: 22.5726, lng: 88.3639 };
      const map = new google.maps.Map(ref.current, {
        center,
        zoom: 14,
      });
      mapRef.current = map;
      if (value) {
        markerRef.current = new google.maps.Marker({ position: value, map, draggable: true });
        markerRef.current.addListener("dragend", () => {
          const p = markerRef.current.getPosition();
          onChange({ lat: p.lat(), lng: p.lng() });
        });
      }
      map.addListener("click", (e: any) => {
        const pos = { lat: e.latLng.lat(), lng: e.latLng.lng() };
        if (!markerRef.current) {
          markerRef.current = new google.maps.Marker({ position: pos, map, draggable: true });
          markerRef.current.addListener("dragend", () => {
            const p = markerRef.current.getPosition();
            onChange({ lat: p.lat(), lng: p.lng() });
          });
        } else {
          markerRef.current.setPosition(pos);
        }
        onChange(pos);
      });
    });
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="space-y-2">
      <div ref={ref} className="w-full h-64 rounded-lg border border-border" />
      <p className="text-xs text-muted-foreground">Click on the map to place your shop, then drag the pin to fine-tune.</p>
    </div>
  );
}
