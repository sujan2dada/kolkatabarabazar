import { useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Star, Zap, PackageCheck, ShieldCheck } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";

interface Review {
  id: string;
  user_id: string;
  rating: number;
  fast_response: number | null;
  accurate_stock: number | null;
  trusted_seller: number | null;
  comment: string | null;
  created_at: string;
}

function Stars({ value, onChange, size = 4 }: { value: number; onChange?: (n: number) => void; size?: 4 | 5 | 6 }) {
  const cls = size === 6 ? "h-6 w-6" : size === 5 ? "h-5 w-5" : "h-4 w-4";
  return (
    <div className="inline-flex items-center gap-0.5">
      {[1, 2, 3, 4, 5].map((n) => (
        <button
          key={n}
          type="button"
          disabled={!onChange}
          onClick={() => onChange?.(n)}
          className={onChange ? "cursor-pointer" : "cursor-default"}
        >
          <Star className={`${cls} ${n <= value ? "fill-accent text-accent" : "text-muted-foreground/40"}`} />
        </button>
      ))}
    </div>
  );
}

function avg(nums: Array<number | null | undefined>) {
  const v = nums.filter((n): n is number => typeof n === "number");
  if (!v.length) return 0;
  return v.reduce((a, b) => a + b, 0) / v.length;
}

export function ShopReviewsSummary({ shopId }: { shopId: string }) {
  const { data } = useQuery({
    queryKey: ["shop-reviews-summary", shopId],
    queryFn: async (): Promise<Review[]> => {
      const { data } = await supabase.from("shop_reviews")
        .select("id, user_id, rating, fast_response, accurate_stock, trusted_seller, comment, created_at")
        .eq("shop_id", shopId);
      return (data as Review[]) ?? [];
    },
  });
  const reviews = data ?? [];
  if (reviews.length === 0) return null;
  const overall = avg(reviews.map((r) => r.rating));
  const fast = avg(reviews.map((r) => r.fast_response));
  const acc = avg(reviews.map((r) => r.accurate_stock));
  const trust = avg(reviews.map((r) => r.trusted_seller));
  return (
    <div className="inline-flex items-center gap-2 rounded-full bg-accent/10 border border-accent/30 px-3 py-1">
      <Star className="h-4 w-4 fill-accent text-accent" />
      <span className="font-bold text-sm">{overall.toFixed(1)}</span>
      <span className="text-xs text-muted-foreground">({reviews.length})</span>
    </div>
  );
}

export function ShopReviews({ shopId }: { shopId: string }) {
  const { user } = useAuth();
  const navigate = useNavigate();
  const qc = useQueryClient();

  const { data: reviews } = useQuery({
    queryKey: ["shop-reviews", shopId],
    queryFn: async (): Promise<Review[]> => {
      const { data } = await supabase.from("shop_reviews")
        .select("id, user_id, rating, fast_response, accurate_stock, trusted_seller, comment, created_at")
        .eq("shop_id", shopId).order("created_at", { ascending: false });
      return (data as Review[]) ?? [];
    },
  });

  const list = reviews ?? [];
  const own = user ? list.find((r) => r.user_id === user.id) : undefined;
  const overall = avg(list.map((r) => r.rating));
  const sub = {
    fast: avg(list.map((r) => r.fast_response)),
    acc: avg(list.map((r) => r.accurate_stock)),
    trust: avg(list.map((r) => r.trusted_seller)),
  };

  const [showForm, setShowForm] = useState(false);
  const [rating, setRating] = useState(own?.rating ?? 0);
  const [fast, setFast] = useState(own?.fast_response ?? 0);
  const [acc, setAcc] = useState(own?.accurate_stock ?? 0);
  const [trust, setTrust] = useState(own?.trusted_seller ?? 0);
  const [comment, setComment] = useState(own?.comment ?? "");
  const [saving, setSaving] = useState(false);

  const startWrite = () => {
    if (!user) { toast.info("Sign in to leave a review"); navigate({ to: "/login" }); return; }
    setRating(own?.rating ?? 0);
    setFast(own?.fast_response ?? 0);
    setAcc(own?.accurate_stock ?? 0);
    setTrust(own?.trusted_seller ?? 0);
    setComment(own?.comment ?? "");
    setShowForm(true);
  };

  const submit = async () => {
    if (!user || rating === 0) return toast.error("Please give an overall rating");
    setSaving(true);
    const payload = {
      shop_id: shopId, user_id: user.id, rating,
      fast_response: fast || null, accurate_stock: acc || null, trusted_seller: trust || null,
      comment: comment.trim() || null,
    };
    const { error } = await supabase.from("shop_reviews").upsert(payload, { onConflict: "shop_id,user_id" });
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success("Thanks for your review");
    setShowForm(false);
    qc.invalidateQueries({ queryKey: ["shop-reviews", shopId] });
    qc.invalidateQueries({ queryKey: ["shop-reviews-summary", shopId] });
  };

  return (
    <section className="rounded-2xl border-2 border-border bg-card p-6 space-y-6">
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <h2 className="font-display text-2xl text-foreground">Reviews & Ratings</h2>
          {list.length > 0 ? (
            <div className="mt-2 flex items-center gap-3">
              <div className="flex items-center gap-1">
                <span className="font-display text-3xl text-foreground">{overall.toFixed(1)}</span>
                <Star className="h-5 w-5 fill-accent text-accent" />
              </div>
              <span className="text-sm text-muted-foreground">from {list.length} {list.length === 1 ? "buyer" : "buyers"}</span>
            </div>
          ) : (
            <p className="text-sm text-muted-foreground mt-1">No reviews yet — be the first.</p>
          )}
        </div>
        <Button onClick={startWrite} className="rounded-full">{own ? "Edit your review" : "Write a review"}</Button>
      </div>

      {list.length > 0 && (
        <div className="grid sm:grid-cols-3 gap-3">
          {[
            { label: "Fast Response", icon: Zap, v: sub.fast },
            { label: "Accurate Stock", icon: PackageCheck, v: sub.acc },
            { label: "Trusted Seller", icon: ShieldCheck, v: sub.trust },
          ].map((s) => (
            <div key={s.label} className="rounded-xl border border-border bg-secondary/40 p-3 flex items-center justify-between">
              <div className="flex items-center gap-2 text-sm font-medium text-foreground">
                <s.icon className="h-4 w-4 text-primary" />{s.label}
              </div>
              <div className="flex items-center gap-1">
                <span className="font-bold text-sm">{s.v ? s.v.toFixed(1) : "—"}</span>
                <Star className="h-3.5 w-3.5 fill-accent text-accent" />
              </div>
            </div>
          ))}
        </div>
      )}

      {showForm && (
        <div className="rounded-xl border border-border bg-secondary/30 p-4 space-y-4">
          <div className="flex items-center justify-between">
            <div className="text-sm font-medium">Overall rating</div>
            <Stars value={rating} onChange={setRating} size={6} />
          </div>
          {[
            { label: "Fast Response", v: fast, set: setFast },
            { label: "Accurate Stock", v: acc, set: setAcc },
            { label: "Trusted Seller", v: trust, set: setTrust },
          ].map((s) => (
            <div key={s.label} className="flex items-center justify-between">
              <div className="text-sm text-muted-foreground">{s.label}</div>
              <Stars value={s.v} onChange={s.set} size={5} />
            </div>
          ))}
          <Textarea value={comment} onChange={(e) => setComment(e.target.value)} placeholder="Share details of your experience (optional)" rows={3} />
          <div className="flex justify-end gap-2">
            <Button variant="ghost" onClick={() => setShowForm(false)}>Cancel</Button>
            <Button onClick={submit} disabled={saving}>{saving ? "Submitting…" : "Submit review"}</Button>
          </div>
        </div>
      )}

      {list.length > 0 && (
        <ul className="divide-y divide-border">
          {list.map((r) => (
            <li key={r.id} className="py-4 first:pt-0 last:pb-0">
              <div className="flex items-center gap-2 mb-1">
                <Stars value={r.rating} size={4} />
                <span className="text-xs text-muted-foreground">{new Date(r.created_at).toLocaleDateString()}</span>
              </div>
              {r.comment && <p className="text-sm text-foreground">{r.comment}</p>}
              <div className="mt-1.5 flex flex-wrap gap-3 text-[11px] text-muted-foreground">
                {r.fast_response != null && <span>Fast response {r.fast_response}/5</span>}
                {r.accurate_stock != null && <span>Accurate stock {r.accurate_stock}/5</span>}
                {r.trusted_seller != null && <span>Trusted {r.trusted_seller}/5</span>}
              </div>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
