import { Link, useRouterState, useNavigate } from "@tanstack/react-router";
import { Search, SlidersHorizontal, Heart, PlusCircle, User } from "lucide-react";
import { useAuth } from "@/lib/auth";

const items = [
  { to: "/search", label: "Search", icon: Search, match: (p: string) => p === "/search" || p === "/" },
  { to: "/search", label: "Filters", icon: SlidersHorizontal, action: "filters" as const },
  { to: "/favorites", label: "Wishlist", icon: Heart, action: "wishlist" as const },
  { to: "/dashboard", label: "Post Stock", icon: PlusCircle, match: (p: string) => p.startsWith("/dashboard") || p.startsWith("/shops"), highlight: true },
  { to: "/account", label: "Account", icon: User, match: (p: string) => p.startsWith("/login") || p.startsWith("/account") },
];

export function MobileBottomNav() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const navigate = useNavigate();
  const { user } = useAuth();

  // hide on auth pages
  if (pathname.startsWith("/login") || pathname.startsWith("/signup")) return null;

  const openFilters = () => {
    if (pathname.startsWith("/search")) {
      window.dispatchEvent(new CustomEvent("open-search-filters"));
    } else {
      navigate({ to: "/search", search: { q: "" } });
      setTimeout(() => window.dispatchEvent(new CustomEvent("open-search-filters")), 300);
    }
  };

  return (
    <>
      <div className="h-16 md:hidden" aria-hidden />
      <nav className="md:hidden fixed bottom-0 inset-x-0 z-40 bg-card/95 backdrop-blur border-t border-border shadow-[0_-4px_20px_rgba(0,0,0,0.06)]">
        <ul className="grid grid-cols-5">
          {items.map((it) => {
            const Icon = it.icon;
            const active = it.match?.(pathname) ?? false;
            const accountTo = user ? "/dashboard" : "/login";
            const to = it.label === "Account" ? accountTo : it.to;

            if (it.action === "filters" || it.action === "wishlist") {
              const handler = it.action === "filters"
                ? openFilters
                : () => window.dispatchEvent(new CustomEvent("open-wishlist"));
              return (
                <li key={it.label}>
                  <button
                    type="button"
                    onClick={handler}
                    className="w-full flex flex-col items-center justify-center gap-0.5 py-2 text-[10px] font-medium text-muted-foreground active:scale-95 transition"
                  >
                    <Icon className="h-5 w-5" />
                    {it.label}
                  </button>
                </li>
              );
            }

            return (
              <li key={it.label}>
                <Link
                  to={to}
                  search={it.label === "Search" ? { q: "" } : undefined}
                  className={`flex flex-col items-center justify-center gap-0.5 py-2 text-[10px] font-medium transition active:scale-95 ${
                    active ? "text-primary" : "text-muted-foreground"
                  } ${it.highlight ? "text-accent" : ""}`}
                >
                  {it.highlight ? (
                    <span className="-mt-5 mb-0.5 flex h-11 w-11 items-center justify-center rounded-full bg-accent text-accent-foreground shadow-lg shadow-accent/30">
                      <Icon className="h-5 w-5" />
                    </span>
                  ) : (
                    <Icon className="h-5 w-5" />
                  )}
                  {it.label}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>
    </>
  );
}
