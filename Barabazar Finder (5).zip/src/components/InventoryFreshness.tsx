import { Clock, ShieldCheck, Activity } from "lucide-react";
import { freshnessLabel } from "@/lib/format";
import { lastActiveLabel, type TrustShop } from "@/lib/trust";

export function InventoryFreshness({
  updatedAt,
  shop,
  compact = false,
}: {
  updatedAt?: string | null;
  shop?: TrustShop | null;
  compact?: boolean;
}) {
  const updated = updatedAt ? freshnessLabel(updatedAt) : null;
  const verifiedToday = updatedAt
    ? (Date.now() - new Date(updatedAt).getTime()) < 36 * 60 * 60 * 1000
    : false;

  const chips: { icon: typeof Clock; text: string; ok: boolean }[] = [];
  if (updated) chips.push({ icon: Clock, text: `Updated ${updated.toLowerCase()}`, ok: true });
  if (verifiedToday) chips.push({ icon: ShieldCheck, text: "Stock verified today", ok: true });
  if (shop) chips.push({ icon: Activity, text: lastActiveLabel(shop), ok: true });

  if (chips.length === 0) return null;

  if (compact) {
    return (
      <div className="flex flex-wrap gap-x-3 gap-y-1 text-[11px] text-muted-foreground">
        {chips.map((c, i) => (
          <span key={i} className="inline-flex items-center gap-1">
            <c.icon className="h-3 w-3 text-emerald-600" />
            {c.text}
          </span>
        ))}
      </div>
    );
  }

  return (
    <div className="flex flex-wrap gap-2">
      {chips.map((c, i) => (
        <span
          key={i}
          className="inline-flex items-center gap-1.5 rounded-full border border-emerald-500/30 bg-emerald-500/10 px-2.5 py-1 text-xs font-medium text-emerald-700 dark:text-emerald-400"
        >
          <c.icon className="h-3.5 w-3.5" />
          {c.text}
        </span>
      ))}
    </div>
  );
}
