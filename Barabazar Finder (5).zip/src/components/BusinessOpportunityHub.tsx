import { Link } from "@tanstack/react-router";
import { ArrowRight, Store, Truck, Handshake, Briefcase } from "lucide-react";
import { FadeIn, StaggerGrid, StaggerItem } from "@/components/motion/FadeIn";

const TILES = [
  { to: "/franchise-opportunities", icon: Store, title: "Franchise Opportunities", desc: "Food, fashion, education, pharmacy & more", grad: "from-orange-500 to-pink-500" },
  { to: "/distributor-opportunities", icon: Truck, title: "Distributor Opportunities", desc: "FMCG, electrical, hardware, packaging", grad: "from-sky-500 to-indigo-500" },
  { to: "/dealer-opportunities", icon: Handshake, title: "Dealer Opportunities", desc: "Apply online · territory & margin info", grad: "from-emerald-500 to-teal-500" },
  { to: "/brands", icon: Briefcase, title: "Verified Brands", desc: "Browse partner brands across India", grad: "from-purple-500 to-fuchsia-500" },
] as const;

export function BusinessOpportunityHub() {
  return (
    <section className="container mx-auto px-4 py-10">
      <FadeIn>
        <div className="flex items-end justify-between gap-3 mb-5">
          <div>
            <span className="inline-flex items-center rounded-full bg-accent/15 text-accent-foreground px-3 py-1 text-xs font-semibold">Business Opportunities</span>
            <h2 className="font-display text-2xl sm:text-3xl mt-2">Start your business with India's top brands</h2>
            <p className="text-sm text-muted-foreground mt-1">Franchise · Distributor · Dealer · Super Stockist · C&F Agent</p>
          </div>
          <Link to="/opportunities" className="hidden sm:inline-flex items-center text-sm font-semibold text-primary hover:underline">
            View all <ArrowRight className="h-4 w-4 ml-1" />
          </Link>
        </div>
      </FadeIn>
      <StaggerGrid className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {TILES.map((t) => {
          const Icon = t.icon;
          return (
            <StaggerItem key={t.to}>
              <Link to={t.to} className="group relative block rounded-2xl overflow-hidden ring-1 ring-border hover:ring-primary/40 transition-all shadow-float h-full">
                <div className={`bg-gradient-to-br ${t.grad} p-5 h-full text-white`}>
                  <Icon className="h-8 w-8 mb-3" />
                  <div className="font-display text-lg leading-tight">{t.title}</div>
                  <p className="text-xs/relaxed opacity-90 mt-1">{t.desc}</p>
                  <span className="mt-3 inline-flex items-center text-xs font-semibold opacity-95 group-hover:translate-x-1 transition-transform">
                    Explore <ArrowRight className="h-3.5 w-3.5 ml-1" />
                  </span>
                </div>
              </Link>
            </StaggerItem>
          );
        })}
      </StaggerGrid>
    </section>
  );
}
