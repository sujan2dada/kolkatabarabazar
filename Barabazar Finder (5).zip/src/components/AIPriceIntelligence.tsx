import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { motion } from "framer-motion";
import { Sparkles, TrendingDown, TrendingUp, Check, Loader2 } from "lucide-react";
import { aiPriceIntel } from "@/lib/ai.functions";

export function AIPriceIntelligence({
  productName,
  category,
  bestPrice,
  offerCount,
}: {
  productName: string;
  category?: string;
  bestPrice: number;
  offerCount: number;
}) {
  const fn = useServerFn(aiPriceIntel);
  const { data, isLoading, isError } = useQuery({
    queryKey: ["ai-price", productName, bestPrice, offerCount],
    queryFn: () => fn({ data: { productName, category, bestPrice, offerCount } }),
    enabled: !!productName && bestPrice > 0,
    staleTime: 1000 * 60 * 60,
    retry: false,
  });

  const tone =
    data?.assessment === "below_market"
      ? { label: "Below market", cls: "bg-success/15 text-success", icon: <TrendingDown className="h-3.5 w-3.5" /> }
      : data?.assessment === "above_market"
      ? { label: "Above market", cls: "bg-discount/15 text-discount", icon: <TrendingUp className="h-3.5 w-3.5" /> }
      : { label: "Fair price", cls: "bg-primary/15 text-primary", icon: <Check className="h-3.5 w-3.5" /> };

  return (
    <motion.div
      initial={{ opacity: 0, y: 6 }}
      animate={{ opacity: 1, y: 0 }}
      className="rounded-2xl border border-border bg-gradient-to-br from-primary/5 via-card to-accent/5 p-4 sm:p-5"
    >
      <div className="flex items-center justify-between gap-2 mb-2">
        <div className="inline-flex items-center gap-1.5 text-xs font-semibold text-primary">
          <Sparkles className="h-3.5 w-3.5" /> AI Price Intelligence
        </div>
        {data && (
          <span className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px] font-medium ${tone.cls}`}>
            {tone.icon}{tone.label}
          </span>
        )}
      </div>

      {isLoading && (
        <div className="flex items-center gap-2 text-sm text-muted-foreground py-2">
          <Loader2 className="h-4 w-4 animate-spin" /> Analyzing market…
        </div>
      )}

      {isError && (
        <div className="text-xs text-muted-foreground">Price intelligence unavailable right now.</div>
      )}

      {data && (
        <>
          <div className="flex items-baseline gap-2">
            <div className="text-xs uppercase tracking-wider text-muted-foreground">Market price</div>
            <div className="font-display text-2xl text-foreground">
              ₹{data.market_min}<span className="text-muted-foreground text-base">–</span>₹{data.market_max}
            </div>
          </div>
          <div className="mt-1 text-xs text-muted-foreground">
            Fair buy: <span className="font-semibold text-foreground">₹{data.fair_price}</span> · Best on platform: <span className="font-semibold text-primary">₹{bestPrice.toFixed(0)}</span>
          </div>
          <p className="mt-2 text-sm text-foreground/80">{data.commentary}</p>
        </>
      )}
    </motion.div>
  );
}
