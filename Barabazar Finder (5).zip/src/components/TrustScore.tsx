import { ShieldCheck } from "lucide-react";
import { trustScore, trustTier, type TrustShop } from "@/lib/trust";

export function TrustScoreBadge({ shop, size = "md" }: { shop: TrustShop; size?: "sm" | "md" | "lg" }) {
  const score = trustScore(shop);
  const tier = trustTier(score);
  if (size === "sm") {
    return (
      <span className={`inline-flex items-center gap-1 rounded-full border text-[10px] font-bold px-1.5 py-0.5 ${tier.cls}`} title={`Trust score ${score}/100 · ${tier.label}`}>
        <ShieldCheck className="h-3 w-3" />{score}
      </span>
    );
  }
  if (size === "lg") {
    return (
      <div className={`inline-flex flex-col items-center justify-center rounded-2xl border px-4 py-3 ${tier.cls}`}>
        <ShieldCheck className="h-5 w-5 mb-1" />
        <div className="font-display text-2xl leading-none">{score}<span className="text-xs opacity-70">/100</span></div>
        <div className="text-[10px] uppercase tracking-wider mt-1">{tier.label}</div>
      </div>
    );
  }
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full border text-xs font-semibold px-2.5 py-1 ${tier.cls}`} title={`Trust score ${score}/100`}>
      <ShieldCheck className="h-3.5 w-3.5" />Trust {score}/100
    </span>
  );
}

export function TrustScoreRing({ shop }: { shop: TrustShop }) {
  const score = trustScore(shop);
  const tier = trustTier(score);
  const r = 28;
  const c = 2 * Math.PI * r;
  const offset = c - (score / 100) * c;
  return (
    <div className="relative inline-flex items-center justify-center">
      <svg width="72" height="72" viewBox="0 0 72 72">
        <circle cx="36" cy="36" r={r} fill="none" stroke="currentColor" strokeOpacity="0.15" strokeWidth="6" />
        <circle cx="36" cy="36" r={r} fill="none" stroke="currentColor" strokeWidth="6" strokeLinecap="round"
          strokeDasharray={c} strokeDashoffset={offset} transform="rotate(-90 36 36)" className="text-emerald-500" />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <div className="font-display text-lg leading-none text-foreground">{score}</div>
        <div className="text-[8px] uppercase tracking-wider text-muted-foreground">{tier.label}</div>
      </div>
    </div>
  );
}
