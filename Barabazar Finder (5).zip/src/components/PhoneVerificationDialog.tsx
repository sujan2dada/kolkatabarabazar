import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { ShieldCheck, MessageCircle, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { sendPhoneOtp, verifyPhoneOtp } from "@/lib/phone-verification.functions";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

type Props = {
  shopId?: string;
  defaultPhone?: string;
  trigger?: React.ReactNode;
  onVerified?: (phone: string) => void;
};

export function PhoneVerificationDialog({ shopId, defaultPhone, trigger, onVerified }: Props) {
  const send = useServerFn(sendPhoneOtp);
  const verify = useServerFn(verifyPhoneOtp);
  const [open, setOpen] = useState(false);
  const [phone, setPhone] = useState(defaultPhone ?? "");
  const [code, setCode] = useState("");
  const [step, setStep] = useState<"phone" | "code">("phone");
  const [waUrl, setWaUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const reset = () => {
    setStep("phone");
    setCode("");
    setWaUrl(null);
  };

  const onSend = async () => {
    setLoading(true);
    try {
      const res = await send({ data: { phone, shopId } });
      setWaUrl(res.whatsappUrl);
      setStep("code");
      toast.success("Code generated. Send it to your phone via WhatsApp.");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Could not send code");
    } finally {
      setLoading(false);
    }
  };

  const onVerify = async () => {
    setLoading(true);
    try {
      await verify({ data: { phone, code, shopId } });
      toast.success("Phone verified ✓");
      onVerified?.(phone);
      setOpen(false);
      reset();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Verification failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) reset(); }}>
      <DialogTrigger asChild>
        {trigger ?? (
          <Button size="sm" variant="outline">
            <ShieldCheck className="h-4 w-4 mr-1" /> Verify mobile
          </Button>
        )}
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Verify your mobile number</DialogTitle>
          <DialogDescription>
            We'll generate a 6-digit OTP. Send it to your phone via WhatsApp, then enter it here to mark this number as verified.
          </DialogDescription>
        </DialogHeader>

        {step === "phone" ? (
          <div className="space-y-3">
            <Label htmlFor="vphone">Mobile number (with country code)</Label>
            <Input
              id="vphone"
              placeholder="+919876543210"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              inputMode="tel"
            />
            <Button onClick={onSend} disabled={loading || phone.length < 10} className="w-full">
              {loading ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <MessageCircle className="h-4 w-4 mr-2" />}
              Generate code
            </Button>
          </div>
        ) : (
          <div className="space-y-3">
            <div className="rounded-lg border border-border bg-muted/40 p-3 text-sm">
              <p className="font-medium">Step 1 — Send the code to your phone</p>
              <p className="text-muted-foreground mt-1">Open WhatsApp and send the prefilled message to <span className="font-mono">{phone}</span>.</p>
              {waUrl && (
                <Button asChild size="sm" variant="outline" className="mt-2">
                  <a href={waUrl} target="_blank" rel="noreferrer">
                    <MessageCircle className="h-4 w-4 mr-1" /> Open WhatsApp
                  </a>
                </Button>
              )}
            </div>
            <Label htmlFor="vcode">Step 2 — Enter the 6-digit code</Label>
            <Input
              id="vcode"
              value={code}
              onChange={(e) => setCode(e.target.value.replace(/[^0-9]/g, "").slice(0, 6))}
              placeholder="123456"
              inputMode="numeric"
              maxLength={6}
              className="text-center tracking-widest text-lg font-mono"
            />
            <div className="flex gap-2">
              <Button variant="ghost" onClick={reset} className="flex-1">Back</Button>
              <Button onClick={onVerify} disabled={loading || code.length !== 6} className="flex-1">
                {loading ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <ShieldCheck className="h-4 w-4 mr-2" />}
                Verify
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
