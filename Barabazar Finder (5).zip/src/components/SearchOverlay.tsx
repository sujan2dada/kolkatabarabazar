import { useState, useEffect, useMemo, type FormEvent } from "react";
import { useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Search, TrendingUp, Flame, X, ArrowRight, Package, Tag, FolderOpen, MapPin, Store, Loader2 } from "lucide-react";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { supabase } from "@/integrations/supabase/client";

const TRENDING = [
  "Mobile covers",
  "Cotton t-shirts",
  "Bluetooth earbuds",
  "Bedsheets",
  "Kurti lot",
  "Power banks",
  "Steel utensils",
  "Footwear surplus",
];

function useDebounced<T>(value: T, ms = 200) {
  const [v, setV] = useState(value);
  useEffect(() => {
    const t = setTimeout(() => setV(value), ms);
    return () => clearTimeout(t);
  }, [value, ms]);
  return v;
}

export function SearchOverlay({ open, onOpenChange }: { open: boolean; onOpenChange: (o: boolean) => void }) {
  const navigate = useNavigate();
  const [q, setQ] = useState("");
  const debouncedQ = useDebounced(q.trim(), 200);
  const isSearching = debouncedQ.length >= 2;

  useEffect(() => {
    if (!open) setQ("");
  }, [open]);

  const { data: popular } = useQuery({
    queryKey: ["popular-products-overlay"],
    enabled: open && !isSearching,
    queryFn: async () => {
      const { data } = await supabase
        .from("shop_products")
        .select("id, price, mrp, product:products(name, slug, image_url, category:categories(name))")
        .order("updated_at", { ascending: false })
        .limit(8);
      return data ?? [];
    },
  });

  const { data: suggestions, isFetching } = useQuery({
    queryKey: ["search-suggest", debouncedQ],
    enabled: open && isSearching,
    queryFn: async () => {
      const like = `%${debouncedQ}%`;
      const [productsRes, brandsRes, categoriesRes, areasRes, shopsRes] = await Promise.all([
        supabase
          .from("products")
          .select("id, name, slug, image_url, category:categories(name)")
          .ilike("name", like)
          .limit(6),
        supabase
          .from("brands")
          .select("id, name, slug, logo_url, category")
          .ilike("name", like)
          .limit(4),
        supabase
          .from("categories")
          .select("id, name, slug, icon")
          .ilike("name", like)
          .limit(4),
        supabase
          .from("shops")
          .select("area")
          .ilike("area", like)
          .eq("approved", true)
          .not("area", "is", null)
          .limit(20),
        supabase
          .from("shops")
          .select("id, name, slug, area, verified")
          .or(`name.ilike.${like},area.ilike.${like}`)
          .eq("approved", true)
          .limit(4),
      ]);
      const areas = Array.from(new Set((areasRes.data ?? []).map((r: any) => r.area).filter(Boolean))).slice(0, 4);
      return {
        products: productsRes.data ?? [],
        brands: brandsRes.data ?? [],
        categories: categoriesRes.data ?? [],
        areas,
        shops: shopsRes.data ?? [],
      };
    },
  });

  const totalResults = useMemo(() => {
    if (!suggestions) return 0;
    return suggestions.products.length + suggestions.brands.length + suggestions.categories.length + suggestions.areas.length + suggestions.shops.length;
  }, [suggestions]);

  const close = () => onOpenChange(false);

  const submit = (e: FormEvent) => {
    e.preventDefault();
    if (!q.trim()) return;
    close();
    navigate({ to: "/search", search: { q: q.trim() } });
  };

  const goSearch = (term: string) => {
    close();
    navigate({ to: "/search", search: { q: term } });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl p-0 gap-0 top-[8%] translate-y-0 max-h-[85vh] overflow-hidden flex flex-col">
        <DialogTitle className="sr-only">Search</DialogTitle>

        <form onSubmit={submit} className="flex items-center gap-2 border-b border-border p-3">
          <Search className="h-5 w-5 text-primary shrink-0 ml-1" />
          <input
            autoFocus
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search products, brands, categories, cities…"
            className="flex-1 bg-transparent text-base outline-none placeholder:text-muted-foreground"
          />
          {isFetching && isSearching && <Loader2 className="h-4 w-4 text-muted-foreground animate-spin" />}
          {q && (
            <button type="button" onClick={() => setQ("")} className="text-muted-foreground hover:text-foreground" aria-label="Clear">
              <X className="h-4 w-4" />
            </button>
          )}
          <Button type="submit" size="sm" className="rounded-full">Search</Button>
        </form>

        <div className="overflow-y-auto px-4 py-4 space-y-5">
          {isSearching ? (
            <SuggestionsPanel
              q={debouncedQ}
              data={suggestions}
              loading={isFetching && !suggestions}
              total={totalResults}
              onClose={close}
              onGoSearch={goSearch}
            />
          ) : (
            <>
              <section>
                <div className="flex items-center gap-2 mb-2">
                  <TrendingUp className="h-4 w-4 text-primary" />
                  <h3 className="text-xs uppercase tracking-wider font-semibold text-muted-foreground">Trending searches</h3>
                </div>
                <div className="flex flex-wrap gap-2">
                  {TRENDING.map((t) => (
                    <button
                      key={t}
                      onClick={() => goSearch(t)}
                      className="rounded-full border border-border bg-secondary px-3 py-1.5 text-sm hover:border-primary/50 hover:text-primary transition-colors"
                    >
                      {t}
                    </button>
                  ))}
                </div>
              </section>

              <section>
                <div className="flex items-center gap-2 mb-2">
                  <Flame className="h-4 w-4 text-accent" />
                  <h3 className="text-xs uppercase tracking-wider font-semibold text-muted-foreground">Popular products</h3>
                </div>
                {!popular ? (
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {Array.from({ length: 8 }).map((_, i) => (
                      <Skeleton key={i} className="aspect-square rounded-xl" />
                    ))}
                  </div>
                ) : popular.length === 0 ? (
                  <p className="text-sm text-muted-foreground">No products yet.</p>
                ) : (
                  <ul className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {popular.map((p: any) => {
                      const off = p.mrp && p.mrp > p.price ? Math.round(((p.mrp - p.price) / p.mrp) * 100) : 0;
                      return (
                        <li key={p.id}>
                          <button
                            onClick={() => {
                              close();
                              navigate({ to: "/product/$slug", params: { slug: p.product?.slug ?? "" } });
                            }}
                            className="group w-full text-left rounded-xl border border-border bg-card overflow-hidden hover:border-primary/50 hover:shadow-md transition-all"
                          >
                            <div className="aspect-square bg-muted relative overflow-hidden">
                              {p.product?.image_url ? (
                                <img src={p.product.image_url} alt={p.product?.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                              ) : (
                                <div className="w-full h-full flex items-center justify-center text-muted-foreground text-xs">No image</div>
                              )}
                              {off > 0 && (
                                <span className="absolute top-1.5 left-1.5 rounded-full bg-discount text-discount-foreground text-[10px] font-bold px-2 py-0.5">
                                  {off}% OFF
                                </span>
                              )}
                            </div>
                            <div className="p-2">
                              <div className="text-xs font-medium line-clamp-1">{p.product?.name}</div>
                              <div className="text-sm font-display text-primary">₹{Number(p.price).toFixed(0)}</div>
                            </div>
                          </button>
                        </li>
                      );
                    })}
                  </ul>
                )}
              </section>

              <button
                onClick={() => { close(); navigate({ to: "/search", search: { q: "" } }); }}
                className="w-full flex items-center justify-center gap-1 text-sm text-primary hover:text-primary/80 py-2"
              >
                Browse all stock <ArrowRight className="h-3.5 w-3.5" />
              </button>
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

function GroupHeader({ icon: Icon, label }: { icon: any; label: string }) {
  return (
    <div className="flex items-center gap-1.5 px-1 mb-1.5">
      <Icon className="h-3.5 w-3.5 text-muted-foreground" />
      <h4 className="text-[11px] uppercase tracking-wider font-semibold text-muted-foreground">{label}</h4>
    </div>
  );
}

function Row({ children, onClick }: { children: React.ReactNode; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="w-full flex items-center gap-3 px-2 py-2 rounded-lg hover:bg-secondary text-left transition-colors"
    >
      {children}
    </button>
  );
}

function SuggestionsPanel({
  q,
  data,
  loading,
  total,
  onClose,
  onGoSearch,
}: {
  q: string;
  data: any;
  loading: boolean;
  total: number;
  onClose: () => void;
  onGoSearch: (term: string) => void;
}) {
  const navigate = useNavigate();

  if (loading) {
    return (
      <div className="space-y-2">
        {Array.from({ length: 6 }).map((_, i) => (
          <div key={i} className="flex items-center gap-3 px-2 py-2">
            <Skeleton className="h-10 w-10 rounded-lg" />
            <div className="flex-1 space-y-1.5">
              <Skeleton className="h-3 w-1/2" />
              <Skeleton className="h-2.5 w-1/3" />
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (!data || total === 0) {
    return (
      <div className="text-center py-10">
        <p className="text-sm text-muted-foreground">No matches for "{q}"</p>
        <Button onClick={() => onGoSearch(q)} variant="outline" size="sm" className="mt-3 rounded-full">
          Search all stock for "{q}"
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {data.products.length > 0 && (
        <section>
          <GroupHeader icon={Package} label="Products" />
          <div className="space-y-0.5">
            {data.products.map((p: any) => (
              <Row key={p.id} onClick={() => { onClose(); navigate({ to: "/product/$slug", params: { slug: p.slug } }); }}>
                <div className="h-10 w-10 rounded-lg bg-muted overflow-hidden shrink-0">
                  {p.image_url ? <img src={p.image_url} alt="" className="h-full w-full object-cover" /> : <div className="h-full w-full" />}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="text-sm font-medium truncate">{p.name}</div>
                  {p.category?.name && <div className="text-xs text-muted-foreground truncate">in {p.category.name}</div>}
                </div>
              </Row>
            ))}
          </div>
        </section>
      )}

      {data.brands.length > 0 && (
        <section>
          <GroupHeader icon={Tag} label="Brands" />
          <div className="space-y-0.5">
            {data.brands.map((b: any) => (
              <Row key={b.id} onClick={() => { onClose(); navigate({ to: "/brand/$slug", params: { slug: b.slug } }); }}>
                <div className="h-10 w-10 rounded-lg bg-muted overflow-hidden shrink-0 flex items-center justify-center text-xs font-semibold">
                  {b.logo_url ? <img src={b.logo_url} alt="" className="h-full w-full object-cover" /> : b.name.slice(0, 2).toUpperCase()}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="text-sm font-medium truncate">{b.name}</div>
                  {b.category && <div className="text-xs text-muted-foreground truncate">{b.category}</div>}
                </div>
              </Row>
            ))}
          </div>
        </section>
      )}

      {data.categories.length > 0 && (
        <section>
          <GroupHeader icon={FolderOpen} label="Categories" />
          <div className="flex flex-wrap gap-2">
            {data.categories.map((c: any) => (
              <button
                key={c.id}
                onClick={() => onGoSearch(c.name)}
                className="rounded-full border border-border bg-secondary px-3 py-1.5 text-sm hover:border-primary/50 hover:text-primary"
              >
                <span className="mr-1">{c.icon}</span>{c.name}
              </button>
            ))}
          </div>
        </section>
      )}

      {data.areas.length > 0 && (
        <section>
          <GroupHeader icon={MapPin} label="Cities & areas" />
          <div className="flex flex-wrap gap-2">
            {data.areas.map((a: string) => (
              <button
                key={a}
                onClick={() => onGoSearch(a)}
                className="rounded-full border border-border bg-secondary px-3 py-1.5 text-sm hover:border-primary/50 hover:text-primary"
              >
                {a}
              </button>
            ))}
          </div>
        </section>
      )}

      {data.shops.length > 0 && (
        <section>
          <GroupHeader icon={Store} label="Suppliers" />
          <div className="space-y-0.5">
            {data.shops.map((s: any) => (
              <Row key={s.id} onClick={() => { onClose(); navigate({ to: "/shop/$slug", params: { slug: s.slug } }); }}>
                <div className="h-10 w-10 rounded-lg bg-primary/10 text-primary flex items-center justify-center shrink-0">
                  <Store className="h-4 w-4" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="text-sm font-medium truncate flex items-center gap-1.5">
                    {s.name}
                    {s.verified && <span className="text-[10px] rounded-full bg-primary/10 text-primary px-1.5 py-0.5">Verified</span>}
                  </div>
                  {s.area && <div className="text-xs text-muted-foreground truncate">{s.area}</div>}
                </div>
              </Row>
            ))}
          </div>
        </section>
      )}

      <button
        onClick={() => onGoSearch(q)}
        className="w-full flex items-center justify-center gap-1 text-sm text-primary hover:text-primary/80 py-2 border-t border-border pt-3"
      >
        See all results for "{q}" <ArrowRight className="h-3.5 w-3.5" />
      </button>
    </div>
  );
}
