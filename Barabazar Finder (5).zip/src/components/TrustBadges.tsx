import { BadgeCheck, ShieldCheck, Phone, Warehouse, Trophy, Zap } from "lucide-react";
import type { TrustShop } from "@/lib/trust";

const cls = "inline-flex items-center gap-1 rounded-full border border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 text-[10px] font-semibold px-2 py-0.5";

export function TrustBadges({ shop, compact = false, max }: { shop: TrustShop; compact?: boolean; max?: number }) {
  const items: { key: string; label: string; icon: React.ComponentType<any> }[] = [];
  if (shop.gst_verified) items.push({ key: "gst", label: "GST Verified", icon: ShieldCheck });
  if (shop.mobile_verified) items.push({ key: "mob", label: "Mobile Verified", icon: Phone });
  if (shop.verified) items.push({ key: "v", label: "Business Verified", icon: BadgeCheck });
  if (shop.warehouse_verified || (shop.photos && shop.photos.length > 0)) items.push({ key: "wh", label: "Warehouse Verified", icon: Warehouse });
  if (shop.top_seller) items.push({ key: "top", label: "Top Seller", icon: Trophy });
  if (shop.fast_responder) items.push({ key: "fr", label: "Fast Responder", icon: Zap });

  const list = max ? items.slice(0, max) : items;
  if (list.length === 0) return null;

  return (
    <div className="flex flex-wrap gap-1.5">
      {list.map(({ key, label, icon: Icon }) => (
        <span key={key} className={cls} title={label}>
          <Icon className="h-3 w-3" />
          {compact ? label.replace(" Supplier", "").replace(" Verified", "") : label}
        </span>
      ))}
      {max && items.length > max && (
        <span className="inline-flex items-center rounded-full border border-border bg-secondary text-[10px] font-semibold px-2 py-0.5 text-muted-foreground">
          +{items.length - max}
        </span>
      )}
    </div>
  );
}
