import { useState, useRef, type MouseEvent } from "react";
import { ZoomIn } from "lucide-react";
import { cn } from "@/lib/utils";

export function ProductGallery({ images, alt }: { images: string[]; alt: string }) {
  const [active, setActive] = useState(0);
  const [zoom, setZoom] = useState(false);
  const [pos, setPos] = useState({ x: 50, y: 50 });
  const ref = useRef<HTMLDivElement>(null);

  const onMove = (e: MouseEvent<HTMLDivElement>) => {
    if (!ref.current) return;
    const r = ref.current.getBoundingClientRect();
    const x = ((e.clientX - r.left) / r.width) * 100;
    const y = ((e.clientY - r.top) / r.height) * 100;
    setPos({ x: Math.max(0, Math.min(100, x)), y: Math.max(0, Math.min(100, y)) });
  };

  const src = images[active];

  return (
    <div className="flex gap-3">
      {/* Thumbs (vertical on desktop, horizontal on mobile via order) */}
      <div className="hidden sm:flex flex-col gap-2 w-20 shrink-0">
        {images.map((img, i) => (
          <button
            key={i}
            onClick={() => setActive(i)}
            className={cn(
              "aspect-square rounded-xl overflow-hidden ring-1 transition-all bg-card",
              active === i ? "ring-2 ring-primary shadow-float" : "ring-border hover:ring-primary/50"
            )}
            aria-label={`View image ${i + 1}`}
          >
            <img src={img} alt={`${alt} ${i + 1}`} className="h-full w-full object-cover" />
          </button>
        ))}
      </div>

      <div className="flex-1 min-w-0">
        <div
          ref={ref}
          onMouseEnter={() => setZoom(true)}
          onMouseLeave={() => setZoom(false)}
          onMouseMove={onMove}
          className="relative aspect-square w-full rounded-3xl overflow-hidden bg-card ring-1 ring-border shadow-float cursor-zoom-in group"
        >
          <img
            src={src}
            alt={alt}
            className={cn(
              "h-full w-full object-cover transition-transform duration-200",
              zoom ? "scale-[2]" : "scale-100"
            )}
            style={zoom ? { transformOrigin: `${pos.x}% ${pos.y}%` } : undefined}
          />
          <div className="absolute bottom-3 right-3 rounded-full bg-background/90 backdrop-blur px-3 py-1.5 text-xs flex items-center gap-1 ring-1 ring-border opacity-0 group-hover:opacity-100 transition">
            <ZoomIn className="h-3.5 w-3.5" /> Hover to zoom
          </div>
        </div>

        {/* Mobile thumbnails */}
        <div className="sm:hidden mt-3 flex gap-2 overflow-x-auto snap-x">
          {images.map((img, i) => (
            <button
              key={i}
              onClick={() => setActive(i)}
              className={cn(
                "h-16 w-16 shrink-0 snap-start rounded-lg overflow-hidden ring-1",
                active === i ? "ring-2 ring-primary" : "ring-border"
              )}
            >
              <img src={img} alt={`${alt} ${i + 1}`} className="h-full w-full object-cover" />
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
