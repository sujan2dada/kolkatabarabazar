import { useState, type FormEvent } from "react";
import { Link } from "@tanstack/react-router";
import { useMutation } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { motion, AnimatePresence } from "framer-motion";
import { Sparkles, Loader2, Package, TrendingDown, Users, MessageCircle, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { aiStockMatch } from "@/lib/ai.functions";
import { whatsappUrl } from "@/lib/format";

const SAMPLES = [
  "Need 2000 mobile covers under ₹15",
  "5000 cotton t-shirts size M under ₹80",
  "Looking for 100 kg basmati rice clearance",
];

export function AIStockMatcher() {
  const [q, setQ] = useState("");
  const fn = useServerFn(aiStockMatch);
  const m = useMutation({ mutationFn: (query: string) => fn({ data: { query } }) });

  const onSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!q.trim()) return;
    m.mutate(q.trim());
  };

  const res = m.data;

  return (
    <section className="container mx-auto px-4 py-10">
      <div className="rounded-3xl bg-gradient-to-br from-primary/10 via-card to-accent/10 border border-border p-6 sm:p-8 shadow-float">
        <div className="flex items-center gap-2 mb-2">
          <span className="inline-flex items-center gap-1.5 rounded-full bg-primary/15 text-primary px-3 py-1 text-xs font-semibold">
            <Sparkles className="h-3.5 w-3.5" />AI Stock Matcher
          </span>
          <Badge variant="outline" className="text-[10px]">Beta</Badge>
        </div>
        <h2 className="font-display text-2xl sm:text-3xl">Describe what you need — get instant matches.</h2>
        <p className="text-muted-foreground text-sm mt-1">
          Tell us the product, quantity, and budget in plain English or Hinglish. Our AI finds suppliers, suggests MOQ, and benchmarks price.
        </p>

        <form onSubmit={onSubmit} className="mt-5 flex flex-col sm:flex-row gap-2">
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="e.g. Need 2000 mobile covers under ₹15"
            className="flex-1 rounded-xl bg-background border border-border px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-primary/30"
          />
          <Button type="submit" size="lg" disabled={m.isPending} className="rounded-xl">
            {m.isPending ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Sparkles className="h-4 w-4 mr-2" />}
            Match suppliers
          </Button>
        </form>

        <div className="mt-3 flex flex-wrap gap-2">
          {SAMPLES.map((s) => (
            <button
              key={s}
              type="button"
              onClick={() => { setQ(s); m.mutate(s); }}
              className="text-xs rounded-full border border-border bg-card px-3 py-1.5 hover:border-primary/40 hover:text-primary transition-colors"
            >
              {s}
            </button>
          ))}
        </div>

        {m.isError && (
          <div className="mt-4 rounded-xl bg-destructive/10 text-destructive border border-destructive/30 px-4 py-3 text-sm">
            {(m.error as Error).message}
          </div>
        )}

        <AnimatePresence>
          {res && (
            <motion.div
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="mt-6 space-y-4"
            >
              {/* INSIGHTS */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <Insight icon={<TrendingDown className="h-4 w-4" />} label="Best price" value={res.insights.minPrice ? `₹${res.insights.minPrice}` : "—"} />
                <Insight icon={<Package className="h-4 w-4" />} label="Price range" value={res.insights.minPrice ? `₹${res.insights.minPrice}–₹${res.insights.maxPrice}` : "—"} />
                <Insight icon={<Package className="h-4 w-4" />} label="Suggested MOQ" value={res.insights.suggestedMoq ? `${res.insights.suggestedMoq} units` : "—"} />
                <Insight icon={<Users className="h-4 w-4" />} label="Suppliers" value={`${res.insights.supplierCount}`} />
              </div>

              {/* INTENT SUMMARY */}
              <div className="rounded-xl bg-card border border-border px-4 py-3 text-sm">
                <span className="text-muted-foreground">Understood:</span>{" "}
                <span className="font-medium">{res.intent.normalized_product || "your request"}</span>
                {res.intent.quantity > 0 && <> · <span className="font-medium">{res.intent.quantity} units</span></>}
                {res.intent.max_price > 0 && <> · <span className="font-medium">under ₹{res.intent.max_price}</span></>}
                {res.intent.quantity > 0 && (
                  <span className={`ml-2 inline-flex items-center rounded-full px-2 py-0.5 text-xs ${res.insights.canFulfill ? "bg-success/15 text-success" : "bg-discount/15 text-discount"}`}>
                    {res.insights.canFulfill ? `${res.insights.totalAvailable} units available` : `Only ${res.insights.totalAvailable} in stock`}
                  </span>
                )}
              </div>

              {/* OFFERS */}
              {res.offers.length === 0 ? (
                <div className="rounded-xl border border-dashed border-border p-6 text-center text-sm text-muted-foreground">
                  No matching suppliers yet. Try broadening the budget or product description.
                </div>
              ) : (
                <ul className="grid gap-2">
                  {res.offers.map((o) => (
                    <li key={o.id} className="rounded-xl bg-card border border-border p-3 sm:p-4 flex flex-wrap items-center gap-3">
                      <div className="flex-1 min-w-[200px]">
                        <Link to="/product/$slug" params={{ slug: o.product?.slug ?? "" }} className="font-semibold hover:text-primary">
                          {o.product?.name ?? "Product"}
                        </Link>
                        <div className="text-xs text-muted-foreground">
                          {o.shop?.name} {o.shop?.area && `· ${o.shop.area}`}
                          {o.shop?.verified && <Badge variant="outline" className="ml-1 text-[10px]">Verified</Badge>}
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-display text-xl text-primary">₹{Number(o.price).toFixed(0)}</div>
                        <div className="text-[11px] text-muted-foreground">MOQ {o.moq}</div>
                      </div>
                      {o.shop?.whatsapp && (
                        <Button asChild size="sm" className="bg-whatsapp hover:bg-whatsapp/90 text-white">
                          <a href={whatsappUrl(o.shop.whatsapp, `Hi ${o.shop.name}, I'm interested in ${o.product?.name}.`)} target="_blank" rel="noopener noreferrer">
                            <MessageCircle className="h-3.5 w-3.5 mr-1" />WhatsApp
                          </a>
                        </Button>
                      )}
                      <Button asChild size="sm" variant="outline">
                        <Link to="/shop/$slug" params={{ slug: o.shop?.slug ?? "" }}>
                          View <ArrowRight className="h-3.5 w-3.5 ml-1" />
                        </Link>
                      </Button>
                    </li>
                  ))}
                </ul>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </section>
  );
}

function Insight({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="rounded-xl bg-card border border-border px-3 py-2.5">
      <div className="flex items-center gap-1.5 text-[11px] uppercase tracking-wider text-muted-foreground">
        {icon}{label}
      </div>
      <div className="font-display text-lg text-foreground mt-0.5">{value}</div>
    </div>
  );
}
