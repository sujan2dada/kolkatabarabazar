import { useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { TrendingDown, MessageCircle, Mail, Bell } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";

const CHANNELS = [
  { id: "whatsapp", label: "WhatsApp", icon: MessageCircle },
  { id: "email", label: "Email", icon: Mail },
  { id: "push", label: "Push", icon: Bell },
];

export function PriceAlertButton({
  productId, shopId, currentPrice, productName,
}: { productId: string; shopId?: string | null; currentPrice?: number | null; productName?: string }) {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [target, setTarget] = useState<string>("");
  const [channels, setChannels] = useState<string[]>(["whatsapp", "email"]);
  const [saving, setSaving] = useState(false);

  const { data: existing, refetch } = useQuery({
    enabled: !!user,
    queryKey: ["price-alert", productId, shopId ?? null, user?.id ?? null],
    queryFn: async () => {
      let q = supabase.from("price_alerts").select("id, target_price, alert_channels").eq("user_id", user!.id).eq("product_id", productId);
      q = shopId ? q.eq("shop_id", shopId) : q.is("shop_id", null);
      const { data } = await q.maybeSingle();
      return data;
    },
  });

  const toggle = (id: string) => setChannels((c) => (c.includes(id) ? c.filter((x) => x !== id) : [...c, id]));

  const onClick = () => {
    if (!user) { toast.info("Sign in to get price alerts"); navigate({ to: "/login" }); return; }
    setTarget(existing?.target_price?.toString() ?? (currentPrice ? Math.floor(currentPrice * 0.9).toString() : ""));
    setChannels(existing?.alert_channels?.length ? existing.alert_channels : ["whatsapp", "email"]);
    setOpen(true);
  };

  const save = async () => {
    if (!user) return;
    setSaving(true);
    const payload = {
      user_id: user.id, product_id: productId, shop_id: shopId ?? null,
      target_price: target ? Number(target) : null,
      alert_channels: channels,
    };
    const { error } = existing
      ? await supabase.from("price_alerts").update(payload).eq("id", existing.id)
      : await supabase.from("price_alerts").insert(payload);
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success(`We'll alert you when ${productName ?? "this product"} drops in price`);
    refetch();
    setOpen(false);
  };

  const remove = async () => {
    if (!existing) return;
    const { error } = await supabase.from("price_alerts").delete().eq("id", existing.id);
    if (error) return toast.error(error.message);
    toast.success("Price alert removed");
    refetch();
    setOpen(false);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button type="button" variant={existing ? "default" : "outline"} size="sm" onClick={onClick} className="rounded-full gap-2">
          <TrendingDown className="h-4 w-4" />
          {existing ? "Price alert on" : "Alert me on price drop"}
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Get a price-drop alert</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <Label>Target price (optional)</Label>
            <div className="relative mt-1">
              <span className="absolute inset-y-0 left-3 flex items-center text-muted-foreground">₹</span>
              <Input type="number" inputMode="numeric" value={target} onChange={(e) => setTarget(e.target.value)} className="pl-7" placeholder={currentPrice ? `Currently ₹${currentPrice}` : "Any drop"} />
            </div>
            <p className="text-xs text-muted-foreground mt-1">Leave blank to be alerted on any price drop.</p>
          </div>
          <div className="space-y-2">
            <Label>Notify me via</Label>
            {CHANNELS.map((c) => (
              <label key={c.id} className="flex items-center gap-2 cursor-pointer text-sm">
                <Checkbox checked={channels.includes(c.id)} onCheckedChange={() => toggle(c.id)} />
                <c.icon className="h-4 w-4 text-primary" /> {c.label}
              </label>
            ))}
          </div>
        </div>
        <DialogFooter className="gap-2">
          {existing && <Button variant="ghost" onClick={remove}>Turn off</Button>}
          <Button onClick={save} disabled={saving || channels.length === 0}>{saving ? "Saving…" : existing ? "Update" : "Set alert"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
