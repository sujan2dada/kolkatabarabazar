import { Link } from "@tanstack/react-router";
import { MapPin, TrendingUp, IndianRupee, BadgeCheck } from "lucide-react";
import { OPP_META, formatInvestment, type OpportunityType } from "@/lib/opportunities";

export type OpportunityRow = {
  id: string;
  slug: string;
  title: string;
  type: OpportunityType;
  category: string | null;
  investment_min: number | null;
  investment_max: number | null;
  margin_min: number | null;
  margin_max: number | null;
  territory: string | null;
  image_url: string | null;
  featured: boolean | null;
  brands?: { name: string; slug: string; logo_url: string | null; verified: boolean | null } | null;
};

export function OpportunityCard({ o }: { o: OpportunityRow }) {
  const meta = OPP_META[o.type];
  const Icon = meta.icon;
  return (
    <Link to="/opportunity/$slug" params={{ slug: o.slug }}
      className="group relative block rounded-2xl overflow-hidden bg-card ring-1 ring-border hover:ring-primary/40 transition-all shadow-float">
      <div className={`aspect-[16/9] bg-gradient-to-br ${meta.color} relative overflow-hidden`}>
        {o.image_url ? (
          <img src={o.image_url} alt={o.title} loading="lazy" className="absolute inset-0 h-full w-full object-cover opacity-90 group-hover:scale-105 transition-transform duration-500" />
        ) : null}
        <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent" />
        <span className="absolute top-2 left-2 inline-flex items-center gap-1 rounded-full bg-white/95 text-foreground px-2.5 py-1 text-[11px] font-semibold shadow">
          <Icon className="h-3.5 w-3.5" />{meta.label}
        </span>
        {o.featured && (
          <span className="absolute top-2 right-2 rounded-full bg-accent text-accent-foreground px-2 py-0.5 text-[10px] font-bold">FEATURED</span>
        )}
      </div>
      <div className="p-4">
        <div className="flex items-center gap-1.5">
          <h3 className="font-display text-base text-foreground line-clamp-1">{o.title}</h3>
          {o.brands?.verified && <BadgeCheck className="h-4 w-4 text-primary shrink-0" />}
        </div>
        {o.brands && <div className="text-xs text-muted-foreground">{o.brands.name}{o.category ? ` · ${o.category}` : ""}</div>}
        <div className="mt-2.5 grid grid-cols-2 gap-2 text-xs">
          <div className="rounded-lg bg-secondary px-2 py-1.5">
            <div className="flex items-center gap-1 text-[10px] uppercase tracking-wider text-muted-foreground"><IndianRupee className="h-3 w-3" />Investment</div>
            <div className="font-semibold text-foreground">{formatInvestment(o.investment_min, o.investment_max)}</div>
          </div>
          <div className="rounded-lg bg-secondary px-2 py-1.5">
            <div className="flex items-center gap-1 text-[10px] uppercase tracking-wider text-muted-foreground"><TrendingUp className="h-3 w-3" />Margin</div>
            <div className="font-semibold text-foreground">
              {o.margin_min || o.margin_max ? `${o.margin_min ?? 0}–${o.margin_max ?? o.margin_min}%` : "On request"}
            </div>
          </div>
        </div>
        {o.territory && (
          <div className="mt-2 flex items-center gap-1 text-xs text-muted-foreground">
            <MapPin className="h-3 w-3" />{o.territory}
          </div>
        )}
      </div>
    </Link>
  );
}
