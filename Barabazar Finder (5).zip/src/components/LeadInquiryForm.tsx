import { useState, type FormEvent } from "react";
import { z } from "zod";
import { Loader2, Send, MessageCircle } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { whatsappUrl } from "@/lib/format";

const Schema = z.object({
  name: z.string().trim().min(2).max(100),
  city: z.string().trim().min(2).max(100),
  phone: z.string().trim().regex(/^[0-9+\s-]{7,15}$/, "Enter a valid phone"),
  email: z.string().trim().email().max(200).optional().or(z.literal("")),
  investment_capacity: z.string().trim().max(100).optional(),
  business_experience: z.string().trim().max(500).optional(),
  message: z.string().trim().max(1000).optional(),
});

type Props = {
  opportunityId?: string;
  brandId?: string;
  brandName?: string;
  whatsappNumber?: string;
  title?: string;
  compact?: boolean;
};

export function LeadInquiryForm({ opportunityId, brandId, brandName, whatsappNumber, title, compact }: Props) {
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);

  const onSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const parsed = Schema.safeParse(Object.fromEntries(fd));
    if (!parsed.success) {
      toast.error(parsed.error.issues[0]?.message ?? "Check the form");
      return;
    }
    setBusy(true);
    const { error } = await supabase.from("opportunity_leads").insert({
      opportunity_id: opportunityId ?? null,
      brand_id: brandId ?? null,
      ...parsed.data,
      email: parsed.data.email || null,
    });
    setBusy(false);
    if (error) { toast.error(error.message); return; }
    setDone(true);
    toast.success("Inquiry sent! The brand will contact you shortly.");

    if (whatsappNumber) {
      const msg = `Hi${brandName ? ` ${brandName}` : ""}, I'm interested in the ${title ?? "opportunity"}.\n\nName: ${parsed.data.name}\nCity: ${parsed.data.city}\nPhone: ${parsed.data.phone}\nInvestment: ${parsed.data.investment_capacity || "—"}`;
      window.open(whatsappUrl(whatsappNumber, msg), "_blank", "noopener");
    }
  };

  if (done) {
    return (
      <div className="rounded-2xl border border-emerald-500/30 bg-emerald-500/10 p-6 text-center">
        <div className="font-display text-xl text-emerald-700 dark:text-emerald-400">Thanks! Your inquiry is in.</div>
        <p className="text-sm text-muted-foreground mt-1">A representative will reach out within 24–48 hrs.</p>
      </div>
    );
  }

  const inp = "w-full rounded-xl bg-background border border-border px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-primary/30";

  return (
    <form onSubmit={onSubmit} className="grid gap-3">
      <div className={compact ? "grid gap-3" : "grid sm:grid-cols-2 gap-3"}>
        <input name="name" required placeholder="Your name *" className={inp} maxLength={100} />
        <input name="city" required placeholder="City *" className={inp} maxLength={100} />
        <input name="phone" required placeholder="Phone / WhatsApp *" className={inp} maxLength={15} inputMode="tel" />
        <input name="email" type="email" placeholder="Email (optional)" className={inp} maxLength={200} />
        <input name="investment_capacity" placeholder="Investment capacity (e.g. ₹5–10 L)" className={inp} maxLength={100} />
        <input name="business_experience" placeholder="Years of business experience" className={inp} maxLength={500} />
      </div>
      <textarea name="message" placeholder="Tell us about your interest (optional)" rows={3} className={inp} maxLength={1000} />
      <Button type="submit" disabled={busy} size="lg" className="rounded-xl">
        {busy ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : whatsappNumber ? <MessageCircle className="h-4 w-4 mr-2" /> : <Send className="h-4 w-4 mr-2" />}
        {whatsappNumber ? "Send inquiry + WhatsApp" : "Submit inquiry"}
      </Button>
      <p className="text-[11px] text-muted-foreground text-center">
        By submitting you agree to be contacted by the brand and Kolkatabarabazar.
      </p>
    </form>
  );
}
