import { Link } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Search, LogOut, LayoutDashboard, ShieldCheck, Tag, MapPin, ChevronDown, PackagePlus, Sparkles, Menu, LogIn, Grid3x3, Briefcase, Heart, UserPlus, Store } from "lucide-react";
import { useAuth } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { supabase } from "@/integrations/supabase/client";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

import { SearchOverlay } from "@/components/SearchOverlay";

const LOCATIONS = ["Kolkata", "Howrah", "Burrabazar", "Salt Lake", "New Town", "All India"];

export function SiteHeader() {
  const { user, isAdmin, signOut } = useAuth();
  const [overlayOpen, setOverlayOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeCategory, setActiveCategory] = useState<{ id: string; slug: string; name: string } | null>(null);
  const [location, setLocation] = useState<string>(() => {
    if (typeof window === "undefined") return "Kolkata";
    return localStorage.getItem("kbb_location") ?? "Kolkata";
  });

  const pickLocation = (loc: string) => {
    setLocation(loc);
    if (typeof window !== "undefined") localStorage.setItem("kbb_location", loc);
  };

  const { data: categories } = useQuery({
    queryKey: ["nav-categories-top"],
    enabled: menuOpen,
    queryFn: async () =>
      (await supabase.from("categories").select("id, slug, name, icon").is("parent_id", null).order("name").limit(50)).data ?? [],
  });

  const { data: subcategories, isLoading: subLoading } = useQuery({
    queryKey: ["nav-subcategories", activeCategory?.id],
    enabled: !!activeCategory?.id,
    queryFn: async () =>
      (await supabase.from("categories").select("id, slug, name, icon").eq("parent_id", activeCategory!.id).order("name").limit(200)).data ?? [],
  });

  const closeMenu = () => setMenuOpen(false);

  return (
    <header className="sticky top-0 z-40 border-b border-border/60 bg-background/90 backdrop-blur-md">
      <div className="container mx-auto flex items-center justify-between gap-2 px-3 py-2 sm:gap-3 sm:px-4 sm:py-3">
        <Link to="/" className="flex items-center gap-2 shrink-0">
          <div className="h-9 w-9 sm:h-10 sm:w-10 rounded-2xl bg-gradient-to-br from-primary to-primary/70 flex items-center justify-center text-primary-foreground font-display text-lg sm:text-xl shadow-float">
            K
          </div>
          <div className="leading-tight">
            <div className="font-display sm:text-base text-foreground whitespace-nowrap text-xl text-justify">Kolkatabarabazar<span className="text-accent">.in</span></div>
            <div className="hidden md:block text-[10px] uppercase tracking-[0.18em] text-muted-foreground">Wholesale clearance</div>
          </div>
        </Link>

        {/* Location pill — desktop only */}
        <div className="hidden md:flex flex-1 items-center min-w-0">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="flex items-center gap-1 rounded-full bg-secondary px-3 py-1.5 text-xs font-semibold text-foreground hover:bg-secondary/70 transition shrink-0">
                <MapPin className="h-3.5 w-3.5 text-primary" />
                <span className="max-w-[120px] truncate">{location}</span>
                <ChevronDown className="h-3 w-3 text-muted-foreground" />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="w-48">
              {LOCATIONS.map((loc) => (
                <DropdownMenuItem key={loc} onSelect={() => pickLocation(loc)}>
                  <MapPin className="h-3.5 w-3.5 mr-2 text-primary" />{loc}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        {/* Primary action icons — same on all breakpoints */}
        <div className="flex items-center gap-1.5 shrink-0">
          <Button
            size="icon"
            variant="ghost"
            className="h-9 w-9 rounded-full bg-secondary hover:bg-secondary/70 text-justify"
            aria-label="Search"
            onClick={() => setOverlayOpen(true)}
          >
            <Search className="h-4 w-4 text-primary" />
          </Button>
          <Button
            size="icon"
            variant="ghost"
            className="hidden sm:inline-flex h-9 w-9 rounded-full bg-secondary hover:bg-secondary/70"
            aria-label="Wishlist"
            onClick={() => window.dispatchEvent(new CustomEvent("open-wishlist"))}
          >
            <Heart className="h-4 w-4 text-primary" />
          </Button>
          <Button
            asChild
            size="icon"
            className="h-9 w-9 rounded-full bg-accent text-accent-foreground hover:bg-accent/90"
            aria-label="Post stock"
          >
            <Link to={user ? "/dashboard" : "/signup"}><PackagePlus className="h-4 w-4" /></Link>
          </Button>

          {/* Menu drawer trigger */}
          <Sheet open={menuOpen} onOpenChange={setMenuOpen}>
            <SheetTrigger asChild>
              <Button
                size="icon"
                variant="ghost"
                className="h-9 w-9 rounded-full bg-secondary hover:bg-secondary/70 text-justify"
                aria-label="Menu"
              >
                <Menu className="h-4 w-4 text-primary" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-[88vw] sm:w-[380px] p-0 flex flex-col">
              <SheetHeader className="px-5 py-4 border-b">
                <SheetTitle className="font-display text-lg">Menu</SheetTitle>
              </SheetHeader>

              <div className="flex-1 overflow-y-auto p-4 space-y-5">
                {/* Account */}
                {!user ? (
                  <div className="grid grid-cols-2 gap-2">
                    <Link
                      to="/login"
                      onClick={closeMenu}
                      className="flex items-center justify-center gap-2 h-11 rounded-xl bg-primary text-primary-foreground font-semibold text-sm shadow-float"
                    >
                      <LogIn className="h-4 w-4" /> Login
                    </Link>
                    <Link
                      to="/signup"
                      onClick={closeMenu}
                      className="flex items-center justify-center gap-2 h-11 rounded-xl bg-accent text-accent-foreground font-semibold text-sm shadow-float"
                    >
                      <UserPlus className="h-4 w-4" /> Sign up
                    </Link>
                  </div>
                ) : (
                  <div className="rounded-xl border border-border bg-secondary/50 p-3 flex items-center gap-3">
                    <div className="h-10 w-10 rounded-full bg-primary/15 text-primary flex items-center justify-center font-semibold">
                      {(user.email ?? "U")[0].toUpperCase()}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-medium truncate">{user.email}</div>
                      <div className="text-[11px] text-muted-foreground">Signed in</div>
                    </div>
                    <Button onClick={() => { signOut(); closeMenu(); }} variant="ghost" size="icon" aria-label="Sign out">
                      <LogOut className="h-4 w-4" />
                    </Button>
                  </div>
                )}

                {/* Highlighted action tiles */}
                <div className="grid grid-cols-2 gap-2">
                  <NavTile to="/search" onClick={closeMenu} icon={Grid3x3} label="Categories" tone="primary" />
                  <NavTile to="/opportunities" onClick={closeMenu} icon={Briefcase} label="Opportunities" tone="accent" />
                  <NavTile to="/pricing" onClick={closeMenu} icon={Tag} label="Pricing" tone="primary" />
                  <NavTile to="/find-suppliers" onClick={closeMenu} icon={Sparkles} label="AI Finder" tone="accent" />
                </div>

                {/* Secondary links */}
                <div className="space-y-1">
                  {user && (
                    <>
                      <NavRow to="/dashboard" onClick={closeMenu} icon={LayoutDashboard} label="Dashboard" />
                      <NavRow to="/favorites" onClick={closeMenu} icon={Heart} label="Saved" />
                      {isAdmin && <NavRow to="/admin" onClick={closeMenu} icon={ShieldCheck} label="Admin" />}
                    </>
                  )}
                  <NavRow to="/brands" onClick={closeMenu} icon={Store} label="Top brands" />
                </div>

                {/* Categories */}
                {categories && categories.length > 0 && (
                  <div>
                    <div className="text-[11px] uppercase tracking-[0.18em] text-muted-foreground px-1 mb-2">All Categories ({categories.length})</div>
                    <div className="grid grid-cols-2 gap-1.5">
                      {categories.map((c: any) => (
                        <button
                          key={c.slug}
                          onClick={() => setActiveCategory({ id: c.id, slug: c.slug, name: c.name })}
                          className="flex items-center justify-between gap-2 px-3 py-2 rounded-lg bg-secondary/60 hover:bg-secondary text-sm text-left"
                        >
                          <span className="flex items-center gap-2 min-w-0">
                            <span className="text-base">{c.icon ?? "📦"}</span>
                            <span className="truncate">{c.name}</span>
                          </span>
                          <ChevronDown className="h-3 w-3 -rotate-90 text-muted-foreground shrink-0" />
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Location */}
                <div>
                  <div className="text-[11px] uppercase tracking-[0.18em] text-muted-foreground px-1 mb-2">Location</div>
                  <div className="flex flex-wrap gap-1.5">
                    {LOCATIONS.map((loc) => (
                      <button
                        key={loc}
                        onClick={() => pickLocation(loc)}
                        className={`px-3 py-1.5 rounded-full text-xs font-medium border transition ${
                          location === loc
                            ? "bg-primary text-primary-foreground border-primary"
                            : "bg-background border-border text-muted-foreground hover:border-primary/40"
                        }`}
                      >
                        <MapPin className="inline h-3 w-3 mr-1" />{loc}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
      <SearchOverlay open={overlayOpen} onOpenChange={setOverlayOpen} />

      {/* Subcategory drawer */}
      <Sheet open={!!activeCategory} onOpenChange={(o) => !o && setActiveCategory(null)}>
        <SheetContent side="left" className="w-[88vw] sm:w-[380px] p-0 flex flex-col">
          <SheetHeader className="px-5 py-4 border-b">
            <button
              onClick={() => setActiveCategory(null)}
              className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground mb-1 text-left"
            >
              <ChevronDown className="h-3 w-3 rotate-90" /> Back to all categories
            </button>
            <SheetTitle className="font-display text-lg">{activeCategory?.name}</SheetTitle>
          </SheetHeader>
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {activeCategory && (
              <Link
                to="/search"
                search={{ category: activeCategory.slug } as any}
                onClick={() => { setActiveCategory(null); closeMenu(); }}
                className="flex items-center justify-between px-3 py-2.5 rounded-lg bg-primary/10 text-primary text-sm font-semibold"
              >
                View all in {activeCategory.name}
                <ChevronDown className="h-3 w-3 -rotate-90" />
              </Link>
            )}
            {subLoading && <div className="text-sm text-muted-foreground px-1">Loading…</div>}
            {subcategories && subcategories.length === 0 && !subLoading && (
              <div className="text-sm text-muted-foreground px-1">No subcategories.</div>
            )}
            <div className="grid grid-cols-1 gap-2">
              {subcategories?.map((s: any) => {
                const img = `https://source.unsplash.com/96x96/?${encodeURIComponent(s.name)}`;
                return (
                  <Link
                    key={s.slug}
                    to="/search"
                    search={{ category: s.slug } as any}
                    onClick={() => { setActiveCategory(null); closeMenu(); }}
                    className="flex items-center gap-3 px-3 py-2 rounded-lg bg-secondary/60 hover:bg-secondary text-sm"
                  >
                    <img
                      src={img}
                      alt={s.name}
                      loading="lazy"
                      className="h-11 w-11 rounded-md object-cover bg-muted shrink-0"
                      onError={(e) => {
                        const el = e.currentTarget as HTMLImageElement;
                        el.src = `https://picsum.photos/seed/${encodeURIComponent(s.slug)}/96`;
                      }}
                    />
                    <span className="truncate flex-1 font-medium">{s.name}</span>
                    <ChevronDown className="h-3 w-3 -rotate-90 text-muted-foreground" />
                  </Link>
                );
              })}
            </div>
          </div>
        </SheetContent>
      </Sheet>
    </header>
  );
}

function NavTile({
  to, onClick, icon: Icon, label, tone,
}: { to: string; onClick: () => void; icon: any; label: string; tone: "primary" | "accent" }) {
  const cls = tone === "primary"
    ? "from-primary/15 to-primary/5 text-primary border-primary/30"
    : "from-accent/20 to-accent/5 text-accent-foreground border-accent/40";
  return (
    <Link
      to={to}
      onClick={onClick}
      className={`flex flex-col items-center justify-center gap-1.5 h-20 rounded-xl border bg-gradient-to-br ${cls} font-semibold text-sm transition hover:scale-[1.02]`}
    >
      <Icon className="h-5 w-5" />
      {label}
    </Link>
  );
}

function NavRow({
  to, onClick, icon: Icon, label,
}: { to: string; onClick: () => void; icon: any; label: string }) {
  return (
    <Link
      to={to}
      onClick={onClick}
      className="flex items-center gap-3 px-3 py-2.5 rounded-lg hover:bg-secondary text-sm font-medium"
    >
      <Icon className="h-4 w-4 text-primary" />
      {label}
    </Link>
  );
}
