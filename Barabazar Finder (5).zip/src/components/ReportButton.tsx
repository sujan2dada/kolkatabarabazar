import { useState, type FormEvent } from "react";
import { Flag } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { toast } from "sonner";

export function ReportButton({
  targetType,
  targetId,
}: {
  targetType: "shop" | "product" | "shop_product";
  targetId: string;
}) {
  const { user } = useAuth();
  const [open, setOpen] = useState(false);
  const [reason, setReason] = useState("");
  const [contact, setContact] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (reason.trim().length < 5) { toast.error("Please describe the issue"); return; }
    setBusy(true);
    const { error } = await supabase.from("reports").insert({
      target_type: targetType,
      target_id: targetId,
      reason: reason.trim().slice(0, 500),
      reporter_user_id: user?.id ?? null,
      reporter_contact: contact.trim() || null,
    });
    setBusy(false);
    if (error) toast.error(error.message);
    else { toast.success("Thanks — we'll review it"); setOpen(false); setReason(""); }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="ghost" size="sm" className="text-muted-foreground">
          <Flag className="h-4 w-4 mr-1" />Report
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader><DialogTitle>Report this listing</DialogTitle></DialogHeader>
        <form onSubmit={submit} className="space-y-3">
          <div><Label>What's wrong?</Label><Textarea rows={4} maxLength={500} value={reason} onChange={(e) => setReason(e.target.value)} placeholder="Fake, outdated price, shop closed, etc." required /></div>
          {!user && <div><Label>Your contact (optional)</Label><Input maxLength={120} value={contact} onChange={(e) => setContact(e.target.value)} placeholder="Phone or email" /></div>}
          <Button type="submit" disabled={busy} className="w-full">{busy ? "Sending…" : "Submit report"}</Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
