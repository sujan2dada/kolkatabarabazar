import { ShieldCheck, Phone, MapPin, Clock, Activity, MessageSquare } from "lucide-react";
import { TrustScoreRing } from "./TrustScore";
import { TrustBadges } from "./TrustBadges";
import { lastActiveLabel, responseTimeLabel, type TrustShop } from "@/lib/trust";
import { freshnessLabel } from "@/lib/format";

export function BuyerConfidenceBox({
  shop,
  lastListingUpdate,
  sticky = false,
}: {
  shop: TrustShop & { name?: string; area?: string };
  lastListingUpdate?: string | null;
  sticky?: boolean;
}) {
  const rows: { icon: React.ComponentType<any>; ok: boolean; text: string }[] = [
    { icon: ShieldCheck, ok: !!shop.verified, text: shop.verified ? "Verified supplier" : "Unverified supplier" },
    { icon: Phone, ok: !!(shop.phone || shop.whatsapp), text: shop.mobile_verified ? "Mobile verified · active contact" : (shop.phone || shop.whatsapp) ? "Active contact number" : "No contact on file" },
    { icon: MapPin, ok: shop.lat != null && shop.lng != null, text: shop.lat != null ? "Business location verified" : "Location unverified" },
    { icon: Clock, ok: !!lastListingUpdate, text: lastListingUpdate ? `Stock ${freshnessLabel(lastListingUpdate).toLowerCase()}` : "Stock not updated recently" },
  ];

  return (
    <aside className={`rounded-3xl border border-emerald-500/30 bg-emerald-500/5 p-5 ${sticky ? "lg:sticky lg:top-24" : ""}`}>
      <div className="flex items-center gap-3">
        <TrustScoreRing shop={shop} />
        <div>
          <div className="text-[10px] uppercase tracking-wider text-emerald-700 dark:text-emerald-400 font-semibold">Buy with confidence</div>
          <div className="font-display text-lg leading-tight">{shop.name ?? "This supplier"}</div>
        </div>
      </div>

      <div className="mt-4">
        <TrustBadges shop={shop} />
      </div>

      <ul className="mt-4 space-y-2 text-sm">
        {rows.map((r, i) => (
          <li key={i} className="flex items-start gap-2">
            <r.icon className={`h-4 w-4 mt-0.5 shrink-0 ${r.ok ? "text-emerald-600" : "text-muted-foreground"}`} />
            <span className={r.ok ? "text-foreground" : "text-muted-foreground"}>{r.text}</span>
          </li>
        ))}
      </ul>

      <div className="mt-4 pt-4 border-t border-emerald-500/20">
        <div className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold mb-2">Recent activity</div>
        <ul className="space-y-1.5 text-xs text-muted-foreground">
          <li className="flex items-center gap-2"><Activity className="h-3.5 w-3.5 text-emerald-600" />{lastActiveLabel(shop)}</li>
          {lastListingUpdate && (
            <li className="flex items-center gap-2"><Clock className="h-3.5 w-3.5 text-emerald-600" />Updated inventory {freshnessLabel(lastListingUpdate).toLowerCase()}</li>
          )}
          {shop.avg_response_minutes != null && (
            <li className="flex items-center gap-2"><MessageSquare className="h-3.5 w-3.5 text-emerald-600" />Responds in {responseTimeLabel(shop.avg_response_minutes)}{shop.response_rate ? ` · ${shop.response_rate}% response rate` : ""}</li>
          )}
        </ul>
      </div>
    </aside>
  );
}
