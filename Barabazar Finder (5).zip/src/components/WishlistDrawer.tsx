import { useEffect, useState } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Heart, Store, Bookmark, Bell, TrendingDown, Trash2, ExternalLink, Search as SearchIcon, RefreshCw } from "lucide-react";
import { toast } from "sonner";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { cn } from "@/lib/utils";

interface Props {
  trigger?: React.ReactNode;
  open?: boolean;
  onOpenChange?: (v: boolean) => void;
}

export function WishlistDrawer({ trigger, open: controlledOpen, onOpenChange }: Props) {
  const [internalOpen, setInternalOpen] = useState(false);
  const open = controlledOpen ?? internalOpen;
  const setOpen = onOpenChange ?? setInternalOpen;
  const { user } = useAuth();
  const navigate = useNavigate();
  const qc = useQueryClient();

  // Listen for global "open-wishlist" events from bottom nav, etc.
  useEffect(() => {
    const handler = () => setOpen(true);
    window.addEventListener("open-wishlist", handler);
    return () => window.removeEventListener("open-wishlist", handler);
  }, [setOpen]);

  const enabled = !!user && open;

  const products = useQuery({
    enabled,
    queryKey: ["wishlist", "products", user?.id],
    queryFn: async () => {
      const { data } = await supabase.from("product_favorites")
        .select("id, created_at, product_id, shop_id, products(slug, name, image_url), shops(slug, name)")
        .eq("user_id", user!.id).order("created_at", { ascending: false });
      return data ?? [];
    },
  });

  const suppliers = useQuery({
    enabled,
    queryKey: ["wishlist", "suppliers", user?.id],
    queryFn: async () => {
      const { data } = await supabase.from("favorites")
        .select("id, created_at, shops(id, slug, name, area, verified)")
        .eq("user_id", user!.id).order("created_at", { ascending: false });
      return data ?? [];
    },
  });

  const searches = useQuery({
    enabled,
    queryKey: ["wishlist", "searches", user?.id],
    queryFn: async () => {
      const { data } = await supabase.from("saved_searches")
        .select("*").eq("user_id", user!.id).order("created_at", { ascending: false });
      return data ?? [];
    },
  });

  const alerts = useQuery({
    enabled,
    queryKey: ["wishlist", "alerts", user?.id],
    queryFn: async () => {
      const [stock, price] = await Promise.all([
        supabase.from("stock_alerts").select("id, created_at, alert_channels, products(slug, name, image_url)").eq("user_id", user!.id),
        supabase.from("price_alerts").select("id, created_at, alert_channels, target_price, products(slug, name, image_url)").eq("user_id", user!.id),
      ]);
      return [
        ...(stock.data ?? []).map((r: any) => ({ ...r, kind: "stock" as const })),
        ...(price.data ?? []).map((r: any) => ({ ...r, kind: "price" as const })),
      ].sort((a, b) => (b.created_at ?? "").localeCompare(a.created_at ?? ""));
    },
  });

  const removeFrom = async (table: "product_favorites" | "favorites" | "saved_searches" | "stock_alerts" | "price_alerts", id: string, key: string) => {
    const { error } = await supabase.from(table).delete().eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Removed");
    qc.invalidateQueries({ queryKey: ["wishlist", key, user?.id] });
  };

  const go = (to: string, search?: any) => {
    setOpen(false);
    navigate({ to, search } as any);
  };

  const counts = {
    products: products.data?.length ?? 0,
    suppliers: suppliers.data?.length ?? 0,
    searches: searches.data?.length ?? 0,
    alerts: alerts.data?.length ?? 0,
  };
  const total = counts.products + counts.suppliers + counts.searches + counts.alerts;

  const refreshAll = () => {
    qc.invalidateQueries({ queryKey: ["wishlist"] });
    toast.success("Synced across your devices");
  };

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      {trigger && <SheetTrigger asChild>{trigger}</SheetTrigger>}
      <SheetContent side="right" className="w-[92vw] sm:w-[440px] p-0 flex flex-col">
        <SheetHeader className="px-5 py-4 border-b">
          <div className="flex items-center justify-between gap-3">
            <SheetTitle className="font-display text-lg flex items-center gap-2">
              <Heart className="h-5 w-5 text-primary fill-primary/20" /> My Wishlist
              {total > 0 && <Badge variant="secondary" className="rounded-full">{total}</Badge>}
            </SheetTitle>
            <Button variant="ghost" size="icon" onClick={refreshAll} aria-label="Sync" className="h-8 w-8">
              <RefreshCw className="h-4 w-4" />
            </Button>
          </div>
          <p className="text-[11px] text-muted-foreground text-left">Synced across all your devices</p>
        </SheetHeader>

        {!user ? (
          <div className="flex-1 flex items-center justify-center p-8 text-center">
            <div className="space-y-3">
              <Heart className="h-10 w-10 text-muted-foreground mx-auto" />
              <p className="text-sm text-muted-foreground">Sign in to access your wishlist on every device.</p>
              <Button onClick={() => go("/login")}>Sign in</Button>
            </div>
          </div>
        ) : (
          <Tabs defaultValue="products" className="flex-1 flex flex-col overflow-hidden">
            <TabsList className="mx-4 mt-3 grid grid-cols-4 h-auto">
              <TabsTrigger value="products" className="flex-col gap-0.5 py-1.5 text-[11px]">
                <Heart className="h-3.5 w-3.5" /> Products
                {counts.products > 0 && <span className="text-[10px] text-muted-foreground">{counts.products}</span>}
              </TabsTrigger>
              <TabsTrigger value="suppliers" className="flex-col gap-0.5 py-1.5 text-[11px]">
                <Store className="h-3.5 w-3.5" /> Suppliers
                {counts.suppliers > 0 && <span className="text-[10px] text-muted-foreground">{counts.suppliers}</span>}
              </TabsTrigger>
              <TabsTrigger value="searches" className="flex-col gap-0.5 py-1.5 text-[11px]">
                <Bookmark className="h-3.5 w-3.5" /> Searches
                {counts.searches > 0 && <span className="text-[10px] text-muted-foreground">{counts.searches}</span>}
              </TabsTrigger>
              <TabsTrigger value="alerts" className="flex-col gap-0.5 py-1.5 text-[11px]">
                <Bell className="h-3.5 w-3.5" /> Alerts
                {counts.alerts > 0 && <span className="text-[10px] text-muted-foreground">{counts.alerts}</span>}
              </TabsTrigger>
            </TabsList>

            <div className="flex-1 overflow-y-auto px-4 py-4">
              <TabsContent value="products" className="mt-0 space-y-2">
                {products.data?.length ? products.data.map((f: any) => (
                  <Row
                    key={f.id}
                    image={f.products?.image_url}
                    title={f.products?.name ?? "Product"}
                    subtitle={f.shops?.name ? `at ${f.shops.name}` : "Any supplier"}
                    onClick={() => f.products?.slug && go(`/product/${f.products.slug}`)}
                    onRemove={() => removeFrom("product_favorites", f.id, "products")}
                  />
                )) : <Empty label="No saved products yet" cta="Browse stock" onCta={() => go("/search", { q: "" })} />}
              </TabsContent>

              <TabsContent value="suppliers" className="mt-0 space-y-2">
                {suppliers.data?.length ? suppliers.data.map((f: any) => f.shops && (
                  <Row
                    key={f.id}
                    icon={<Store className="h-5 w-5 text-primary" />}
                    title={
                      <span className="flex items-center gap-1.5">
                        {f.shops.name}
                        {f.shops.verified && <Badge variant="secondary" className="h-4 px-1 text-[9px]">✓</Badge>}
                      </span>
                    }
                    subtitle={f.shops.area ?? ""}
                    onClick={() => go(`/shop/${f.shops.slug}`)}
                    onRemove={() => removeFrom("favorites", f.id, "suppliers")}
                  />
                )) : <Empty label="No saved suppliers yet" cta="Find suppliers" onCta={() => go("/find-suppliers")} />}
              </TabsContent>

              <TabsContent value="searches" className="mt-0 space-y-2">
                {searches.data?.length ? searches.data.map((s: any) => (
                  <Row
                    key={s.id}
                    icon={<SearchIcon className="h-5 w-5 text-primary" />}
                    title={s.name}
                    subtitle={s.query ?? s.category_slug ?? "Saved filters"}
                    chips={s.alert_channels ?? []}
                    onClick={() => go("/search", { q: s.query ?? "", category: s.category_slug ?? undefined })}
                    onRemove={() => removeFrom("saved_searches", s.id, "searches")}
                  />
                )) : <Empty label="No saved searches yet" cta="Start searching" onCta={() => go("/search", { q: "" })} />}
              </TabsContent>

              <TabsContent value="alerts" className="mt-0 space-y-2">
                {alerts.data?.length ? alerts.data.map((a: any) => (
                  <Row
                    key={`${a.kind}-${a.id}`}
                    image={a.products?.image_url}
                    icon={a.kind === "price" ? <TrendingDown className="h-5 w-5 text-accent" /> : <Bell className="h-5 w-5 text-primary" />}
                    title={a.products?.name ?? "Product"}
                    subtitle={a.kind === "price"
                      ? a.target_price ? `Notify under ₹${a.target_price}` : "On any price drop"
                      : "Notify on new stock"}
                    chips={a.alert_channels ?? []}
                    onClick={() => a.products?.slug && go(`/product/${a.products.slug}`)}
                    onRemove={() => removeFrom(a.kind === "price" ? "price_alerts" : "stock_alerts", a.id, "alerts")}
                  />
                )) : <Empty label="No alerts set up yet" cta="Browse products" onCta={() => go("/search", { q: "" })} />}
              </TabsContent>
            </div>
          </Tabs>
        )}
      </SheetContent>
    </Sheet>
  );
}

function Row({
  image, icon, title, subtitle, chips, onClick, onRemove,
}: {
  image?: string | null;
  icon?: React.ReactNode;
  title: React.ReactNode;
  subtitle?: React.ReactNode;
  chips?: string[];
  onClick: () => void;
  onRemove: () => void;
}) {
  return (
    <div className="group flex items-center gap-3 rounded-xl border border-border bg-card p-2.5 hover:border-primary/40 transition">
      <button onClick={onClick} className="flex-1 flex items-center gap-3 min-w-0 text-left">
        <div className="h-12 w-12 rounded-lg bg-secondary flex items-center justify-center overflow-hidden shrink-0">
          {image ? <img src={image} alt="" className="h-full w-full object-cover" /> : icon}
        </div>
        <div className="min-w-0 flex-1">
          <div className="text-sm font-medium text-foreground truncate">{title}</div>
          {subtitle && <div className="text-xs text-muted-foreground truncate">{subtitle}</div>}
          {chips && chips.length > 0 && (
            <div className="mt-1 flex flex-wrap gap-1">
              {chips.map((c) => (
                <span key={c} className="text-[9px] rounded-full bg-secondary px-1.5 py-0.5 text-muted-foreground capitalize">{c}</span>
              ))}
            </div>
          )}
        </div>
        <ExternalLink className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
      </button>
      <Button variant="ghost" size="icon" onClick={onRemove} aria-label="Remove" className="h-8 w-8 shrink-0 text-muted-foreground hover:text-destructive">
        <Trash2 className="h-3.5 w-3.5" />
      </Button>
    </div>
  );
}

function Empty({ label, cta, onCta }: { label: string; cta: string; onCta: () => void }) {
  return (
    <div className={cn("rounded-2xl border-2 border-dashed border-border p-8 text-center")}>
      <p className="text-sm text-muted-foreground mb-3">{label}</p>
      <Button size="sm" onClick={onCta}>{cta}</Button>
    </div>
  );
}
