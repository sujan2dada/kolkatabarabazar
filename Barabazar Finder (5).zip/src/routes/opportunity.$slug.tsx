import { createFileRoute, notFound, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { SiteHeader } from "@/components/SiteHeader";
import { LeadInquiryForm } from "@/components/LeadInquiryForm";
import { FadeIn } from "@/components/motion/FadeIn";
import { IndianRupee, TrendingUp, MapPin, Maximize2, GraduationCap, BadgeCheck, CheckCircle2 } from "lucide-react";
import { OPP_META, formatInvestment, type OpportunityType } from "@/lib/opportunities";

export const Route = createFileRoute("/opportunity/$slug")({
  head: ({ params }) => ({
    meta: [
      { title: `${params.slug} — Business Opportunity | Kolkatabarabazar` },
      { name: "description", content: `Apply online for this verified business opportunity on Kolkatabarabazar.` },
      { rel: "canonical", href: `/opportunity/${params.slug}` },
    ],
  }),
  component: OpportunityPage,
});

function OpportunityPage() {
  const { slug } = Route.useParams();
  const { data: o, isLoading } = useQuery({
    queryKey: ["opp", slug],
    queryFn: async () => {
      const { data } = await supabase.from("opportunities")
        .select("*, brands(id, name, slug, logo_url, verified, description, website)")
        .eq("slug", slug).maybeSingle();
      if (!data) throw notFound();
      return data as any;
    },
  });

  if (isLoading) return <div className="min-h-screen"><SiteHeader /></div>;
  if (!o) return null;

  const meta = OPP_META[o.type as OpportunityType];
  const Icon = meta.icon;

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <section className="container mx-auto px-4 py-8">
        <FadeIn>
          <div className={`rounded-3xl bg-gradient-to-br ${meta.color} text-white p-6 sm:p-8 shadow-float relative overflow-hidden`}>
            {o.image_url && <img src={o.image_url} alt={o.title} className="absolute inset-0 h-full w-full object-cover opacity-30" />}
            <div className="relative">
              <span className="inline-flex items-center gap-1 rounded-full bg-white/95 text-foreground px-3 py-1 text-xs font-semibold">
                <Icon className="h-3.5 w-3.5" />{meta.label}
              </span>
              <h1 className="font-display text-3xl sm:text-4xl mt-3">{o.title}</h1>
              {o.brands && (
                <Link to="/brand/$slug" params={{ slug: o.brands.slug }} className="inline-flex items-center gap-1 mt-2 text-white/95 hover:underline">
                  by {o.brands.name} {o.brands.verified && <BadgeCheck className="h-4 w-4" />}
                </Link>
              )}
            </div>
          </div>
        </FadeIn>

        <div className="grid lg:grid-cols-3 gap-6 mt-6">
          <div className="lg:col-span-2 space-y-5">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <Stat icon={IndianRupee} label="Investment" value={formatInvestment(o.investment_min, o.investment_max)} />
              <Stat icon={TrendingUp} label="Margin" value={o.margin_min || o.margin_max ? `${o.margin_min ?? 0}–${o.margin_max ?? o.margin_min}%` : "On request"} />
              <Stat icon={MapPin} label="Territory" value={o.territory || "PAN India"} />
              <Stat icon={Maximize2} label="Area" value={o.area_required_sqft ? `${o.area_required_sqft} sqft` : "Flexible"} />
            </div>

            {o.description && (
              <div className="rounded-2xl bg-card border border-border p-5">
                <h2 className="font-display text-xl mb-2">About this opportunity</h2>
                <p className="text-sm whitespace-pre-line text-foreground/90">{o.description}</p>
              </div>
            )}

            {o.highlights?.length > 0 && (
              <div className="rounded-2xl bg-card border border-border p-5">
                <h2 className="font-display text-xl mb-3">Highlights</h2>
                <ul className="grid sm:grid-cols-2 gap-2 text-sm">
                  {o.highlights.map((h: string) => (
                    <li key={h} className="flex items-start gap-2"><CheckCircle2 className="h-4 w-4 text-emerald-500 shrink-0 mt-0.5" />{h}</li>
                  ))}
                </ul>
              </div>
            )}

            {o.experience_required && (
              <div className="rounded-2xl bg-card border border-border p-5">
                <div className="flex items-center gap-2"><GraduationCap className="h-4 w-4 text-primary" /><h2 className="font-display text-lg">Experience required</h2></div>
                <p className="text-sm text-muted-foreground mt-1">{o.experience_required}</p>
              </div>
            )}
          </div>

          <aside className="rounded-2xl bg-card border border-border p-5 shadow-float h-fit lg:sticky lg:top-24">
            <h3 className="font-display text-xl">Apply Online</h3>
            <p className="text-sm text-muted-foreground mt-1 mb-4">Get matched with this brand in 24–48 hrs.</p>
            <LeadInquiryForm compact opportunityId={o.id} brandId={o.brand_id} brandName={o.brands?.name} title={o.title} />
          </aside>
        </div>
      </section>
    </div>
  );
}

function Stat({ icon: Icon, label, value }: { icon: any; label: string; value: string }) {
  return (
    <div className="rounded-2xl bg-card border border-border p-3">
      <div className="flex items-center gap-1 text-[10px] uppercase tracking-wider text-muted-foreground"><Icon className="h-3 w-3" />{label}</div>
      <div className="font-display text-base mt-0.5">{value}</div>
    </div>
  );
}
