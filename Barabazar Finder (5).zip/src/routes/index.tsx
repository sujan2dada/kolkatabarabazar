import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useEffect, useRef, useState } from "react";
import { MapPin, BadgeCheck, Clock, Flame, ArrowRight, ArrowLeft, Phone, Mail, Youtube, Facebook, Instagram } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { SiteHeader } from "@/components/SiteHeader";
import { HeroSlider } from "@/components/HeroSlider";
import { Button } from "@/components/ui/button";
import { getRecent, type RecentProduct } from "@/lib/recently-viewed";
import { FadeIn, StaggerGrid, StaggerItem } from "@/components/motion/FadeIn";
import { BusinessOpportunityHub } from "@/components/BusinessOpportunityHub";


import catApparel from "@/assets/cat-apparel.jpg";
import catElectronics from "@/assets/cat-electronics.jpg";
import catHome from "@/assets/cat-home.jpg";
import catGrocery from "@/assets/cat-grocery.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Wholesale Marketplace India — Kolkatabarabazar.in" },
      { name: "description", content: "India's wholesale marketplace for factory surplus, liquidation stock & overstock inventory. Source wholesale apparel, electronics & garments from verified suppliers." },
      { name: "keywords", content: "wholesale marketplace India, factory surplus stock, liquidation stock India, wholesale apparel suppliers, electronics wholesale India, wholesale garments, electronics clearance, liquidation inventory" },
      { property: "og:title", content: "Wholesale Marketplace India — Kolkatabarabazar.in" },
      { property: "og:description", content: "Source factory surplus, overstock & liquidation inventory from verified Indian wholesale suppliers." },
      { property: "og:url", content: "https://kolkatabarabazar.in/" },
    ],
    links: [{ rel: "canonical", href: "https://kolkatabarabazar.in/" }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "FAQPage",
          mainEntity: [
            {
              "@type": "Question",
              name: "What is Kolkatabarabazar.in?",
              acceptedAnswer: { "@type": "Answer", text: "Kolkatabarabazar.in is India's wholesale clearance marketplace connecting buyers with verified suppliers of factory surplus, overstock and liquidation inventory across apparel, electronics, FMCG and more." },
            },
            {
              "@type": "Question",
              name: "How do I buy factory surplus or liquidation stock?",
              acceptedAnswer: { "@type": "Answer", text: "Search for the product or category, compare offers from verified suppliers, and contact them directly via WhatsApp, call or bulk enquiry to negotiate prices and MOQ." },
            },
            {
              "@type": "Question",
              name: "Are the wholesale suppliers verified?",
              acceptedAnswer: { "@type": "Answer", text: "Yes. Suppliers go through GST, mobile and warehouse verification. Every supplier carries a Trust Score so buyers can buy with confidence." },
            },
            {
              "@type": "Question",
              name: "Can I become a distributor or dealer?",
              acceptedAnswer: { "@type": "Answer", text: "Yes — visit /opportunities to explore franchise, distributor and dealer opportunities from top Indian brands." },
            },
          ],
        }),
      },
    ],
  }),
  component: HomePage,
});

const CATEGORY_VISUALS: Record<string, string> = {
  apparel: catApparel,
  clothing: catApparel,
  fashion: catApparel,
  electronics: catElectronics,
  mobile: catElectronics,
  home: catHome,
  kitchen: catHome,
  grocery: catGrocery,
  food: catGrocery,
};

function visualFor(slug: string | null | undefined, idx: number) {
  if (slug) {
    for (const key of Object.keys(CATEGORY_VISUALS)) {
      if (slug.toLowerCase().includes(key)) return CATEGORY_VISUALS[key];
    }
  }
  const fallbacks = [catApparel, catElectronics, catHome, catGrocery];
  return fallbacks[idx % fallbacks.length];
}

function HomePage() {
  const [recent, setRecent] = useState<RecentProduct[]>([]);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => { setRecent(getRecent()); }, []);

  const { data: categories } = useQuery({
    queryKey: ["categories", "top-level"],
    queryFn: async () => {
      const { data } = await supabase
        .from("categories")
        .select("*")
        .is("parent_id", null);
      const ORDER = [
        "Textiles & Fabrics", "Ready-Made Garments", "Jewelry & Fashion Accessories",
        "Bags & Luggage", "Footwear", "Electronics", "Electrical Goods",
        "Hardware & Tools", "Building Materials", "Packaging Materials",
        "Stationery & Office Supplies", "FMCG & Grocery", "Tea, Coffee & Beverages",
        "Home & Kitchen", "Plastic Products", "Chemicals", "Agriculture Products",
        "Automobile Parts", "Machinery & Industrial Equipment", "Printing & Advertising",
        "Gifts & Promotional Items", "Toys & Sports Goods", "Books & Educational Materials",
        "Transport & Logistics", "Business Services",
      ];
      const rank = (n: string) => {
        const i = ORDER.findIndex(o => o.toLowerCase() === n.toLowerCase());
        return i === -1 ? 999 : i;
      };
      return (data ?? [])
        .filter((c: any) => rank(c.name) < 999)
        .sort((a: any, b: any) => rank(a.name) - rank(b.name))
        .slice(0, 25);
    },
  });

  const { data: trendingOffers } = useQuery({
    queryKey: ["trending-offers"],
    queryFn: async () => {
      const { data } = await supabase.from("shop_products")
        .select("id, price, mrp, moq, stock_status, updated_at, products(id, name, slug, image_url), shops(id, name, slug, area, verified, approved, whatsapp, phone)")
        .order("updated_at", { ascending: false }).limit(12);
      return (data ?? []).filter((o: any) => o.shops?.approved);
    },
  });

  const { data: featured } = useQuery({
    queryKey: ["featured-shops"],
    queryFn: async () => {
      const { data } = await supabase.from("shops")
        .select("id, name, slug, description, address, area, phone, verified")
        .eq("approved", true).order("verified", { ascending: false }).limit(6);
      return data ?? [];
    },
  });


  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />

      <h1 className="sr-only">Kolkatabarabazar.in — India's wholesale clearance marketplace for factory surplus, liquidation stock and overstock inventory</h1>

      {/* HERO AUTO-SLIDER */}
      <HeroSlider />


      {/* CATEGORIES HORIZONTAL SCROLL */}
      <section className="container mx-auto px-4 py-12">
        <FadeIn className="flex items-end justify-between mb-6">
          <div>
            <h2 className="font-display text-3xl sm:text-4xl">Browse by category</h2>
            <p className="text-muted-foreground mt-1 text-sm">Swipe to explore live clearance lots</p>
          </div>
          <div className="hidden sm:flex items-center gap-2">
            <button
              onClick={() => scrollRef.current?.scrollBy({ left: -280, behavior: 'smooth' })}
              className="h-9 w-9 rounded-full bg-card ring-1 ring-border flex items-center justify-center hover:bg-secondary transition-colors"
              aria-label="Scroll left"
            >
              <ArrowLeft className="h-4 w-4 text-foreground" />
            </button>
            <button
              onClick={() => scrollRef.current?.scrollBy({ left: 280, behavior: 'smooth' })}
              className="h-9 w-9 rounded-full bg-card ring-1 ring-border flex items-center justify-center hover:bg-secondary transition-colors"
              aria-label="Scroll right"
            >
              <ArrowRight className="h-4 w-4 text-foreground" />
            </button>
          </div>
        </FadeIn>

        <div
          ref={scrollRef}
          className="flex gap-4 overflow-x-auto pb-4 snap-x snap-mandatory scroll-smooth scrollbar-hide"
          style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
        >
          {(categories ?? []).map((c, i) => (
            <Link
              key={c.id}
              to="/search"
              search={{ q: "", category: c.slug }}
              className="group relative flex-shrink-0 w-[140px] sm:w-[160px] snap-start"
            >
              <div className="relative h-[140px] sm:h-[160px] w-full rounded-2xl overflow-hidden ring-1 ring-border bg-card shadow-float transition-all duration-500 hover:ring-2 hover:ring-primary/50 hover:shadow-2xl hover:-translate-y-1">
                <img
                  src={visualFor(c.slug, i)}
                  alt={c.name}
                  loading="lazy"
                  className="absolute inset-0 h-full w-full object-cover transition-transform duration-[1200ms] ease-out group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-foreground/80 via-foreground/25 to-transparent" />
              </div>
              <div className="mt-2.5 text-center">
                <div className="font-display text-sm text-foreground flex items-center justify-center gap-1.5">
                  {c.icon && <span>{c.icon}</span>}
                  <span className="line-clamp-1">{c.name}</span>
                </div>
                <span className="text-[10px] text-muted-foreground">Live lots daily</span>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* TRENDING CLEARANCE PRODUCTS */}
      {trendingOffers && trendingOffers.length > 0 && (
        <section className="container mx-auto px-4 py-10">
          <FadeIn className="flex items-end justify-between mb-5">
            <div>
              <div className="inline-flex items-center gap-1.5 text-xs font-semibold text-discount uppercase tracking-wider"><Flame className="h-3.5 w-3.5" />Trending now</div>
              <h2 className="font-display text-3xl sm:text-4xl mt-1">Fresh liquidation lots</h2>
            </div>
            <Link to="/search" search={{ q: "" }} className="text-sm font-semibold text-primary inline-flex items-center gap-1 hover:gap-2 transition-all">
              See all <ArrowRight className="h-4 w-4" />
            </Link>
          </FadeIn>

          <StaggerGrid className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-3" stagger={0.04}>
            {trendingOffers.slice(0, 12).map((o: any, i) => {
              const img = o.products?.image_url || visualFor(null, i);
              const mrp = o.mrp ? Number(o.mrp) : null;
              const price = Number(o.price);
              const pct = mrp && mrp > price ? Math.round(((mrp - price) / mrp) * 100) : null;
              return (
                <StaggerItem key={o.id}>
                  <Link to="/product/$slug" params={{ slug: o.products.slug }}
                    className="group relative block rounded-2xl overflow-hidden bg-card ring-1 ring-border hover:ring-primary/40 transition-all shadow-float">
                    <div className="aspect-square overflow-hidden bg-secondary">
                      <img src={img} alt={o.products.name} loading="lazy" className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-500" />
                    </div>
                    {pct !== null && (
                      <div className="absolute top-2 left-2 rounded-full bg-discount text-white text-[11px] font-bold px-2 py-0.5 shadow-float">
                        {pct}% OFF
                      </div>
                    )}
                    {o.shops?.verified && (
                      <div className="absolute top-2 right-2 rounded-full glass p-1 shadow-float text-blue-900">
                        <BadgeCheck className="h-3.5 w-3.5 text-primary" />
                      </div>
                    )}
                    <div className="p-3">
                      <div className="font-semibold text-sm text-foreground line-clamp-1">{o.products.name}</div>
                      <div className="text-[11px] text-muted-foreground line-clamp-1">{o.shops.name}{o.shops.area && ` · ${o.shops.area}`}</div>
                      <div className="mt-1.5 flex items-baseline justify-between gap-2">
                        <div className="flex items-baseline gap-1.5">
                          <span className="font-display text-primary text-xl text-black">₹{price.toFixed(0)}</span>
                          {mrp && mrp > price && (
                            <span className="text-[11px] text-muted-foreground line-through">₹{mrp.toFixed(0)}</span>
                          )}
                        </div>
                        <span className="text-[10px] text-muted-foreground">MOQ {o.moq}</span>
                      </div>
                    </div>
                  </Link>
                </StaggerItem>
              );
            })}
          </StaggerGrid>
        </section>
      )}

      {/* TOP STORES */}
      <section className="relative overflow-hidden my-14 mx-4 sm:mx-6 rounded-3xl bg-gradient-to-br from-[#63B0EF] via-[#AFCFF4] to-[#F1D1D8] py-12 px-5 sm:px-10 shadow-2xl">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(214,58,18,0.18),transparent_60%)] pointer-events-none" />
        <FadeIn className="text-center mb-8 relative">
          <h2 className="font-display text-4xl sm:text-5xl text-[#3F3F3F] drop-shadow-[0_2px_8px_rgba(255,255,255,0.4)]">Top brand</h2>
          <p className="text-[#3F3F3F]/75 mt-2 text-sm">Handpicked brands with the hottest clearance offers</p>
        </FadeIn>
        <StaggerGrid className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 gap-5 sm:gap-7 relative" stagger={0.04}>
          {[
            { name: "Nike", logo: "👟", offer: "Min. 40% Off" },
            { name: "Adidas", logo: "⚡", offer: "Under ₹699" },
            { name: "Puma", logo: "🐆", offer: "Up to 50% Off" },
            { name: "Levi's", logo: "👖", offer: "Flat 60% Off" },
            { name: "H&M", logo: "👕", offer: "From ₹299" },
            { name: "Zara", logo: "🛍️", offer: "Up to 70% Off" },
            { name: "boAt", logo: "🎧", offer: "Min. 45% Off" },
            { name: "Apple", logo: "🍎", offer: "Up to 30% Off" },
            { name: "Samsung", logo: "📱", offer: "Best Deals" },
            { name: "Sony", logo: "🎮", offer: "Under ₹1999" },
            { name: "Mi", logo: "📲", offer: "Min. 35% Off" },
            { name: "HP", logo: "💻", offer: "Up to 40% Off" },
          ].map((b) => (
            <StaggerItem key={b.name} className="flex flex-col items-center">
              <Link
                to="/search"
                search={{ q: b.name }}
                className="group relative transition-transform duration-300 hover:-translate-y-1 active:scale-95"
                aria-label={`Browse ${b.name} clearance`}
              >
                <div className="h-20 w-20 sm:h-24 sm:w-24 rounded-full bg-gradient-to-br from-[#F5F3EC] via-[#FFFFFF] to-[#D7B4D1] flex items-center justify-center text-3xl sm:text-4xl shadow-[0_10px_28px_-6px_rgba(63,63,63,0.35)] ring-4 ring-white/70 group-hover:ring-white transition-all">
                  <span className="drop-shadow-sm">{b.logo}</span>
                </div>
                <div className="mt-3 text-center">
                  <div className="text-[#3F3F3F] font-semibold text-xs sm:text-sm">{b.name}</div>
                  <div className="text-[#D63A12] text-[10px] sm:text-xs font-semibold mt-0.5">{b.offer}</div>
                </div>
              </Link>
            </StaggerItem>
          ))}
        </StaggerGrid>
      </section>

      {recent.length > 0 && <RecentlyViewed recent={recent} />}

      <BusinessOpportunityHub />

      {/* FEATURED SUPPLIERS */}
      {featured && featured.length > 0 && (
        <section className="container mx-auto px-4 py-10">
          <FadeIn>
            <h2 className="font-display text-3xl sm:text-4xl">visit store</h2>
            <p className="text-sm text-muted-foreground mt-1 mb-5">Trusted partners across India</p>
          </FadeIn>
          <StaggerGrid className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {featured.map((shop, i) => (
              <StaggerItem key={shop.id}>
                <Link to="/shop/$slug" params={{ slug: shop.slug }}
                  className="group relative block rounded-2xl overflow-hidden bg-card ring-1 ring-border hover:ring-primary/40 transition-all shadow-float">
                  <div className="aspect-[16/9] overflow-hidden bg-secondary">
                    <img src={visualFor(null, i)} alt={shop.name} loading="lazy" className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-500" />
                  </div>
                  <div className="p-4">
                    <div className="flex items-center gap-1.5">
                      <h3 className="font-display text-lg text-foreground truncate">{shop.name}</h3>
                      {shop.verified && <BadgeCheck className="h-4 w-4 text-primary shrink-0" />}
                    </div>
                    <p className="text-xs text-muted-foreground line-clamp-2 mt-1">{shop.description}</p>
                    <div className="mt-2 flex items-center gap-3 text-xs text-muted-foreground">
                      <span className="flex items-center gap-1"><MapPin className="h-3 w-3" />{shop.area ?? shop.address}</span>
                      {shop.phone && <span className="flex items-center gap-1"><Phone className="h-3 w-3" />Direct</span>}
                    </div>
                  </div>
                </Link>
              </StaggerItem>
            ))}
          </StaggerGrid>
        </section>
      )}

      <footer className="border-t border-border mt-8">
        <div className="container mx-auto px-4 py-10 grid sm:grid-cols-4 gap-6 text-sm">
          <div>
            <div className="font-display text-lg">Kolkatabarabazar<span className="text-accent">.in</span></div>
            <p className="text-muted-foreground mt-2 text-xs">India's wholesale clearance marketplace — overstock, factory surplus and liquidation lots direct from suppliers.</p>
          </div>
          <div>
            <div className="font-semibold mb-2">Marketplace</div>
            <ul className="space-y-1 text-muted-foreground">
              <li><Link to="/search" search={{ q: "" }} className="hover:text-primary">Explore stock</Link></li>
              <li><Link to="/pricing" className="hover:text-primary">Seller pricing</Link></li>
              <li><Link to="/signup" className="hover:text-primary">List your stock</Link></li>
            </ul>
          </div>
          <div>
            <div className="font-semibold mb-2">Connect</div>
            <ul className="space-y-1 text-muted-foreground">
              <li><Link to="/search" search={{ q: "" }} className="hover:text-primary">Find suppliers</Link></li>
              <li><Link to="/favorites" className="hover:text-primary">Saved items</Link></li>
              <li><Link to="/write-to-us" className="hover:text-primary">Write to us</Link></li>
            </ul>
          </div>
          <div>
            <div className="font-semibold mb-2">Contact</div>
            <ul className="space-y-2 text-muted-foreground">
              <li>
                <a href="tel:+917384414113" className="inline-flex items-center gap-2 hover:text-primary">
                  <Phone className="h-4 w-4" /> +91 73844 14113
                </a>
              </li>
              <li>
                <a href="mailto:kolkatabarabazar@gmail.com" className="inline-flex items-center gap-2 hover:text-primary break-all">
                  <Mail className="h-4 w-4" /> kolkatabarabazar@gmail.com
                </a>
              </li>
              <li className="flex items-center gap-3 pt-1">
                <a href="https://youtube.com/@kolkatabarabazar?si=yXJbtxkFFYf-U1p2" target="_blank" rel="noopener noreferrer" aria-label="YouTube"
                   className="inline-flex h-9 w-9 items-center justify-center rounded-full bg-[#FF0000] text-white hover:opacity-90 transition">
                  <Youtube className="h-4 w-4" />
                </a>
                <a href="https://www.facebook.com/share/1Ay34scDCG/" target="_blank" rel="noopener noreferrer" aria-label="Facebook"
                   className="inline-flex h-9 w-9 items-center justify-center rounded-full bg-[#1877F2] text-white hover:opacity-90 transition">
                  <Facebook className="h-4 w-4" />
                </a>
                <a href="https://www.instagram.com/kolkatabarabazar?igsh=MWlxZnMzdWh4YTFpNg==" target="_blank" rel="noopener noreferrer" aria-label="Instagram"
                   className="inline-flex h-9 w-9 items-center justify-center rounded-full bg-gradient-to-tr from-[#feda75] via-[#d62976] to-[#4f5bd5] text-white hover:opacity-90 transition">
                  <Instagram className="h-4 w-4" />
                </a>
              </li>
            </ul>
          </div>
        </div>
        <div className="border-t border-border py-4 text-center text-xs text-muted-foreground">
          © {new Date().getFullYear()} Kolkatabarabazar.in · India's wholesale clearance marketplace
        </div>
      </footer>
    </div>
  );
}

function RecentlyViewed({ recent }: { recent: RecentProduct[] }) {
  const slugs = recent.map((r) => r.slug);
  const { data: priceMap } = useQuery({
    queryKey: ["recent-prices", slugs.join(",")],
    queryFn: async () => {
      const { data: prods } = await supabase.from("products").select("id, slug").in("slug", slugs);
      const ids = (prods ?? []).map((p: any) => p.id);
      if (!ids.length) return {} as Record<string, number>;
      const { data: sp } = await supabase.from("shop_products").select("product_id, price").in("product_id", ids);
      const bySlug: Record<string, number> = {};
      for (const p of prods ?? []) {
        const prices = (sp ?? []).filter((x: any) => x.product_id === (p as any).id).map((x: any) => Number(x.price));
        if (prices.length) bySlug[(p as any).slug] = Math.min(...prices);
      }
      return bySlug;
    },
  });

  return (
    <section className="container mx-auto px-4 pb-10">
      <FadeIn>
        <h2 className="font-display text-2xl sm:text-3xl flex items-center gap-2">
          <Clock className="h-5 w-5 text-primary" />Recently viewed
        </h2>
        <p className="text-sm text-muted-foreground mt-1 mb-4">Pick up where you left off</p>
      </FadeIn>
      <StaggerGrid className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
        {recent.map((r, i) => {
          const img = r.image_url || visualFor(r.category, i);
          const price = priceMap?.[r.slug];
          return (
            <StaggerItem key={r.slug}>
              <Link to="/product/$slug" params={{ slug: r.slug }}
                className="group block rounded-2xl overflow-hidden bg-card ring-1 ring-border hover:ring-primary/40 transition-all shadow-float">
                <div className="aspect-square overflow-hidden bg-secondary">
                  <img src={img} alt={r.name} loading="lazy" className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-500" />
                </div>
                <div className="p-3">
                  {r.category && <div className="text-[10px] uppercase tracking-wider text-muted-foreground truncate">{r.category}</div>}
                  <h3 className="font-display text-sm sm:text-base text-foreground line-clamp-2 mt-0.5">{r.name}</h3>
                  {price != null ? (
                    <div className="mt-1.5 font-display text-base text-primary">₹{price.toFixed(0)}<span className="text-[10px] text-muted-foreground ml-1">best price</span></div>
                  ) : (
                    <div className="mt-1.5 text-xs text-muted-foreground">View details</div>
                  )}
                </div>
              </Link>
            </StaggerItem>
          );
        })}
      </StaggerGrid>
    </section>
  );
}
