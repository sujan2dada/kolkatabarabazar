import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { z } from "zod";
import { MapPin, Phone, BadgeCheck, MessageCircle, ExternalLink, Flame, LayoutGrid, List, Menu } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { SiteHeader } from "@/components/SiteHeader";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { SearchFilters, countActiveFilters, type FilterValues } from "@/components/SearchFilters";
import { SaveSearchButton } from "@/components/SaveSearchButton";
import { TrustBadges } from "@/components/TrustBadges";
import { TrustScoreBadge } from "@/components/TrustScore";
import { distanceKm, freshnessLabel, stockLabel, telUrl, whatsappUrl, directionsUrl } from "@/lib/format";
import { trustScore } from "@/lib/trust";

import catApparel from "@/assets/cat-apparel.jpg";
import catElectronics from "@/assets/cat-electronics.jpg";
import catHome from "@/assets/cat-home.jpg";
import catGrocery from "@/assets/cat-grocery.jpg";

const FALLBACKS = [catApparel, catElectronics, catHome, catGrocery];
const fallbackImg = (i: number) => FALLBACKS[i % FALLBACKS.length];

const searchSchema = z.object({
  q: z.string().optional().default(""),
  category: z.string().optional(),
});

export const Route = createFileRoute("/search")({
  validateSearch: searchSchema,
  head: (ctx: any) => {
    const q = ctx?.search?.q?.trim();
    const title = q
      ? `${q} — Wholesale Suppliers & Clearance Stock | Kolkatabarabazar.in`
      : "Browse Wholesale Clearance Stock — Kolkatabarabazar.in";
    const desc = q
      ? `Compare wholesale ${q} suppliers, MOQ, condition and prices. Live factory surplus & liquidation lots from verified Indian suppliers on Kolkatabarabazar.in.`
      : "Search live wholesale clearance lots across apparel, electronics, home & FMCG. Compare verified Indian suppliers, MOQ, condition & prices on Kolkatabarabazar.in.";
    return {
      meta: [
        { title },
        { name: "description", content: desc },
        { property: "og:title", content: title },
        { property: "og:description", content: desc },
        { property: "og:url", content: "https://kolkatabarabazar.in/search" },
      ],
      links: [{ rel: "canonical", href: "https://kolkatabarabazar.in/search" }],
    };
  },
  component: SearchPage,
});

interface Offer {
  id: string;
  price: number;
  moq: number;
  stock_status: "available" | "low" | "out";
  updated_at: string;
  condition: string | null;
  brand: string | null;
  dispatch_time: string | null;
  product_id: string;
  product_name: string;
  product_slug: string;
  product_image: string | null;
  category_name: string | null;
  shop_id: string;
  shop: any;
  shop_name: string;
  shop_slug: string;
  shop_address: string;
  shop_area: string | null;
  shop_phone: string | null;
  shop_whatsapp: string | null;
  shop_verified: boolean;
  shop_lat: number | null;
  shop_lng: number | null;
  trust: number;
}


function SearchPage() {
  const { q, category } = Route.useSearch();
  const navigate = useNavigate();
  const [filters, setFilters] = useState<FilterValues>({ category });
  const [draftFilters, setDraftFilters] = useState<FilterValues>({ category });
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [view, setView] = useState<"grid" | "compare">("grid");
  const [userLoc, setUserLoc] = useState<{ lat: number; lng: number } | null>(null);

  useEffect(() => {
    setFilters((f) => ({ ...f, category }));
    setDraftFilters((f) => ({ ...f, category }));
  }, [category]);

  useEffect(() => {
    const handler = () => {
      setDraftFilters(filters);
      setDrawerOpen(true);
    };
    window.addEventListener("open-search-filters", handler);
    return () => window.removeEventListener("open-search-filters", handler);
  }, [filters]);

  const activeCount = countActiveFilters(filters);

  const applyFromDrawer = () => {
    setFilters(draftFilters);
    if (draftFilters.category !== category) {
      navigate({ to: "/search", search: { q, category: draftFilters.category } });
    }
    setDrawerOpen(false);
  };
  const clearAll = () => {
    setDraftFilters({});
    setFilters({});
    navigate({ to: "/search", search: { q } });
  };
  const openDrawer = () => {
    setDraftFilters(filters);
    setDrawerOpen(true);
  };

  useEffect(() => {
    if (filters.nearMe && !userLoc && typeof navigator !== "undefined" && navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (p) => setUserLoc({ lat: p.coords.latitude, lng: p.coords.longitude }),
        () => setUserLoc(null),
      );
    }
  }, [filters.nearMe, userLoc]);

  const { data: subcategories } = useQuery({
    queryKey: ["subcategories", filters.category],
    queryFn: async () => {
      if (!filters.category) return [];
      const { data: parent } = await supabase.from("categories").select("id").eq("slug", filters.category).single();
      if (!parent) return [];
      const { data } = await supabase.from("categories").select("id, name, slug, icon").eq("parent_id", parent.id).order("name").limit(50);
      return data ?? [];
    },
    enabled: !!filters.category,
  });

  const { data, isLoading } = useQuery({
    queryKey: ["search", q, filters.category],
    queryFn: async (): Promise<Offer[]> => {
      let productQuery = supabase.from("products").select("id, name, slug, image_url, synonyms, categories(name, slug)");
      if (q) productQuery = productQuery.or(`name.ilike.%${q}%,description.ilike.%${q}%,synonyms.cs.{${q}}`);
      if (filters.category) {
        const { data: cat } = await supabase.from("categories").select("id").eq("slug", filters.category).single();
        if (cat) productQuery = productQuery.eq("category_id", cat.id);
      }
      const { data: products } = await productQuery.limit(100);
      if (!products || products.length === 0) return [];

      const productIds = products.map((p) => p.id);
      const { data: sps } = await supabase.from("shop_products")
        .select("id, price, moq, stock_status, updated_at, condition, brand, dispatch_time, product_id, shop_id, shops(id, name, slug, address, area, phone, whatsapp, verified, approved, lat, lng, gst_verified, mobile_verified, warehouse_verified, top_seller, fast_responder, response_rate, avg_response_minutes, years_in_business, photos, description, logo_url, created_at, last_active_at, total_views)")
        .in("product_id", productIds).order("price", { ascending: true });

      return (sps ?? [])
        .filter((sp: any) => sp.shops?.approved)
        .map((sp: any) => {
          const p = products.find((pp) => pp.id === sp.product_id)!;
          return {
            id: sp.id,
            price: Number(sp.price),
            moq: sp.moq,
            stock_status: sp.stock_status,
            updated_at: sp.updated_at,
            condition: sp.condition ?? null,
            brand: sp.brand ?? null,
            dispatch_time: sp.dispatch_time ?? null,
            product_id: sp.product_id,
            product_name: p.name,
            product_slug: p.slug,
            product_image: p.image_url,
            category_name: (p as any).categories?.name ?? null,
            shop_id: sp.shop_id,
            shop: sp.shops,
            shop_name: sp.shops.name,
            shop_slug: sp.shops.slug,
            shop_address: sp.shops.address,
            shop_area: sp.shops.area,
            shop_phone: sp.shops.phone,
            shop_whatsapp: sp.shops.whatsapp,
            shop_verified: sp.shops.verified,
            shop_lat: sp.shops.lat,
            shop_lng: sp.shops.lng,
            trust: trustScore(sp.shops),
          } as Offer;
        });
    },
  });


  const filtered = (data ?? []).filter((o) => {
    if (filters.minPrice != null && o.price < filters.minPrice) return false;
    if (filters.maxPrice != null && o.price > filters.maxPrice) return false;
    if (filters.maxMoq != null && o.moq > filters.maxMoq) return false;
    if (filters.verifiedOnly && !o.shop_verified) return false;
    if (filters.inStockOnly && o.stock_status === "out") return false;
    if (filters.area && o.shop_area !== filters.area) return false;
    if (filters.condition && (o.condition ?? "").toLowerCase() !== filters.condition.toLowerCase()) return false;
    if (filters.brand && !(o.brand ?? "").toLowerCase().includes(filters.brand.toLowerCase())) return false;
    if (filters.dispatchTime && (o.dispatch_time ?? "") !== filters.dispatchTime) return false;
    if (filters.minTrustScore && o.trust < filters.minTrustScore) return false;
    return true;
  });

  const sort = filters.sort ?? "best";
  if (sort === "price_asc") filtered.sort((a, b) => a.price - b.price);
  else if (sort === "price_desc") filtered.sort((a, b) => b.price - a.price);
  else if (sort === "newest") filtered.sort((a, b) => +new Date(b.updated_at) - +new Date(a.updated_at));
  else if (sort === "trust") filtered.sort((a, b) => b.trust - a.trust);

  if (filters.nearMe && userLoc) {
    filtered.sort((a, b) => {
      const da = a.shop_lat != null && a.shop_lng != null ? distanceKm(userLoc, { lat: a.shop_lat, lng: a.shop_lng }) : Infinity;
      const db = b.shop_lat != null && b.shop_lng != null ? distanceKm(userLoc, { lat: b.shop_lat, lng: b.shop_lng }) : Infinity;
      return da - db;
    });
  }


  // Group by product
  const byProduct = new Map<string, Offer[]>();
  filtered.forEach((o) => {
    const arr = byProduct.get(o.product_id) ?? [];
    arr.push(o);
    byProduct.set(o.product_id, arr);
  });
  const productCards = Array.from(byProduct.entries()).map(([pid, offers]) => {
    offers.sort((a, b) => a.price - b.price);
    return { pid, offers, best: offers[0] };
  });

  return (
    <div className="min-h-screen">
      <SiteHeader />
      <main className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-[260px_1fr] gap-6">
          <div className="hidden lg:block">
            <SearchFilters
              value={filters}
              onChange={(v) => {
                setFilters(v);
                if (v.category !== category) navigate({ to: "/search", search: { q, category: v.category } });
              }}
              onReset={() => { setFilters({}); navigate({ to: "/search", search: { q } }); }}
            />
          </div>

          <Sheet open={drawerOpen} onOpenChange={setDrawerOpen}>
            <SheetContent
              side="left"
              className="w-[320px] sm:max-w-[320px] p-0 bg-card rounded-r-2xl shadow-2xl border-r-0 flex flex-col gap-0"
            >
              <SheetHeader className="p-5 border-b border-border text-left space-y-0">
                <SheetTitle className="font-display text-xl flex items-center gap-2">
                  Filters
                  {countActiveFilters(draftFilters) > 0 && (
                    <Badge className="bg-primary text-primary-foreground">{countActiveFilters(draftFilters)}</Badge>
                  )}
                </SheetTitle>
              </SheetHeader>
              <SearchFilters
                variant="drawer"
                value={draftFilters}
                onChange={setDraftFilters}
                onReset={clearAll}
                onApply={applyFromDrawer}
              />
            </SheetContent>
          </Sheet>

          <div>
            {q && filtered.length > 0 && (() => {
              const supplierCount = new Set(filtered.map((o) => o.shop_id)).size;
              const minMoq = Math.min(...filtered.map((o) => o.moq));
              const minPrice = Math.min(...filtered.map((o) => o.price));
              const verifiedCount = new Set(filtered.filter((o) => o.shop_verified).map((o) => o.shop_id)).size;
              return (
                <div className="mb-5 rounded-2xl border border-border bg-card shadow-float overflow-hidden">
                  <div className="px-5 py-3 border-b border-border flex items-center justify-between gap-3 flex-wrap">
                    <div className="flex items-center gap-2">
                      <span className="font-display text-lg text-foreground">{q}</span>
                      <span className="inline-flex items-center gap-1 rounded-full bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 border border-emerald-500/30 text-[10px] font-semibold px-2 py-0.5">
                        <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse" />Live inventory
                      </span>
                    </div>
                    <span className="text-[11px] text-muted-foreground">Updated just now · from verified suppliers</span>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-4 divide-x divide-border">
                    <Stat label="Active lots" value={filtered.length.toLocaleString("en-IN")} />
                    <Stat label="Suppliers" value={`${supplierCount}${verifiedCount > 0 ? ` · ${verifiedCount} verified` : ""}`} />
                    <Stat label="MOQ from" value={`${minMoq} pcs`} />
                    <Stat label="Starting at" value={`₹${minPrice.toFixed(0)}`} />
                  </div>
                </div>
              );
            })()}
            {subcategories && subcategories.length > 0 && (
              <div className="mb-5">
                <h3 className="text-sm font-semibold text-muted-foreground mb-3">Subcategories</h3>
                <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-hide" style={{ scrollbarWidth: 'none' }}>
                  {subcategories.map((s: any) => (
                    <Link
                      key={s.id}
                      to="/search"
                      search={{ q, category: s.slug }}
                      className="group flex-shrink-0 w-24 text-center"
                    >
                      <div className="h-24 w-24 rounded-2xl overflow-hidden bg-muted ring-1 ring-border mb-2 group-hover:ring-primary/50 transition-all">
                        <img
                          src={`https://source.unsplash.com/96x96/?${encodeURIComponent(s.name)}`}
                          alt={s.name}
                          loading="lazy"
                          className="h-full w-full object-cover group-hover:scale-110 transition-transform duration-500"
                          onError={(e) => { (e.currentTarget as HTMLImageElement).src = `https://picsum.photos/seed/${encodeURIComponent(s.slug)}/96`; }}
                        />
                      </div>
                      <span className="text-xs text-foreground line-clamp-2 leading-tight">{s.name}</span>
                    </Link>
                  ))}
                </div>
              </div>
            )}
            <div className="mb-6 flex items-end justify-between gap-4 flex-wrap">
              <div>
                <h1 className="font-display text-3xl sm:text-4xl text-foreground">
                  {q ? `Results for "${q}"` : filters.category ? `${filters.category}` : "All clearance lots"}
                </h1>
                <p className="text-sm text-muted-foreground mt-1">
                  {byProduct.size} product{byProduct.size === 1 ? "" : "s"} · {filtered.length} offer{filtered.length === 1 ? "" : "s"}
                  {filters.nearMe && !userLoc && " · waiting for location…"}
                </p>
              </div>
              <div className="flex items-center gap-2">
                <SaveSearchButton query={q} filters={filters} />
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={openDrawer}
                  className="lg:hidden rounded-full gap-2 relative"
                >
                  <Menu className="h-4 w-4" />
                  Filters
                  {activeCount > 0 && (
                    <span className="ml-1 inline-flex h-5 min-w-5 items-center justify-center rounded-full bg-primary px-1.5 text-[10px] font-bold text-primary-foreground">
                      {activeCount}
                    </span>
                  )}
                </Button>
                <div className="inline-flex rounded-full border border-border bg-card p-0.5">
                  <button onClick={() => setView("grid")} className={`px-3 py-1.5 rounded-full text-xs font-medium flex items-center gap-1 ${view === "grid" ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`}>
                    <LayoutGrid className="h-3.5 w-3.5" />Grid
                  </button>
                  <button onClick={() => setView("compare")} className={`px-3 py-1.5 rounded-full text-xs font-medium flex items-center gap-1 ${view === "compare" ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`}>
                    <List className="h-3.5 w-3.5" />Compare
                  </button>
                </div>
              </div>
            </div>


            {isLoading && <p className="text-muted-foreground">Searching…</p>}

            {!isLoading && byProduct.size === 0 && (
              <div className="rounded-2xl border-2 border-dashed border-border p-12 text-center">
                <p className="text-muted-foreground">No clearance lots match these filters.</p>
              </div>
            )}

            {view === "grid" ? (
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
                {productCards.map(({ pid, offers, best }, i) => {
                  const img = best.product_image || fallbackImg(i);
                  const max = offers[offers.length - 1].price;
                  const discountPct = max > best.price ? Math.round(((max - best.price) / max) * 100) : null;
                  return (
                    <Link key={pid} to="/product/$slug" params={{ slug: best.product_slug }}
                      className="group relative rounded-2xl overflow-hidden bg-card ring-1 ring-border hover:ring-primary/40 hover:-translate-y-0.5 transition-all shadow-float">
                      <div className="aspect-square overflow-hidden bg-secondary">
                        <img src={img} alt={best.product_name} loading="lazy" className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-500" />
                      </div>
                      {discountPct && discountPct > 0 && (
                        <div className="absolute top-2 left-2 rounded-full bg-discount text-white text-[10px] font-bold px-2 py-0.5 shadow-float">
                          {discountPct}% OFF
                        </div>
                      )}
                      {best.shop_verified && (
                        <div className="absolute top-2 right-2 rounded-full glass p-1 shadow-float text-blue-900">
                          <BadgeCheck className="h-3.5 w-3.5 text-primary" />
                        </div>
                      )}
                      <div className="p-3">
                        <div className="font-semibold text-sm text-foreground line-clamp-1">{best.product_name}</div>
                        <div className="text-[11px] text-muted-foreground line-clamp-1">{best.shop_name}{best.shop_area && ` · ${best.shop_area}`}</div>
                        <div className="mt-1.5 flex items-center gap-1.5 flex-wrap">
                          <TrustScoreBadge shop={best.shop} size="sm" />
                          <TrustBadges shop={best.shop} max={2} compact />
                        </div>
                        <div className="mt-1.5 flex items-baseline justify-between">
                          <div className="flex items-baseline gap-1.5">
                            <span className="font-display text-primary text-xl text-black">₹{best.price.toFixed(0)}</span>
                            {max > best.price && <span className="text-[10px] text-muted-foreground line-through">₹{max.toFixed(0)}</span>}
                          </div>
                          <span className="text-[10px] text-muted-foreground">MOQ {best.moq}</span>
                        </div>
                        <div className="text-[10px] text-muted-foreground mt-0.5">{offers.length} supplier{offers.length === 1 ? "" : "s"}</div>
                      </div>
                    </Link>
                  );
                })}
              </div>
            ) : (
              <div className="space-y-5">
                {productCards.map(({ pid, offers, best }) => (
                  <div key={pid} className="rounded-2xl border border-border bg-card overflow-hidden shadow-float">
                    <div className="p-5 border-b border-border bg-secondary/40 flex items-center justify-between gap-4">
                      <Link to="/product/$slug" params={{ slug: best.product_slug }} className="font-display text-xl text-foreground hover:text-primary">
                        {best.product_name}
                      </Link>
                      <div className="text-right">
                        <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Best price</div>
                        <div className="font-display text-2xl text-primary">₹{best.price.toFixed(0)}</div>
                      </div>
                    </div>
                    <ul className="divide-y divide-border">
                      {offers.map((o) => {
                        const isBest = o.id === best.id;
                        const stock = stockLabel(o.stock_status);
                        const dist = filters.nearMe && userLoc && o.shop_lat != null && o.shop_lng != null
                          ? distanceKm(userLoc, { lat: o.shop_lat, lng: o.shop_lng }) : null;
                        const msg = `Hi ${o.shop_name}, I'd like to enquire about ${o.product_name}. Please share availability and best price.`;
                        return (
                          <li key={o.id} className="p-4 hover:bg-secondary/30 transition">
                            <div className="flex items-start justify-between gap-4">
                              <Link to="/shop/$slug" params={{ slug: o.shop_slug }} className="flex-1 min-w-0">
                                <div className="flex items-center gap-2 flex-wrap">
                                  <span className="font-semibold text-foreground">{o.shop_name}</span>
                                  <TrustScoreBadge shop={o.shop} size="sm" />
                                  {isBest && <Badge className="bg-discount text-white hover:bg-discount"><Flame className="h-3 w-3 mr-1" />Best price</Badge>}
                                  <span className={`px-1.5 py-0.5 rounded border text-[10px] ${stock.cls}`}>{stock.text}</span>
                                </div>
                                <div className="mt-1.5"><TrustBadges shop={o.shop} max={3} compact /></div>
                                <div className="text-xs text-muted-foreground mt-1.5 flex flex-wrap gap-3">
                                  <span className="flex items-center gap-1"><MapPin className="h-3 w-3" />{o.shop_area ?? o.shop_address}{dist != null && ` · ${dist.toFixed(1)} km`}</span>
                                  <span>MOQ {o.moq}</span>
                                  <span>{freshnessLabel(o.updated_at)}</span>
                                </div>
                              </Link>
                              <div className="font-display text-xl text-primary shrink-0">₹{o.price.toFixed(0)}</div>
                            </div>
                            <div className="mt-2 flex gap-1 flex-wrap">
                              {o.shop_phone && <Button size="sm" variant="outline" asChild><a href={telUrl(o.shop_phone)}><Phone className="h-3.5 w-3.5 mr-1" />Call</a></Button>}
                              {o.shop_whatsapp && <Button size="sm" asChild className="bg-whatsapp hover:bg-whatsapp/90 text-white"><a href={whatsappUrl(o.shop_whatsapp, msg)} target="_blank" rel="noopener noreferrer"><MessageCircle className="h-3.5 w-3.5 mr-1" />WhatsApp</a></Button>}
                              {o.shop_lat != null && o.shop_lng != null && <Button size="sm" variant="ghost" asChild><a href={directionsUrl(o.shop_lat, o.shop_lng)} target="_blank" rel="noopener noreferrer"><ExternalLink className="h-3.5 w-3.5 mr-1" />Map</a></Button>}
                            </div>
                          </li>
                        );
                      })}
                    </ul>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="px-4 py-3">
      <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className="font-display text-lg sm:text-xl text-foreground mt-0.5">{value}</div>
    </div>
  );
}
