import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { SiteHeader } from "@/components/SiteHeader";
import { OpportunityCard, type OpportunityRow } from "@/components/OpportunityCard";
import { BusinessOpportunityHub } from "@/components/BusinessOpportunityHub";
import { FadeIn } from "@/components/motion/FadeIn";
import { ArrowRight } from "lucide-react";
import { OPP_META, type OpportunityType } from "@/lib/opportunities";

export const Route = createFileRoute("/opportunities")({
  head: () => ({
    meta: [
      { title: "Business Opportunities in India — Franchise, Distributor, Dealer | Kolkatabarabazar" },
      { name: "description", content: "Discover franchise, distributor, dealer, super stockist & C&F opportunities from verified Indian brands. Apply online and start your business." },
      { property: "og:title", content: "Business Opportunities — Kolkatabarabazar" },
      { property: "og:description", content: "Franchise · Distributor · Dealer · Wholesale opportunities across India." },
      { rel: "canonical", href: "/opportunities" },
    ],
  }),
  component: OpportunitiesHub,
});

function OpportunitiesHub() {
  const { data: opps } = useQuery({
    queryKey: ["opps", "featured"],
    queryFn: async () => {
      const { data } = await supabase.from("opportunities")
        .select("id, slug, title, type, category, investment_min, investment_max, margin_min, margin_max, territory, image_url, featured, brands(name, slug, logo_url, verified)")
        .eq("approved", true).order("featured", { ascending: false }).order("created_at", { ascending: false }).limit(24);
      return (data ?? []) as unknown as OpportunityRow[];
    },
  });

  const byType: Partial<Record<OpportunityType, OpportunityRow[]>> = {};
  for (const o of opps ?? []) (byType[o.type] ||= []).push(o);

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <BusinessOpportunityHub />

      {Object.entries(byType).map(([type, list]) => (
        <section key={type} className="container mx-auto px-4 py-6">
          <FadeIn>
            <div className="flex items-end justify-between mb-4">
              <h2 className="font-display text-2xl">{OPP_META[type as OpportunityType].label} opportunities</h2>
              <Link to="/franchise-opportunities" className="text-sm text-primary inline-flex items-center">All <ArrowRight className="h-4 w-4 ml-1" /></Link>
            </div>
          </FadeIn>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {list!.slice(0, 6).map((o) => <OpportunityCard key={o.id} o={o} />)}
          </div>
        </section>
      ))}

      {!opps?.length && (
        <div className="container mx-auto px-4 py-20 text-center text-muted-foreground">
          New opportunities are being added — check back soon.
        </div>
      )}
    </div>
  );
}
