import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import {
  Plus, Store, Package, Pencil, ShieldCheck, ShieldAlert,
  TrendingUp, MessageSquare, Eye, IndianRupee, Boxes, Phone,
  ExternalLink, NotebookPen, Trash2, RefreshCw,
} from "lucide-react";
import { formatDistanceToNow, format, subDays, startOfDay } from "date-fns";
import {
  ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip,
  CartesianGrid, BarChart, Bar, PieChart, Pie, Cell, Legend,
} from "recharts";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { SiteHeader } from "@/components/SiteHeader";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter,
} from "@/components/ui/dialog";
import { PhoneVerificationDialog } from "@/components/PhoneVerificationDialog";
import { whatsappUrl, telUrl } from "@/lib/format";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({ meta: [{ title: "Seller Dashboard — Kolkatabarabazar.in" }] }),
  component: Dashboard,
});

type EnquiryStatus = "new" | "contacted" | "quoted" | "won" | "lost";
const STATUS_OPTIONS: EnquiryStatus[] = ["new", "contacted", "quoted", "won", "lost"];
const STATUS_COLORS: Record<EnquiryStatus, string> = {
  new: "bg-sky-100 text-sky-700 border-sky-200",
  contacted: "bg-amber-100 text-amber-700 border-amber-200",
  quoted: "bg-violet-100 text-violet-700 border-violet-200",
  won: "bg-emerald-100 text-emerald-700 border-emerald-200",
  lost: "bg-rose-100 text-rose-700 border-rose-200",
};

function Dashboard() {
  const { user } = useAuth();
  const qc = useQueryClient();
  const [tab, setTab] = useState<string>("overview");

  const { data: shops, refetch: refetchShops } = useQuery({
    enabled: !!user,
    queryKey: ["my-shops", user?.id],
    queryFn: async () => {
      const { data } = await supabase
        .from("shops").select("*")
        .eq("owner_id", user!.id).order("created_at", { ascending: false });
      return data ?? [];
    },
  });

  const shopIds = useMemo(() => (shops ?? []).map((s) => s.id), [shops]);

  const { data: listings } = useQuery({
    enabled: shopIds.length > 0,
    queryKey: ["my-listings", shopIds],
    queryFn: async () => {
      const { data } = await supabase.from("shop_products")
        .select("id, shop_id, price, stock, moq, stock_status, updated_at, products(id, name, slug, image_url)")
        .in("shop_id", shopIds).order("updated_at", { ascending: false });
      return data ?? [];
    },
  });

  const { data: enquiries } = useQuery({
    enabled: shopIds.length > 0,
    queryKey: ["my-enquiries", shopIds],
    queryFn: async () => {
      const { data } = await supabase.from("enquiries")
        .select("*, shops(name, whatsapp, phone), products(name, slug)")
        .in("shop_id", shopIds).order("created_at", { ascending: false });
      return data ?? [];
    },
  });

  const stats = useMemo(() => {
    const list = listings ?? [];
    const enq = enquiries ?? [];
    const lowStock = list.filter((l: any) => l.stock_status === "low" || (l.stock != null && l.stock < 10)).length;
    const oos = list.filter((l: any) => l.stock_status === "out_of_stock").length;
    const totalViews = (shops ?? []).reduce((s, x: any) => s + (x.total_views ?? 0), 0);
    const open = enq.filter((e: any) => e.status === "new" || e.status === "contacted").length;
    const won = enq.filter((e: any) => e.status === "won").length;
    const conv = enq.length ? Math.round((won / enq.length) * 100) : 0;
    return { listings: list.length, lowStock, oos, totalViews, totalEnq: enq.length, openEnq: open, conv, won };
  }, [listings, enquiries, shops]);

  if (!shops) {
    return <div className="min-h-screen"><SiteHeader /><div className="p-8">Loading…</div></div>;
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-secondary/30">
      <SiteHeader />
      <main className="container mx-auto px-4 py-8 max-w-7xl">
        <header className="flex flex-wrap items-end justify-between gap-3 mb-6">
          <div>
            <h1 className="font-display text-4xl text-foreground">Seller Workspace</h1>
            <p className="text-muted-foreground text-sm">Track inventory, leads and growth across your shops.</p>
          </div>
          <div className="flex gap-2">
            <Button asChild variant="outline"><Link to="/pricing">Plan</Link></Button>
            <Button asChild><Link to="/shops/new"><Plus className="h-4 w-4 mr-1" />New shop</Link></Button>
          </div>
        </header>

        {shops.length === 0 ? (
          <EmptyState />
        ) : (
          <>
            <KpiGrid stats={stats} />

            <Tabs value={tab} onValueChange={setTab} className="mt-6">
              <TabsList className="flex flex-wrap h-auto">
                <TabsTrigger value="overview"><Store className="h-4 w-4 mr-1.5" />Overview</TabsTrigger>
                <TabsTrigger value="inventory"><Boxes className="h-4 w-4 mr-1.5" />Inventory</TabsTrigger>
                <TabsTrigger value="leads">
                  <MessageSquare className="h-4 w-4 mr-1.5" />Leads
                  {stats.openEnq > 0 && <span className="ml-1.5 px-1.5 py-0.5 text-[10px] rounded-full bg-primary text-primary-foreground">{stats.openEnq}</span>}
                </TabsTrigger>
                <TabsTrigger value="analytics"><TrendingUp className="h-4 w-4 mr-1.5" />Analytics</TabsTrigger>
              </TabsList>

              <TabsContent value="overview" className="mt-4">
                <OverviewTab shops={shops} onChanged={refetchShops} />
              </TabsContent>
              <TabsContent value="inventory" className="mt-4">
                <InventoryTab shops={shops} listings={listings ?? []} onChanged={() => qc.invalidateQueries({ queryKey: ["my-listings"] })} />
              </TabsContent>
              <TabsContent value="leads" className="mt-4">
                <LeadsTab enquiries={enquiries ?? []} onChanged={() => qc.invalidateQueries({ queryKey: ["my-enquiries"] })} />
              </TabsContent>
              <TabsContent value="analytics" className="mt-4">
                <AnalyticsTab enquiries={enquiries ?? []} shops={shops} listings={listings ?? []} />
              </TabsContent>
            </Tabs>
          </>
        )}
      </main>
    </div>
  );
}

function EmptyState() {
  return (
    <div className="rounded-xl border-2 border-dashed border-border p-12 text-center bg-card">
      <Store className="h-12 w-12 mx-auto text-muted-foreground" />
      <h2 className="mt-3 font-display text-2xl">No shops yet</h2>
      <p className="text-muted-foreground text-sm mt-1">Create your first shop to start listing clearance stock.</p>
      <Button asChild className="mt-4"><Link to="/shops/new">Create a shop</Link></Button>
    </div>
  );
}

function Kpi({ icon: Icon, label, value, hint, tone = "default" }: any) {
  const tones: Record<string, string> = {
    default: "from-primary/10 to-primary/5 text-primary",
    warn: "from-amber-100 to-amber-50 text-amber-700",
    danger: "from-rose-100 to-rose-50 text-rose-700",
    success: "from-emerald-100 to-emerald-50 text-emerald-700",
  };
  return (
    <Card className="overflow-hidden">
      <CardContent className="p-4">
        <div className="flex items-center gap-3">
          <div className={`h-10 w-10 rounded-xl bg-gradient-to-br ${tones[tone]} flex items-center justify-center`}>
            <Icon className="h-5 w-5" />
          </div>
          <div>
            <div className="text-xs text-muted-foreground">{label}</div>
            <div className="font-display text-2xl">{value}</div>
            {hint && <div className="text-[11px] text-muted-foreground mt-0.5">{hint}</div>}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function KpiGrid({ stats }: { stats: any }) {
  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
      <Kpi icon={Boxes} label="Active listings" value={stats.listings} hint={`${stats.lowStock} low · ${stats.oos} OOS`} />
      <Kpi icon={Eye} label="Profile views" value={stats.totalViews.toLocaleString()} tone="success" />
      <Kpi icon={MessageSquare} label="Open leads" value={stats.openEnq} hint={`${stats.totalEnq} total`} tone="warn" />
      <Kpi icon={IndianRupee} label="Conversion" value={`${stats.conv}%`} hint={`${stats.won} won`} tone="success" />
    </div>
  );
}

/* ---------- OVERVIEW ---------- */
function OverviewTab({ shops, onChanged }: any) {
  return (
    <div className="grid sm:grid-cols-2 gap-4">
      {shops.map((s: any) => (
        <Card key={s.id} className="overflow-hidden hover:shadow-float transition">
          <CardContent className="p-5">
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <h2 className="font-display text-2xl truncate">{s.name}</h2>
                <p className="text-xs text-muted-foreground truncate">{s.address}</p>
              </div>
              {s.mobile_verified ? (
                <Badge variant="outline" className="text-emerald-700 border-emerald-200 bg-emerald-50">
                  <ShieldCheck className="h-3 w-3 mr-1" />Verified
                </Badge>
              ) : (
                <Badge variant="outline" className="text-amber-700 border-amber-200 bg-amber-50">
                  <ShieldAlert className="h-3 w-3 mr-1" />Unverified
                </Badge>
              )}
            </div>
            <div className="mt-3 flex flex-wrap gap-3 text-xs text-muted-foreground">
              <span><Eye className="inline h-3 w-3 mr-1" />{(s.total_views ?? 0).toLocaleString()} views</span>
              {s.response_rate != null && <span>{s.response_rate}% reply</span>}
              {s.years_in_business != null && <span>{s.years_in_business}+ yrs</span>}
            </div>
            <div className="flex flex-wrap gap-2 mt-4">
              <Button asChild size="sm" variant="outline"><Link to="/shops/$id/edit" params={{ id: s.id }}><Pencil className="h-3.5 w-3.5 mr-1" />Edit</Link></Button>
              <Button asChild size="sm"><Link to="/shops/$id/products" params={{ id: s.id }}><Package className="h-3.5 w-3.5 mr-1" />Products</Link></Button>
              <Button asChild size="sm" variant="ghost"><Link to="/shop/$slug" params={{ slug: s.slug }}>View<ExternalLink className="h-3 w-3 ml-1" /></Link></Button>
              {!s.mobile_verified && (
                <PhoneVerificationDialog shopId={s.id} defaultPhone={s.phone ?? ""} onVerified={() => onChanged()} />
              )}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

/* ---------- INVENTORY ---------- */
function InventoryTab({ shops, listings, onChanged }: any) {
  const [shopFilter, setShopFilter] = useState<string>("all");
  const [stockFilter, setStockFilter] = useState<string>("all");

  const shopName = (id: string) => shops.find((s: any) => s.id === id)?.name ?? "—";
  const shopSlug = (id: string) => shops.find((s: any) => s.id === id)?.slug;

  const filtered = listings.filter((l: any) =>
    (shopFilter === "all" || l.shop_id === shopFilter) &&
    (stockFilter === "all" || l.stock_status === stockFilter)
  );

  async function deleteListing(id: string) {
    if (!confirm("Remove this listing?")) return;
    const { error } = await supabase.from("shop_products").delete().eq("id", id);
    if (error) toast.error(error.message); else { toast.success("Removed"); onChanged(); }
  }

  return (
    <Card>
      <CardHeader className="flex flex-row flex-wrap items-center justify-between gap-3 space-y-0">
        <CardTitle className="text-lg">All listings ({filtered.length})</CardTitle>
        <div className="flex flex-wrap gap-2">
          <Select value={shopFilter} onValueChange={setShopFilter}>
            <SelectTrigger className="w-44"><SelectValue placeholder="Shop" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All shops</SelectItem>
              {shops.map((s: any) => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}
            </SelectContent>
          </Select>
          <Select value={stockFilter} onValueChange={setStockFilter}>
            <SelectTrigger className="w-40"><SelectValue placeholder="Stock" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Any stock</SelectItem>
              <SelectItem value="available">Available</SelectItem>
              <SelectItem value="low">Low</SelectItem>
              <SelectItem value="out_of_stock">Out of stock</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        {filtered.length === 0 ? (
          <div className="p-10 text-center text-muted-foreground text-sm">
            No listings. <Link to="/dashboard" className="text-primary underline">Pick a shop</Link> and click "Products" to add stock.
          </div>
        ) : (
          <div className="divide-y">
            {filtered.map((l: any) => (
              <div key={l.id} className="flex items-center gap-3 p-3 hover:bg-muted/30">
                <img src={l.products?.image_url || "/placeholder.svg"} alt="" className="h-14 w-14 rounded-lg object-cover border bg-secondary" />
                <div className="flex-1 min-w-0">
                  <div className="font-medium truncate">{l.products?.name}</div>
                  <div className="text-xs text-muted-foreground truncate">
                    {shopName(l.shop_id)} · MOQ {l.moq} · updated {formatDistanceToNow(new Date(l.updated_at), { addSuffix: true })}
                  </div>
                </div>
                <div className="text-right hidden sm:block">
                  <div className="font-display text-lg">₹{Number(l.price).toFixed(0)}</div>
                  <div className="text-[11px] text-muted-foreground">stock: {l.stock ?? "—"}</div>
                </div>
                <Badge variant="outline" className={`hidden md:inline-flex ${l.stock_status === "out_of_stock" ? "text-rose-700 border-rose-200" : l.stock_status === "low" ? "text-amber-700 border-amber-200" : "text-emerald-700 border-emerald-200"}`}>
                  {l.stock_status}
                </Badge>
                <div className="flex gap-1">
                  {shopSlug(l.shop_id) && (
                    <Button asChild size="icon" variant="ghost" className="h-8 w-8">
                      <Link to="/product/$slug" params={{ slug: l.products.slug }}><Eye className="h-4 w-4" /></Link>
                    </Button>
                  )}
                  <Button asChild size="icon" variant="ghost" className="h-8 w-8">
                    <Link to="/shops/$id/products" params={{ id: l.shop_id }}><Pencil className="h-4 w-4" /></Link>
                  </Button>
                  <Button size="icon" variant="ghost" className="h-8 w-8 text-destructive" onClick={() => deleteListing(l.id)}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

/* ---------- LEADS ---------- */
function LeadsTab({ enquiries, onChanged }: { enquiries: any[]; onChanged: () => void }) {
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const list = statusFilter === "all" ? enquiries : enquiries.filter((e) => e.status === statusFilter);

  async function setStatus(id: string, status: EnquiryStatus) {
    const { error } = await supabase.from("enquiries").update({ status, updated_at: new Date().toISOString() }).eq("id", id);
    if (error) toast.error(error.message); else onChanged();
  }
  async function saveNote(id: string, note: string) {
    const { error } = await supabase.from("enquiries").update({ seller_notes: note, updated_at: new Date().toISOString() }).eq("id", id);
    if (error) toast.error(error.message); else { toast.success("Note saved"); onChanged(); }
  }

  return (
    <Card>
      <CardHeader className="flex flex-row flex-wrap items-center justify-between gap-3 space-y-0">
        <CardTitle className="text-lg">Buyer enquiries ({list.length})</CardTitle>
        <div className="flex gap-1 flex-wrap">
          {(["all", ...STATUS_OPTIONS] as const).map((s) => (
            <button key={s}
              onClick={() => setStatusFilter(s)}
              className={`text-xs px-2.5 py-1 rounded-full border transition ${statusFilter === s ? "bg-primary text-primary-foreground border-primary" : "bg-card hover:bg-muted"}`}>
              {s}
            </button>
          ))}
        </div>
      </CardHeader>
      <CardContent className="p-0">
        {list.length === 0 ? (
          <div className="p-10 text-center text-muted-foreground text-sm">No leads yet. They'll appear here as soon as buyers enquire.</div>
        ) : (
          <div className="divide-y">
            {list.map((e: any) => <LeadRow key={e.id} e={e} onStatus={setStatus} onSaveNote={saveNote} />)}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function LeadRow({ e, onStatus, onSaveNote }: any) {
  const [note, setNote] = useState(e.seller_notes ?? "");
  const wa = e.shops?.whatsapp || e.buyer_phone;
  const msg = `Hi ${e.buyer_name}, regarding your enquiry on ${e.products?.name ?? "our stock"} via Kolkatabarabazar.in —`;

  return (
    <div className="p-4 hover:bg-muted/30">
      <div className="flex flex-wrap items-start gap-3">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="font-medium">{e.buyer_name}</span>
            <Badge variant="outline" className={STATUS_COLORS[e.status as EnquiryStatus]}>{e.status}</Badge>
            <span className="text-xs text-muted-foreground">{format(new Date(e.created_at), "dd MMM, HH:mm")}</span>
          </div>
          <div className="text-xs text-muted-foreground mt-0.5">
            {e.shops?.name}{e.products?.name && ` · ${e.products.name}`}{e.quantity && ` · Qty ${e.quantity}`}{e.budget && ` · Budget ₹${e.budget}`}
          </div>
          <p className="text-sm mt-2 whitespace-pre-wrap">{e.message}</p>
        </div>
        <div className="flex flex-col gap-1.5 items-stretch w-full sm:w-auto">
          <Select value={e.status} onValueChange={(v) => onStatus(e.id, v as EnquiryStatus)}>
            <SelectTrigger className="h-8 w-full sm:w-36 text-xs"><SelectValue /></SelectTrigger>
            <SelectContent>
              {STATUS_OPTIONS.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
            </SelectContent>
          </Select>
          <div className="flex gap-1.5">
            {e.buyer_phone && (
              <Button asChild size="sm" className="bg-whatsapp hover:bg-whatsapp/90 text-white flex-1">
                <a href={whatsappUrl(e.buyer_phone, msg)} target="_blank" rel="noopener noreferrer">
                  <MessageSquare className="h-3.5 w-3.5 mr-1" />WhatsApp
                </a>
              </Button>
            )}
            {e.buyer_phone && (
              <Button asChild size="sm" variant="outline">
                <a href={telUrl(e.buyer_phone)}><Phone className="h-3.5 w-3.5" /></a>
              </Button>
            )}
            <Dialog>
              <DialogTrigger asChild><Button size="sm" variant="outline"><NotebookPen className="h-3.5 w-3.5" /></Button></DialogTrigger>
              <DialogContent>
                <DialogHeader><DialogTitle>Note for {e.buyer_name}</DialogTitle></DialogHeader>
                <Textarea value={note} onChange={(ev) => setNote(ev.target.value)} rows={5} placeholder="Internal notes (price quoted, follow-up date…)" />
                <DialogFooter><Button onClick={() => onSaveNote(e.id, note)}>Save note</Button></DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </div>
      {e.seller_notes && <div className="mt-2 text-xs italic text-muted-foreground bg-muted/40 rounded px-2 py-1">📝 {e.seller_notes}</div>}
    </div>
  );
}

/* ---------- ANALYTICS ---------- */
function AnalyticsTab({ enquiries, shops, listings }: any) {
  const data30 = useMemo(() => {
    const days: { date: string; leads: number; won: number }[] = [];
    for (let i = 29; i >= 0; i--) {
      const d = startOfDay(subDays(new Date(), i));
      const key = format(d, "MMM d");
      const leads = enquiries.filter((e: any) => startOfDay(new Date(e.created_at)).getTime() === d.getTime()).length;
      const won = enquiries.filter((e: any) => e.status === "won" && startOfDay(new Date(e.updated_at ?? e.created_at)).getTime() === d.getTime()).length;
      days.push({ date: key, leads, won });
    }
    return days;
  }, [enquiries]);

  const statusBreakdown = useMemo(() => {
    return STATUS_OPTIONS.map((s) => ({
      name: s,
      value: enquiries.filter((e: any) => e.status === s).length,
    })).filter((x) => x.value > 0);
  }, [enquiries]);

  const topShops = useMemo(() => {
    return shops.map((s: any) => ({
      name: s.name.length > 14 ? s.name.slice(0, 14) + "…" : s.name,
      views: s.total_views ?? 0,
      leads: enquiries.filter((e: any) => e.shop_id === s.id).length,
    })).sort((a: any, b: any) => b.leads - a.leads).slice(0, 6);
  }, [shops, enquiries]);

  const PIE = ["#0EA5E9", "#F59E0B", "#8B5CF6", "#10B981", "#F43F5E"];

  return (
    <div className="grid lg:grid-cols-3 gap-4">
      <Card className="lg:col-span-2">
        <CardHeader><CardTitle className="text-base">Leads & wins (last 30 days)</CardTitle></CardHeader>
        <CardContent className="h-72">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={data30}>
              <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
              <XAxis dataKey="date" fontSize={11} tickMargin={6} />
              <YAxis fontSize={11} allowDecimals={false} />
              <Tooltip contentStyle={{ borderRadius: 12, border: "1px solid hsl(var(--border))" }} />
              <Legend />
              <Line type="monotone" dataKey="leads" stroke="#0EA5E9" strokeWidth={2} dot={false} />
              <Line type="monotone" dataKey="won" stroke="#10B981" strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle className="text-base">Lead pipeline</CardTitle></CardHeader>
        <CardContent className="h-72">
          {statusBreakdown.length === 0 ? (
            <div className="h-full flex items-center justify-center text-sm text-muted-foreground">No leads yet</div>
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={statusBreakdown} dataKey="value" nameKey="name" innerRadius={50} outerRadius={90} paddingAngle={3}>
                  {statusBreakdown.map((_, i) => <Cell key={i} fill={PIE[i % PIE.length]} />)}
                </Pie>
                <Tooltip />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          )}
        </CardContent>
      </Card>

      <Card className="lg:col-span-3">
        <CardHeader><CardTitle className="text-base">Top shops by traction</CardTitle></CardHeader>
        <CardContent className="h-72">
          {topShops.length === 0 ? (
            <div className="h-full flex items-center justify-center text-sm text-muted-foreground">Add a shop to see traction</div>
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={topShops}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis dataKey="name" fontSize={11} />
                <YAxis fontSize={11} allowDecimals={false} />
                <Tooltip contentStyle={{ borderRadius: 12, border: "1px solid hsl(var(--border))" }} />
                <Legend />
                <Bar dataKey="views" fill="#0EA5E9" radius={[6,6,0,0]} />
                <Bar dataKey="leads" fill="#F59E0B" radius={[6,6,0,0]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
