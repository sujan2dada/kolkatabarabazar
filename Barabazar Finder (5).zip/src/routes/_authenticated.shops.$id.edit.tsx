import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { ArrowLeft, Trash2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { SiteHeader } from "@/components/SiteHeader";
import { ShopForm } from "@/components/ShopForm";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/shops/$id/edit")({
  head: () => ({ meta: [{ title: "Edit shop — Digital Barabazar" }] }),
  component: EditShop,
});

function EditShop() {
  const { id } = Route.useParams();
  const navigate = useNavigate();
  const [busy, setBusy] = useState(false);

  const { data: shop, isLoading } = useQuery({
    queryKey: ["shop-edit", id],
    queryFn: async () => (await supabase.from("shops").select("*").eq("id", id).maybeSingle()).data,
  });

  if (isLoading) return <div className="min-h-screen"><SiteHeader /><div className="p-8">Loading…</div></div>;
  if (!shop) return <div className="min-h-screen"><SiteHeader /><div className="p-8">Shop not found.</div></div>;

  return (
    <div className="min-h-screen">
      <SiteHeader />
      <main className="container mx-auto px-4 py-8 max-w-3xl">
        <Link to="/dashboard" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-primary mb-4">
          <ArrowLeft className="h-4 w-4" />Dashboard
        </Link>
        <div className="flex items-center justify-between mb-6">
          <h1 className="font-display text-4xl text-foreground">Edit shop</h1>
          <Button
            variant="outline"
            className="text-destructive border-destructive hover:bg-destructive hover:text-destructive-foreground"
            onClick={async () => {
              if (!confirm("Delete this shop and all its listings?")) return;
              const { error } = await supabase.from("shops").delete().eq("id", id);
              if (error) toast.error(error.message);
              else { toast.success("Shop deleted"); navigate({ to: "/dashboard" }); }
            }}
          >
            <Trash2 className="h-4 w-4 mr-1" />Delete
          </Button>
        </div>
        <div className="rounded-xl border-2 border-border bg-card p-6">
          <ShopForm
            submitLabel="Save changes"
            busy={busy}
            initial={{
              name: shop.name, slug: shop.slug,
              description: shop.description ?? "",
              address: shop.address, area: shop.area ?? "",
              phone: shop.phone ?? "", whatsapp: shop.whatsapp ?? "",
              hours: shop.hours ?? "", owner_name: shop.owner_name ?? "",
              years_in_business: shop.years_in_business,
              photos: shop.photos ?? [],
              category_id: shop.category_id,
              lat: shop.lat, lng: shop.lng,
            }}
            onSubmit={async (v) => {
              setBusy(true);
              const { error } = await supabase.from("shops").update({
                name: v.name, slug: v.slug,
                description: v.description || null,
                address: v.address, area: v.area || null,
                phone: v.phone || null, whatsapp: v.whatsapp || null,
                hours: v.hours || null, owner_name: v.owner_name || null,
                years_in_business: v.years_in_business,
                photos: v.photos,
                category_id: v.category_id,
                lat: v.lat, lng: v.lng,
              }).eq("id", id);
              setBusy(false);
              if (error) toast.error(error.message);
              else { toast.success("Saved"); navigate({ to: "/dashboard" }); }
            }}
          />
        </div>
      </main>
    </div>
  );
}
