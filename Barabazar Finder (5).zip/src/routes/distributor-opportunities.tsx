import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { SiteHeader } from "@/components/SiteHeader";
import { OpportunityCard, type OpportunityRow } from "@/components/OpportunityCard";
import { FadeIn } from "@/components/motion/FadeIn";

const INDUSTRIES = ["all", "fmcg", "electrical", "hardware", "stationery", "packaging", "consumer-goods"] as const;

export const Route = createFileRoute("/distributor-opportunities")({
  head: () => ({
    meta: [
      { title: "Distributor Wanted — FMCG, Electrical, Hardware, Packaging | Kolkatabarabazar" },
      { name: "description", content: "Become a distributor for India's leading brands. FMCG, electrical, hardware, stationery & packaging companies looking for distributors across West Bengal & India." },
      { property: "og:title", content: "Distributor Opportunities in India" },
      { property: "og:description", content: "Top brands seeking distributors across FMCG, electrical, hardware and more." },
      { rel: "canonical", href: "/distributor-opportunities" },
    ],
  }),
  component: DistributorPage,
});

function DistributorPage() {
  const [ind, setInd] = useState<typeof INDUSTRIES[number]>("all");
  const { data: opps } = useQuery({
    queryKey: ["opps", "distributor", ind],
    queryFn: async () => {
      let q = supabase.from("opportunities")
        .select("id, slug, title, type, category, investment_min, investment_max, margin_min, margin_max, territory, image_url, featured, brands(name, slug, logo_url, verified)")
        .in("type", ["distributor", "super_stockist", "cnf_agent"]).eq("approved", true).order("featured", { ascending: false });
      if (ind !== "all") q = q.eq("category", ind);
      const { data } = await q;
      return (data ?? []) as unknown as OpportunityRow[];
    },
  });

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <section className="container mx-auto px-4 py-8">
        <FadeIn>
          <h1 className="font-display text-3xl sm:text-4xl">Distributor & Super Stockist Opportunities</h1>
          <p className="text-muted-foreground mt-2 max-w-2xl">Companies across FMCG, electrical, hardware, stationery and packaging are looking for distributors. Apply online and get matched.</p>
        </FadeIn>
        <div className="mt-5 flex gap-2 overflow-x-auto pb-2">
          {INDUSTRIES.map((c) => (
            <button key={c} onClick={() => setInd(c)}
              className={`shrink-0 rounded-full px-4 py-1.5 text-sm capitalize border transition ${ind === c ? "bg-primary text-primary-foreground border-primary" : "bg-card border-border hover:border-primary/40"}`}>
              {c.replace("-", " ")}
            </button>
          ))}
        </div>
        <div className="mt-6 grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {(opps ?? []).map((o) => <OpportunityCard key={o.id} o={o} />)}
        </div>
        {opps && opps.length === 0 && (
          <div className="py-20 text-center text-muted-foreground">No opportunities in this industry yet.</div>
        )}
      </section>
    </div>
  );
}
