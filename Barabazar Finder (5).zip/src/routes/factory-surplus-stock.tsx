import { createFileRoute } from "@tanstack/react-router";
import { CategoryLanding, categoryJsonLd, type CategoryLandingConfig } from "@/components/CategoryLanding";
import hero from "@/assets/cat-home.jpg";

const URL = "https://barabazar-finder.lovable.app/factory-surplus-stock";
const TITLE = "Factory Surplus Stock — Buy Overstock & Liquidation Lots Online";
const DESC = "Discover factory surplus and overstock inventory from Indian manufacturers. Bulk lots across apparel, electronics, home goods at clearance prices on Kolkatabarabazar.";

const config: CategoryLandingConfig = {
  slug: "factory-surplus-stock",
  h1: "Factory Surplus Stock",
  tagline: "Overstock and cancelled-order inventory direct from Indian factories.",
  intro:
    "Factory surplus is unsold or cancelled-order stock that mills and manufacturers need to clear fast. Kolkatabarabazar connects you directly to those factories — no agents, no markups. Browse live lots across categories with verified MOQ, condition and dispatch time.",
  heroImage: hero,
  search: {},
  benefits: [
    { icon: "price", title: "Factory-gate pricing", body: "Buy at the price the factory needs to clear inventory." },
    { icon: "verified", title: "Verified warehouses", body: "Warehouse-verified suppliers with photos and addresses." },
    { icon: "trust", title: "Condition disclosed", body: "Every lot shows condition: A-grade, B-grade, or mixed." },
    { icon: "fast", title: "Live freshness", body: "See when stock was last verified and updated." },
  ],
  faqs: [
    { q: "What does 'factory surplus' mean?", a: "Surplus is excess production, cancelled export orders, or end-of-season stock that the factory needs to liquidate quickly." },
    { q: "Is the stock new?", a: "Yes — surplus is unsold new stock, not used. Some lots may be export-rejects with minor cosmetic flaws; the listing will say so." },
    { q: "Can I inspect before buying?", a: "Yes. Warehouse-verified suppliers welcome visits. Use the map and contact details on each shop page." },
    { q: "Are there bulk discounts?", a: "Most surplus lots are already at clearance pricing. Larger MOQs unlock further per-piece discounts — negotiate directly via WhatsApp." },
  ],
};

export const Route = createFileRoute("/factory-surplus-stock")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESC },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESC },
      { property: "og:url", content: URL },
      { property: "og:type", content: "website" },
    ],
    links: [{ rel: "canonical", href: URL }],
    scripts: [{ type: "application/ld+json", children: JSON.stringify(categoryJsonLd(config, URL)) }],
  }),
  component: () => <CategoryLanding config={config} />,
});
