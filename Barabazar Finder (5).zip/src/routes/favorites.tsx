import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useEffect } from "react";
import { Heart, MapPin, Bookmark } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { SiteHeader } from "@/components/SiteHeader";

export const Route = createFileRoute("/favorites")({
  head: () => ({ meta: [{ title: "Saved shops — Digital Barabazar" }] }),
  component: FavoritesPage,
});

function FavoritesPage() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => { if (!loading && !user) navigate({ to: "/login" }); }, [loading, user, navigate]);

  const { data: favs } = useQuery({
    enabled: !!user,
    queryKey: ["favorites", user?.id],
    queryFn: async () => {
      const { data } = await supabase.from("favorites")
        .select("id, shops(id, name, slug, address, area, verified)")
        .eq("user_id", user!.id)
        .order("created_at", { ascending: false });
      return data ?? [];
    },
  });

  return (
    <div className="min-h-screen">
      <SiteHeader />
      <main className="container mx-auto px-4 py-8 max-w-4xl">
        <div className="flex items-center justify-between gap-3 flex-wrap mb-6">
          <h1 className="font-display text-4xl flex items-center gap-2"><Heart className="h-7 w-7 text-primary" />Saved shops</h1>
          <Link to="/saved-searches" className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-4 py-2 text-sm font-medium hover:border-primary transition">
            <Bookmark className="h-4 w-4 text-primary" /> Saved searches
          </Link>
        </div>
        {(!favs || favs.length === 0) ? (
          <div className="rounded-lg border-2 border-dashed border-border p-12 text-center text-muted-foreground">
            No saved shops yet. Tap the heart on any shop to save it.
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 gap-4">
            {favs.map((f: any) => f.shops && (
              <Link key={f.id} to="/shop/$slug" params={{ slug: f.shops.slug }}
                className="rounded-xl border-2 border-border bg-card p-4 hover:border-primary transition">
                <div className="font-display text-xl text-foreground">{f.shops.name}{f.shops.verified && <span className="ml-2 text-xs text-accent">✓ Verified</span>}</div>
                <div className="text-sm text-muted-foreground mt-1 flex items-center gap-1"><MapPin className="h-3 w-3" />{f.shops.area ?? f.shops.address}</div>
              </Link>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
