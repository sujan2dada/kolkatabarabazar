import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { MapPin, Phone, MessageCircle, Clock, ExternalLink, ArrowLeft, Calendar, User, Package, Eye, ListChecks, MessageSquare } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { SiteHeader } from "@/components/SiteHeader";
import { ShopMap } from "@/components/ShopMap";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { FavoriteButton } from "@/components/FavoriteButton";
import { EnquiryDialog } from "@/components/EnquiryDialog";
import { ReportButton } from "@/components/ReportButton";
import { TrustBadges } from "@/components/TrustBadges";
import { TrustScoreBadge } from "@/components/TrustScore";
import { BuyerConfidenceBox } from "@/components/BuyerConfidenceBox";
import { ShopReviews, ShopReviewsSummary } from "@/components/ShopReviews";
import { responseTimeLabel } from "@/lib/trust";
import { freshnessLabel, stockLabel, telUrl, whatsappUrl, directionsUrl } from "@/lib/format";
import catApparel from "@/assets/cat-apparel.jpg";
import catElectronics from "@/assets/cat-electronics.jpg";
import catHome from "@/assets/cat-home.jpg";
import catGrocery from "@/assets/cat-grocery.jpg";
import heroImg from "@/assets/hero-warehouse.jpg";

const FALLBACKS = [catApparel, catElectronics, catHome, catGrocery];

export const Route = createFileRoute("/shop/$slug")({
  loader: async ({ params }) => {
    const { data: shop } = await supabase
      .from("shops")
      .select("name, slug, description, address, area, phone, whatsapp, photos, logo_url, lat, lng, categories(name)")
      .eq("slug", params.slug)
      .maybeSingle();
    return { shop };
  },
  head: ({ params, loaderData }) => {
    const s: any = loaderData?.shop;
    const name = s?.name ?? params.slug;
    const cat = s?.categories?.name ?? "wholesale";
    const area = s?.area ?? "Kolkata";
    const title = `${name} — ${cat} Wholesale Supplier in ${area} | Kolkatabarabazar.in`;
    const desc = s?.description
      ? String(s.description).slice(0, 160)
      : `${name} is a verified ${cat} wholesale supplier in ${area}. Contact for factory surplus, liquidation stock, MOQ & pricing on Kolkatabarabazar.in.`;
    const url = `https://kolkatabarabazar.in/shop/${params.slug}`;
    const img = s?.photos?.[0] ?? s?.logo_url ?? undefined;
    return {
      meta: [
        { title },
        { name: "description", content: desc },
        { property: "og:title", content: title },
        { property: "og:description", content: desc },
        { property: "og:url", content: url },
        { property: "og:type", content: "website" },
        ...(img ? [{ property: "og:image", content: img }, { name: "twitter:image", content: img }] : []),
      ],
      links: [{ rel: "canonical", href: url }],
      scripts: s
        ? [
            {
              type: "application/ld+json",
              children: JSON.stringify({
                "@context": "https://schema.org",
                "@type": "LocalBusiness",
                name,
                description: desc,
                image: img,
                telephone: s.phone ?? undefined,
                address: s.address
                  ? { "@type": "PostalAddress", streetAddress: s.address, addressLocality: area, addressCountry: "IN" }
                  : undefined,
                geo: s.lat && s.lng ? { "@type": "GeoCoordinates", latitude: s.lat, longitude: s.lng } : undefined,
                url,
              }),
            },
          ]
        : undefined,
    };
  },
  component: ShopPage,
  errorComponent: ({ error }) => <div className="p-8">Error: {error.message}</div>,
  notFoundComponent: () => <div className="p-8">Supplier not found.</div>,
});

function ShopPage() {
  const { slug } = Route.useParams();

  const { data: shop, isLoading } = useQuery({
    queryKey: ["shop", slug],
    queryFn: async () => {
      const { data } = await supabase.from("shops")
        .select("*, categories(name, slug)").eq("slug", slug).maybeSingle();
      if (!data) throw notFound();
      return data;
    },
  });

  const { data: items } = useQuery({
    enabled: !!shop?.id,
    queryKey: ["shop-products", shop?.id],
    queryFn: async () => {
      const { data } = await supabase.from("shop_products")
        .select("id, price, stock, moq, stock_status, updated_at, products(id, name, slug, image_url)")
        .eq("shop_id", shop!.id).order("price", { ascending: true });
      return data ?? [];
    },
  });

  if (isLoading) return <div className="min-h-screen"><SiteHeader /><div className="p-8">Loading…</div></div>;
  if (!shop) return null;

  const cover = (shop.photos && shop.photos[0]) || heroImg;
  const photos: string[] = shop.photos && shop.photos.length > 0 ? shop.photos : [];

  return (
    <div className="min-h-screen">
      <SiteHeader />

      {/* COVER */}
      <div className="relative">
        <div className="h-48 sm:h-64 overflow-hidden">
          <img src={cover} alt="" className="h-full w-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/40 to-transparent" />
        </div>
      </div>

      <main className="container mx-auto px-4 -mt-16 pb-12 max-w-6xl relative">
        <Link to="/" className="inline-flex items-center gap-1 text-sm text-background hover:text-background/80 mb-3 absolute top-[-3rem] left-4">
          <ArrowLeft className="h-4 w-4" />Back
        </Link>

        <div className="grid lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <div className="rounded-3xl border border-border bg-card p-6 shadow-float">
              <div className="flex items-start gap-4">
                <div className="h-20 w-20 rounded-2xl bg-gradient-to-br from-primary to-primary/70 text-primary-foreground flex items-center justify-center text-3xl shrink-0 shadow-float">
                  🏭
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h1 className="font-display text-3xl sm:text-4xl text-foreground">{shop.name}</h1>
                    <TrustScoreBadge shop={shop as any} />
                    <ShopReviewsSummary shopId={shop.id} />
                  </div>
                  {(shop as any).categories?.name && (
                    <div className="text-sm text-muted-foreground mt-1">{(shop as any).categories.name}</div>
                  )}
                  <div className="mt-3"><TrustBadges shop={shop as any} /></div>
                  {shop.description && <p className="mt-3 text-foreground">{shop.description}</p>}
                </div>
              </div>

              <div className="mt-6 grid sm:grid-cols-2 gap-3 text-sm">
                <div className="flex items-start gap-2"><MapPin className="h-4 w-4 mt-0.5 text-primary shrink-0" /><span>{shop.address}{shop.area && ` · ${shop.area}`}</span></div>
                {shop.hours && <div className="flex items-start gap-2"><Clock className="h-4 w-4 mt-0.5 text-primary shrink-0" /><span>{shop.hours}</span></div>}
                {shop.owner_name && <div className="flex items-start gap-2"><User className="h-4 w-4 mt-0.5 text-primary shrink-0" /><span>{shop.owner_name}</span></div>}
                {shop.years_in_business != null && <div className="flex items-start gap-2"><Calendar className="h-4 w-4 mt-0.5 text-primary shrink-0" /><span>{shop.years_in_business}+ years in business</span></div>}
                {(shop as any).total_views != null && <div className="flex items-start gap-2"><Eye className="h-4 w-4 mt-0.5 text-primary shrink-0" /><span>{(shop as any).total_views.toLocaleString()} profile views</span></div>}
                {(shop as any).response_rate != null && <div className="flex items-start gap-2"><MessageSquare className="h-4 w-4 mt-0.5 text-primary shrink-0" /><span>{(shop as any).response_rate}% response rate · {responseTimeLabel((shop as any).avg_response_minutes)}</span></div>}
                {items && <div className="flex items-start gap-2"><ListChecks className="h-4 w-4 mt-0.5 text-primary shrink-0" /><span>{items.length} active listing{items.length === 1 ? "" : "s"}</span></div>}
              </div>

              <div className="mt-5 flex flex-wrap gap-2">
                {shop.whatsapp && (
                  <Button asChild className="bg-whatsapp hover:bg-whatsapp/90 text-white">
                    <a href={whatsappUrl(shop.whatsapp, `Hi ${shop.name}, I'd like to enquire about your stock.`)} target="_blank" rel="noopener noreferrer">
                      <MessageCircle className="h-4 w-4 mr-1" />WhatsApp
                    </a>
                  </Button>
                )}
                {shop.phone && (
                  <Button asChild variant="outline"><a href={telUrl(shop.phone)}><Phone className="h-4 w-4 mr-1" />Call {shop.phone}</a></Button>
                )}
                <EnquiryDialog shopId={shop.id} trigger={<Button variant="outline"><Package className="h-4 w-4 mr-1" />Bulk enquiry</Button>} />
                {shop.lat != null && shop.lng != null && (
                  <Button asChild variant="ghost">
                    <a href={directionsUrl(shop.lat, shop.lng)} target="_blank" rel="noopener noreferrer">
                      <ExternalLink className="h-4 w-4 mr-1" />Directions
                    </a>
                  </Button>
                )}
                <FavoriteButton shopId={shop.id} />
                <ReportButton targetType="shop" targetId={shop.id} />
              </div>
            </div>

            {photos.length > 0 && (
              <div className="rounded-3xl border border-border bg-card p-4">
                <h2 className="font-display text-xl mb-3">Warehouse photos</h2>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {photos.map((p: string, i: number) => (
                    <img key={i} src={p} alt="" loading="lazy" className="h-32 w-full object-cover rounded-xl border border-border" />
                  ))}
                </div>
              </div>
            )}

            <div className="rounded-3xl border border-border bg-card p-5">
              <h2 className="font-display text-2xl mb-4">Live clearance lots ({items?.length ?? 0})</h2>
              {!items || items.length === 0 ? (
                <p className="text-muted-foreground text-sm">No products listed yet.</p>
              ) : (
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  {items.map((it: any, i) => {
                    const stock = stockLabel(it.stock_status);
                    const img = it.products?.image_url || FALLBACKS[i % FALLBACKS.length];
                    return (
                      <Link key={it.id} to="/product/$slug" params={{ slug: it.products.slug }}
                        className="group rounded-2xl overflow-hidden bg-background ring-1 ring-border hover:ring-primary/40 transition shadow-float">
                        <div className="aspect-square overflow-hidden bg-secondary">
                          <img src={img} alt={it.products.name} loading="lazy" className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-500" />
                        </div>
                        <div className="p-3">
                          <div className="font-semibold text-sm line-clamp-1">{it.products.name}</div>
                          <div className="mt-1 flex items-baseline justify-between">
                            <span className="font-display text-primary text-xl text-black">₹{Number(it.price).toFixed(0)}</span>
                            <span className="text-[10px] text-muted-foreground">MOQ {it.moq}</span>
                          </div>
                          <div className="mt-1 flex items-center gap-1.5">
                            <span className={`px-1.5 py-0.5 rounded border text-[10px] ${stock.cls}`}>{stock.text}</span>
                            <span className="text-[10px] text-muted-foreground">{freshnessLabel(it.updated_at)}</span>
                          </div>
                        </div>
                      </Link>
                    );
                  })}
                </div>
              )}
            </div>
          </div>

          <div className="space-y-4 lg:sticky lg:top-24 lg:self-start">
            <BuyerConfidenceBox shop={shop as any} lastListingUpdate={items?.[0]?.updated_at ?? null} />
            <div className="rounded-3xl border border-border bg-card p-3 shadow-float">
              {shop.lat != null && shop.lng != null ? (
                <ShopMap lat={shop.lat} lng={shop.lng} name={shop.name} />
              ) : (
                <div className="h-80 flex items-center justify-center text-muted-foreground text-sm">No location set</div>
              )}
            </div>

            <div className="mt-6">
              <ShopReviews shopId={shop.id} />
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
