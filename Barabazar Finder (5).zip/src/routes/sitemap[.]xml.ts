import { createFileRoute } from "@tanstack/react-router";
import type {} from "@tanstack/react-start";
import { createClient } from "@supabase/supabase-js";

const BASE_URL = "https://kolkatabarabazar.in";

interface SitemapEntry {
  path: string;
  lastmod?: string;
  changefreq?: "always" | "hourly" | "daily" | "weekly" | "monthly" | "yearly" | "never";
  priority?: string;
}

const STATIC_ENTRIES: SitemapEntry[] = [
  { path: "/", changefreq: "daily", priority: "1.0" },
  { path: "/search", changefreq: "daily", priority: "0.9" },
  { path: "/opportunities", changefreq: "weekly", priority: "0.9" },
  { path: "/find-suppliers", changefreq: "weekly", priority: "0.8" },
  { path: "/brands", changefreq: "weekly", priority: "0.8" },
  { path: "/pricing", changefreq: "monthly", priority: "0.7" },
  { path: "/factory-surplus-stock", changefreq: "weekly", priority: "0.9" },
  { path: "/garment-liquidation", changefreq: "weekly", priority: "0.9" },
  { path: "/electronics-clearance", changefreq: "weekly", priority: "0.9" },
  { path: "/mobile-accessories-wholesale", changefreq: "weekly", priority: "0.9" },
  { path: "/franchise-opportunities", changefreq: "weekly", priority: "0.8" },
  { path: "/distributor-opportunities", changefreq: "weekly", priority: "0.8" },
  { path: "/dealer-opportunities", changefreq: "weekly", priority: "0.8" },
  { path: "/write-to-us", changefreq: "yearly", priority: "0.3" },
];

export const Route = createFileRoute("/sitemap.xml")({
  server: {
    handlers: {
      GET: async () => {
        const entries: SitemapEntry[] = [...STATIC_ENTRIES];

        try {
          const supabase = createClient(
            process.env.SUPABASE_URL ?? import.meta.env.VITE_SUPABASE_URL!,
            process.env.SUPABASE_PUBLISHABLE_KEY ?? import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY!,
            { auth: { persistSession: false, autoRefreshToken: false } },
          );

          const [{ data: products }, { data: shops }, { data: brands }, { data: opps }] = await Promise.all([
            supabase.from("products").select("slug, updated_at").limit(2000),
            supabase.from("shops").select("slug, updated_at").eq("approved", true).limit(2000),
            supabase.from("brands").select("slug, updated_at").limit(500),
            supabase.from("opportunities").select("slug, updated_at").limit(500),
          ]);

          for (const p of products ?? []) {
            if (!p.slug) continue;
            entries.push({ path: `/product/${p.slug}`, lastmod: p.updated_at, changefreq: "weekly", priority: "0.7" });
          }
          for (const s of shops ?? []) {
            if (!s.slug) continue;
            entries.push({ path: `/shop/${s.slug}`, lastmod: s.updated_at, changefreq: "weekly", priority: "0.7" });
          }
          for (const b of brands ?? []) {
            if (!b.slug) continue;
            entries.push({ path: `/brand/${b.slug}`, lastmod: b.updated_at, changefreq: "weekly", priority: "0.6" });
          }
          for (const o of opps ?? []) {
            if (!o.slug) continue;
            entries.push({ path: `/opportunity/${o.slug}`, lastmod: o.updated_at, changefreq: "weekly", priority: "0.6" });
          }
        } catch (err) {
          console.error("sitemap dynamic entries failed", err);
        }

        const urls = entries.map((e) =>
          [
            `  <url>`,
            `    <loc>${BASE_URL}${e.path}</loc>`,
            e.lastmod ? `    <lastmod>${new Date(e.lastmod).toISOString()}</lastmod>` : null,
            e.changefreq ? `    <changefreq>${e.changefreq}</changefreq>` : null,
            e.priority ? `    <priority>${e.priority}</priority>` : null,
            `  </url>`,
          ].filter(Boolean).join("\n"),
        );

        const xml = [
          `<?xml version="1.0" encoding="UTF-8"?>`,
          `<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">`,
          ...urls,
          `</urlset>`,
        ].join("\n");

        return new Response(xml, {
          headers: {
            "Content-Type": "application/xml",
            "Cache-Control": "public, max-age=3600",
          },
        });
      },
    },
  },
});
