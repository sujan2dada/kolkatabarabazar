import { createFileRoute } from "@tanstack/react-router";
import { CategoryLanding, categoryJsonLd, type CategoryLandingConfig } from "@/components/CategoryLanding";
import hero from "@/assets/cat-apparel.jpg";

const URL = "https://barabazar-finder.lovable.app/garment-liquidation";
const TITLE = "Garment Liquidation — Wholesale Apparel Clearance Lots Online";
const DESC = "Buy garment liquidation lots from Kolkata's largest apparel hub. Branded surplus, export rejects and seasonal clearance — verified suppliers, bulk MOQs.";

const config: CategoryLandingConfig = {
  slug: "garment-liquidation",
  h1: "Garment Liquidation Lots",
  tagline: "Branded apparel surplus and export-reject clearance lots.",
  intro:
    "Kolkata's Burrabazar is India's wholesale apparel heart. Browse live garment liquidation lots — men's, women's, kids', innerwear and ethnicwear — from verified manufacturers and exporters clearing surplus stock at unbeatable prices.",
  heroImage: hero,
  search: { category: "clothing" },
  benefits: [
    { icon: "price", title: "₹50–200 per piece", body: "Bulk lots starting at clearance per-piece pricing." },
    { icon: "verified", title: "Mill-direct sellers", body: "Skip agents — buy from the manufacturer or exporter." },
    { icon: "trust", title: "Lot size shown", body: "Every listing shows lot size, size ratio and condition." },
    { icon: "fast", title: "Pan-India dispatch", body: "Most lots ship within 48 hours across India." },
  ],
  faqs: [
    { q: "What kind of garments are available?", a: "Men's shirts, t-shirts, denim, women's kurtis, sarees, dresses, kidswear, innerwear and ethnicwear — both branded surplus and export rejects." },
    { q: "Can I pick sizes and colors?", a: "Most lots are sold as mixed assortments. The listing shows the size ratio. Pre-sorted lots may cost slightly more." },
    { q: "What are export rejects?", a: "Garments rejected from export orders due to minor stitching or cosmetic flaws. Quality is otherwise export-grade." },
    { q: "Do you offer mixed lots across categories?", a: "Yes — many suppliers offer combo lots. Filter by lot size and contact the supplier for custom assortments." },
  ],
};

export const Route = createFileRoute("/garment-liquidation")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESC },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESC },
      { property: "og:url", content: URL },
      { property: "og:type", content: "website" },
    ],
    links: [{ rel: "canonical", href: URL }],
    scripts: [{ type: "application/ld+json", children: JSON.stringify(categoryJsonLd(config, URL)) }],
  }),
  component: () => <CategoryLanding config={config} />,
});
