import { createFileRoute, notFound } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { SiteHeader } from "@/components/SiteHeader";
import { OpportunityCard, type OpportunityRow } from "@/components/OpportunityCard";
import { LeadInquiryForm } from "@/components/LeadInquiryForm";
import { BadgeCheck, Globe } from "lucide-react";
import { FadeIn } from "@/components/motion/FadeIn";

export const Route = createFileRoute("/brand/$slug")({
  head: ({ params }) => ({
    meta: [
      { title: `${params.slug} Franchise & Distributor Opportunities — Kolkatabarabazar` },
      { name: "description", content: `Apply for franchise, distributor or dealer opportunities with ${params.slug}. Verified brand on Kolkatabarabazar.` },
      { rel: "canonical", href: `/brand/${params.slug}` },
    ],
  }),
  component: BrandPage,
});

function BrandPage() {
  const { slug } = Route.useParams();
  const { data: brand, isLoading } = useQuery({
    queryKey: ["brand", slug],
    queryFn: async () => {
      const { data } = await supabase.from("brands").select("*").eq("slug", slug).maybeSingle();
      if (!data) throw notFound();
      return data;
    },
  });
  const { data: opps } = useQuery({
    queryKey: ["brand-opps", brand?.id],
    enabled: !!brand?.id,
    queryFn: async () => {
      const { data } = await supabase.from("opportunities")
        .select("id, slug, title, type, category, investment_min, investment_max, margin_min, margin_max, territory, image_url, featured, brands(name, slug, logo_url, verified)")
        .eq("brand_id", brand!.id).eq("approved", true);
      return (data ?? []) as unknown as OpportunityRow[];
    },
  });

  if (isLoading) return <div className="min-h-screen"><SiteHeader /></div>;
  if (!brand) return null;

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <section className="container mx-auto px-4 py-8">
        <FadeIn>
          <div className="rounded-3xl bg-gradient-to-br from-primary/15 via-card to-accent/10 border border-border p-6 sm:p-8 shadow-float flex items-center gap-5">
            <div className="h-20 w-20 sm:h-24 sm:w-24 shrink-0 rounded-2xl bg-secondary flex items-center justify-center overflow-hidden">
              {brand.logo_url ? <img src={brand.logo_url} alt={brand.name} className="h-full w-full object-contain p-2" />
                : <span className="font-display text-4xl text-muted-foreground">{brand.name?.[0]}</span>}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-display text-2xl sm:text-3xl">{brand.name}</h1>
                {brand.verified && <BadgeCheck className="h-5 w-5 text-primary" />}
              </div>
              {brand.category && <div className="text-sm text-muted-foreground">{brand.category}</div>}
              {brand.description && <p className="text-sm mt-2 max-w-2xl">{brand.description}</p>}
              {brand.website && (
                <a href={brand.website} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 text-sm text-primary mt-2 hover:underline">
                  <Globe className="h-3.5 w-3.5" /> Visit website
                </a>
              )}
            </div>
          </div>
        </FadeIn>

        <div className="grid lg:grid-cols-3 gap-6 mt-8">
          <div className="lg:col-span-2">
            <h2 className="font-display text-xl mb-3">Open opportunities</h2>
            <div className="grid sm:grid-cols-2 gap-3">
              {(opps ?? []).map((o) => <OpportunityCard key={o.id} o={o} />)}
              {opps && opps.length === 0 && (
                <div className="sm:col-span-2 py-12 text-center text-muted-foreground rounded-2xl border border-dashed border-border">
                  No active openings — submit an inquiry below and the brand will reach out.
                </div>
              )}
            </div>
          </div>
          <aside className="rounded-2xl bg-card border border-border p-5 shadow-float h-fit lg:sticky lg:top-24">
            <h3 className="font-display text-xl">Inquire with {brand.name}</h3>
            <p className="text-sm text-muted-foreground mt-1 mb-4">Get a callback within 48 hours.</p>
            <LeadInquiryForm compact brandId={brand.id} brandName={brand.name} />
          </aside>
        </div>
      </section>
    </div>
  );
}
