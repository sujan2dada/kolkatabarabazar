import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { SiteHeader } from "@/components/SiteHeader";
import { OpportunityCard, type OpportunityRow } from "@/components/OpportunityCard";
import { LeadInquiryForm } from "@/components/LeadInquiryForm";
import { FadeIn } from "@/components/motion/FadeIn";
import { CheckCircle2 } from "lucide-react";

export const Route = createFileRoute("/dealer-opportunities")({
  head: () => ({
    meta: [
      { title: "Become a Dealer — Apply Online | Kolkatabarabazar" },
      { name: "description", content: "Become an authorised dealer for top Indian brands. Get exclusive territory rights, attractive margins and marketing support. Apply online today." },
      { property: "og:title", content: "Become a Dealer in India" },
      { property: "og:description", content: "Exclusive territory · Attractive margins · Marketing support. Apply online." },
      { rel: "canonical", href: "/dealer-opportunities" },
    ],
  }),
  component: DealerPage,
});

const BENEFITS = [
  "Exclusive territory rights",
  "Margins up to 35%",
  "Marketing & POSM support",
  "Dedicated account manager",
  "Easy credit terms",
  "Verified, trusted brands",
];

function DealerPage() {
  const { data: opps } = useQuery({
    queryKey: ["opps", "dealer"],
    queryFn: async () => {
      const { data } = await supabase.from("opportunities")
        .select("id, slug, title, type, category, investment_min, investment_max, margin_min, margin_max, territory, image_url, featured, brands(name, slug, logo_url, verified)")
        .eq("type", "dealer").eq("approved", true).order("featured", { ascending: false });
      return (data ?? []) as unknown as OpportunityRow[];
    },
  });

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <section className="container mx-auto px-4 py-8">
        <FadeIn>
          <div className="rounded-3xl bg-gradient-to-br from-emerald-500 to-teal-600 text-white p-6 sm:p-10 shadow-float">
            <h1 className="font-display text-3xl sm:text-4xl">Become a Dealer</h1>
            <p className="mt-2 max-w-2xl opacity-95">Partner with India's most trusted brands. Get exclusive territory, attractive margins and full marketing support.</p>
            <ul className="mt-4 grid sm:grid-cols-2 gap-2 text-sm">
              {BENEFITS.map((b) => (
                <li key={b} className="flex items-center gap-2"><CheckCircle2 className="h-4 w-4" />{b}</li>
              ))}
            </ul>
          </div>
        </FadeIn>

        <div className="grid lg:grid-cols-3 gap-6 mt-8">
          <div className="lg:col-span-2 grid sm:grid-cols-2 gap-3">
            {(opps ?? []).map((o) => <OpportunityCard key={o.id} o={o} />)}
            {opps && opps.length === 0 && (
              <div className="sm:col-span-2 py-12 text-center text-muted-foreground rounded-2xl border border-dashed border-border">
                No dealer opportunities listed yet — submit the form and we'll match you.
              </div>
            )}
          </div>
          <aside className="rounded-2xl bg-card border border-border p-5 shadow-float h-fit lg:sticky lg:top-24">
            <h3 className="font-display text-xl">Apply Online</h3>
            <p className="text-sm text-muted-foreground mt-1 mb-4">Tell us about yourself — brands will reach out within 48 hrs.</p>
            <LeadInquiryForm compact title="Dealer opportunity" />
          </aside>
        </div>
      </section>
    </div>
  );
}
