import { createFileRoute, Link } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { useMutation } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { motion, AnimatePresence } from "framer-motion";
import {
  Sparkles,
  Loader2,
  MessageCircle,
  Phone,
  MapPin,
  ShieldCheck,
  ArrowRight,
  Star,
  Package,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { SiteHeader } from "@/components/SiteHeader";
import { MobileBottomNav } from "@/components/MobileBottomNav";
import { aiMatchSuppliers } from "@/lib/ai-match.functions";
import { whatsappUrl, telUrl } from "@/lib/format";
import { trustScore, trustTier, lastActiveLabel } from "@/lib/trust";

const SAMPLES = [
  "Need cotton kurti wholesalers near Burrabazar, 500 pcs under ₹180",
  "Looking for 2000 mobile back covers under ₹15 each",
  "10000 surplus cotton t-shirts, mixed sizes, Howrah delivery",
  "Bulk basmati rice 500 kg, FMCG distributor wanted",
];

export const Route = createFileRoute("/find-suppliers")({
  head: () => ({
    meta: [
      { title: "AI Supplier Finder — Kolkatabarabazar.in" },
      {
        name: "description",
        content:
          "Tell us what you need in plain English, Hindi or Bengali. Our AI matches you to the best 5–10 verified Burrabazar wholesalers with instant WhatsApp inquiry.",
      },
    ],
  }),
  component: FindSuppliersPage,
});

function FindSuppliersPage() {
  const [query, setQuery] = useState("");
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [city, setCity] = useState("");

  const fn = useServerFn(aiMatchSuppliers);
  const m = useMutation({
    mutationFn: (payload: { query: string; buyerName: string; buyerPhone: string; buyerCity?: string }) =>
      fn({ data: payload }),
  });

  const onSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!query.trim() || !name.trim() || !phone.trim()) return;
    m.mutate({
      query: query.trim(),
      buyerName: name.trim(),
      buyerPhone: phone.trim(),
      buyerCity: city.trim() || undefined,
    });
  };

  const res = m.data;

  return (
    <div className="min-h-screen pb-20">
      <SiteHeader />
      <main className="container mx-auto px-4 py-6 sm:py-10 max-w-5xl">
        <section className="rounded-3xl bg-gradient-to-br from-primary/15 via-card to-accent/10 border border-border p-5 sm:p-8 shadow-float">
          <div className="flex items-center gap-2 mb-2">
            <span className="inline-flex items-center gap-1.5 rounded-full bg-primary text-primary-foreground px-3 py-1 text-xs font-semibold">
              <Sparkles className="h-3.5 w-3.5" /> AI Supplier Finder
            </span>
            <Badge variant="outline" className="text-[10px]">Beta</Badge>
          </div>
          <h1 className="font-display text-2xl sm:text-4xl text-foreground">
            Tell us what you need. We'll match the best wholesalers.
          </h1>
          <p className="text-muted-foreground text-sm sm:text-base mt-2 max-w-2xl">
            Describe your requirement in plain English, Hindi, or Bengali. Our AI scores 1000+ Burrabazar suppliers by
            category, area, MOQ, price and response speed — then routes you straight to WhatsApp.
          </p>

          <form onSubmit={onSubmit} className="mt-6 grid gap-3">
            <Textarea
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="e.g. Need cotton kurti wholesalers near Burrabazar, 500 pcs under ₹180"
              className="min-h-[90px] bg-background rounded-xl border-border"
              required
              minLength={5}
              maxLength={500}
            />
            <div className="grid sm:grid-cols-3 gap-3">
              <Input
                placeholder="Your name *"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
                maxLength={80}
                className="rounded-xl"
              />
              <Input
                placeholder="WhatsApp / phone *"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                required
                maxLength={20}
                pattern="[0-9+\-\s]+"
                className="rounded-xl"
              />
              <Input
                placeholder="City (optional)"
                value={city}
                onChange={(e) => setCity(e.target.value)}
                maxLength={60}
                className="rounded-xl"
              />
            </div>
            <Button type="submit" size="lg" disabled={m.isPending} className="rounded-xl w-full sm:w-auto sm:justify-self-start">
              {m.isPending ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Sparkles className="h-4 w-4 mr-2" />}
              Match me to suppliers
            </Button>
          </form>

          <div className="mt-4 flex flex-wrap gap-2">
            {SAMPLES.map((s) => (
              <button
                key={s}
                type="button"
                onClick={() => setQuery(s)}
                className="text-xs rounded-full border border-border bg-card px-3 py-1.5 hover:border-primary/40 hover:text-primary transition-colors"
              >
                {s}
              </button>
            ))}
          </div>

          {m.isError && (
            <div className="mt-4 rounded-xl bg-destructive/10 text-destructive border border-destructive/30 px-4 py-3 text-sm">
              {(m.error as Error).message}
            </div>
          )}
        </section>

        <AnimatePresence>
          {res && (
            <motion.section
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="mt-8"
            >
              <div className="flex flex-wrap items-end justify-between gap-3 mb-4">
                <div>
                  <h2 className="font-display text-xl sm:text-2xl">
                    {res.summary.matchCount > 0
                      ? `Top ${res.summary.matchCount} matched supplier${res.summary.matchCount === 1 ? "" : "s"}`
                      : "No matches yet"}
                  </h2>
                  <p className="text-sm text-muted-foreground">
                    Understood: <span className="font-medium text-foreground">{res.intent.normalized_product || "your request"}</span>
                    {res.intent.quantity > 0 && <> · {res.intent.quantity} units</>}
                    {res.intent.max_price > 0 && <> · under ₹{res.intent.max_price}</>}
                    {res.intent.area_hint && <> · {res.intent.area_hint}</>}
                  </p>
                </div>
                {res.summary.matchCount > 0 && (
                  <Badge variant="outline" className="text-xs">
                    Price range ₹{res.summary.minPrice} – ₹{res.summary.maxPrice}
                  </Badge>
                )}
              </div>

              {res.summary.matchCount === 0 ? (
                <div className="rounded-2xl border border-dashed border-border p-8 text-center text-muted-foreground">
                  No matching suppliers yet. Try a broader product description or remove the price cap.
                </div>
              ) : (
                <ul className="grid gap-3">
                  {res.matches.map((m, i) => {
                    const s = m.shop;
                    const tScore = trustScore(s);
                    const tier = trustTier(tScore);
                    const waMessage = `Hi ${s.name}, I'm looking for ${res.intent.normalized_product || "wholesale stock"}${res.intent.quantity > 0 ? ` (${res.intent.quantity} units)` : ""}${res.intent.max_price > 0 ? ` under ₹${res.intent.max_price}` : ""}. Saw your listing on Kolkatabarabazar.in. Please share best price & availability.`;
                    return (
                      <li
                        key={s.id}
                        className="rounded-2xl bg-card border border-border p-4 sm:p-5 hover:border-primary/40 hover:shadow-float transition"
                      >
                        <div className="flex flex-wrap gap-4">
                          <div className="flex items-center justify-center h-12 w-12 rounded-full bg-primary/15 text-primary font-display text-lg shrink-0">
                            #{i + 1}
                          </div>
                          <div className="flex-1 min-w-[200px]">
                            <div className="flex flex-wrap items-center gap-2">
                              <Link to="/shop/$slug" params={{ slug: s.slug }} className="font-display text-lg hover:text-primary">
                                {s.name}
                              </Link>
                              {s.verified && (
                                <Badge className="bg-primary/15 text-primary border-primary/30 border text-[10px]">
                                  <ShieldCheck className="h-3 w-3 mr-1" /> Verified
                                </Badge>
                              )}
                              <Badge variant="outline" className={`text-[10px] ${tier.cls}`}>
                                <Star className="h-3 w-3 mr-1" /> Trust {tScore} · {tier.label}
                              </Badge>
                            </div>
                            <div className="text-xs text-muted-foreground mt-1 flex flex-wrap gap-x-3 gap-y-1">
                              {s.area && <span className="inline-flex items-center"><MapPin className="h-3 w-3 mr-1" />{s.area}</span>}
                              <span>{lastActiveLabel(s)}</span>
                              {s.response_rate ? <span>{s.response_rate}% response</span> : null}
                              {s.years_in_business ? <span>{s.years_in_business}y in business</span> : null}
                            </div>
                            {m.product && (
                              <div className="text-xs text-muted-foreground mt-2 inline-flex items-center gap-1">
                                <Package className="h-3 w-3" /> Best offer:{" "}
                                <Link to="/product/$slug" params={{ slug: m.product.slug }} className="text-foreground hover:text-primary font-medium">
                                  {m.product.name}
                                </Link>
                              </div>
                            )}
                          </div>
                          <div className="text-right shrink-0">
                            <div className="font-display text-2xl text-primary">₹{m.offer.price.toFixed(0)}</div>
                            <div className="text-[11px] text-muted-foreground">MOQ {m.offer.moq} · Stock {m.offer.stock}</div>
                          </div>
                        </div>

                        <div className="mt-3 flex flex-wrap gap-2">
                          {s.whatsapp && (
                            <Button asChild size="sm" className="bg-whatsapp hover:bg-whatsapp/90 text-white">
                              <a href={whatsappUrl(s.whatsapp, waMessage)} target="_blank" rel="noopener noreferrer">
                                <MessageCircle className="h-3.5 w-3.5 mr-1.5" />
                                WhatsApp
                              </a>
                            </Button>
                          )}
                          {s.phone && (
                            <Button asChild size="sm" variant="outline">
                              <a href={telUrl(s.phone)}>
                                <Phone className="h-3.5 w-3.5 mr-1.5" /> Call
                              </a>
                            </Button>
                          )}
                          <Button asChild size="sm" variant="outline">
                            <Link to="/shop/$slug" params={{ slug: s.slug }}>
                              Visit store <ArrowRight className="h-3.5 w-3.5 ml-1" />
                            </Link>
                          </Button>
                          <span className="ml-auto text-[11px] text-muted-foreground self-center">
                            Match score {m.score}/100
                          </span>
                        </div>
                      </li>
                    );
                  })}
                </ul>
              )}
            </motion.section>
          )}
        </AnimatePresence>
      </main>
      <MobileBottomNav />
    </div>
  );
}
