import { createFileRoute } from "@tanstack/react-router";
import { CategoryLanding, categoryJsonLd, type CategoryLandingConfig } from "@/components/CategoryLanding";
import hero from "@/assets/cat-electronics.jpg";

const URL = "https://barabazar-finder.lovable.app/mobile-accessories-wholesale";
const TITLE = "Mobile Accessories Wholesale in Kolkata — Bulk & Clearance Stock";
const DESC = "Source mobile accessories at wholesale prices from verified Kolkata suppliers. Chargers, cables, earphones, covers — bulk MOQs, factory surplus & liquidation lots.";

const config: CategoryLandingConfig = {
  slug: "mobile-accessories-wholesale",
  h1: "Mobile Accessories Wholesale",
  tagline: "Chargers, cables, earphones & covers — factory-direct bulk pricing.",
  intro:
    "Kolkatabarabazar.in is India's wholesale clearance marketplace for mobile accessories. Compare live MOQs and per-piece prices from verified Burrabazar, Howrah and pan-India suppliers — from branded overstock to OEM surplus lots.",
  heroImage: hero,
  search: { q: "mobile", category: "electronics" },
  benefits: [
    { icon: "price", title: "Up to 70% off MRP", body: "Direct from importers and factory clearance — no middlemen." },
    { icon: "verified", title: "GST-verified sellers", body: "Every supplier is GST + mobile verified before listing." },
    { icon: "fast", title: "Same-day dispatch", body: "Most lots dispatch within 24 hours across India." },
    { icon: "trust", title: "Buyer protection", body: "WhatsApp the seller, verify stock, then pay." },
  ],
  faqs: [
    { q: "What is the minimum order quantity?", a: "MOQs typically start at 50–100 pieces per SKU. Each listing shows the exact MOQ." },
    { q: "Are these original branded accessories?", a: "Listings clearly mark whether the lot is branded surplus, OEM, or generic. Filter by brand on the search page." },
    { q: "Do suppliers ship across India?", a: "Yes — most Kolkata suppliers ship pan-India via Delhivery, Bluedart and local logistics partners." },
    { q: "Can I get samples?", a: "Many sellers offer paid samples. Contact them directly via WhatsApp from the listing." },
  ],
};

export const Route = createFileRoute("/mobile-accessories-wholesale")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESC },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESC },
      { property: "og:url", content: URL },
      { property: "og:type", content: "website" },
    ],
    links: [{ rel: "canonical", href: URL }],
    scripts: [{ type: "application/ld+json", children: JSON.stringify(categoryJsonLd(config, URL)) }],
  }),
  component: () => <CategoryLanding config={config} />,
});
