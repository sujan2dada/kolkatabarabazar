import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useState } from "react";
import { ArrowLeft } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { SiteHeader } from "@/components/SiteHeader";
import { ShopForm } from "@/components/ShopForm";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/shops/new")({
  head: () => ({ meta: [{ title: "New shop — Digital Barabazar" }] }),
  component: NewShop,
});

function NewShop() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [busy, setBusy] = useState(false);

  return (
    <div className="min-h-screen">
      <SiteHeader />
      <main className="container mx-auto px-4 py-8 max-w-3xl">
        <Link to="/dashboard" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-primary mb-4">
          <ArrowLeft className="h-4 w-4" />Dashboard
        </Link>
        <h1 className="font-display text-4xl text-foreground mb-6">Create a shop</h1>
        <div className="rounded-xl border-2 border-border bg-card p-6">
          <ShopForm
            submitLabel="Create shop"
            busy={busy}
            onSubmit={async (v) => {
              setBusy(true);
              const { data, error } = await supabase.from("shops").insert({
                owner_id: user!.id,
                name: v.name, slug: v.slug,
                description: v.description || null,
                address: v.address, area: v.area || null,
                phone: v.phone || null, whatsapp: v.whatsapp || null,
                hours: v.hours || null, owner_name: v.owner_name || null,
                years_in_business: v.years_in_business,
                photos: v.photos,
                category_id: v.category_id,
                lat: v.lat, lng: v.lng,
                approved: true,
              }).select("id").single();
              setBusy(false);
              if (error) toast.error(error.message);
              else {
                toast.success("Shop created");
                navigate({ to: "/shops/$id/products", params: { id: data!.id } });
              }
            }}
          />
        </div>
      </main>
    </div>
  );
}
