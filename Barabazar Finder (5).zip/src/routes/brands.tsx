import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { SiteHeader } from "@/components/SiteHeader";
import { BadgeCheck } from "lucide-react";
import { FadeIn, StaggerGrid, StaggerItem } from "@/components/motion/FadeIn";

export const Route = createFileRoute("/brands")({
  head: () => ({
    meta: [
      { title: "Top Brands offering Franchise & Distributor Opportunities — Kolkatabarabazar" },
      { name: "description", content: "Browse verified Indian brands offering franchise, distributor and dealer opportunities. Apply directly with the brand of your choice." },
      { property: "og:title", content: "Verified Brands — Kolkatabarabazar" },
      { property: "og:description", content: "Verified Indian brands offering franchise, distributor and dealer opportunities." },
      { rel: "canonical", href: "/brands" },
    ],
  }),
  component: BrandsPage,
});

function BrandsPage() {
  const { data: brands } = useQuery({
    queryKey: ["brands"],
    queryFn: async () => (await supabase.from("brands").select("*").order("featured", { ascending: false }).order("name")).data ?? [],
  });

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <section className="container mx-auto px-4 py-8">
        <FadeIn>
          <h1 className="font-display text-3xl sm:text-4xl">Verified Brands</h1>
          <p className="text-muted-foreground mt-2">Browse brands offering franchise, distributor and dealer opportunities.</p>
        </FadeIn>
        <StaggerGrid className="mt-6 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
          {(brands ?? []).map((b: any) => (
            <StaggerItem key={b.id}>
              <Link to="/brand/$slug" params={{ slug: b.slug }}
                className="group block rounded-2xl bg-card ring-1 ring-border hover:ring-primary/40 transition-all shadow-float p-4 text-center">
                <div className="aspect-square rounded-xl bg-secondary flex items-center justify-center overflow-hidden mb-3">
                  {b.logo_url ? <img src={b.logo_url} alt={b.name} className="h-full w-full object-contain p-3" />
                    : <span className="font-display text-3xl text-muted-foreground">{b.name?.[0]}</span>}
                </div>
                <div className="flex items-center justify-center gap-1">
                  <h3 className="font-display text-sm">{b.name}</h3>
                  {b.verified && <BadgeCheck className="h-4 w-4 text-primary" />}
                </div>
                {b.category && <div className="text-[11px] text-muted-foreground mt-0.5">{b.category}</div>}
              </Link>
            </StaggerItem>
          ))}
        </StaggerGrid>
        {brands && brands.length === 0 && (
          <div className="py-20 text-center text-muted-foreground">No brands listed yet.</div>
        )}
      </section>
    </div>
  );
}
