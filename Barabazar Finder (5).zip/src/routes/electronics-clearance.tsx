import { createFileRoute } from "@tanstack/react-router";
import { CategoryLanding, categoryJsonLd, type CategoryLandingConfig } from "@/components/CategoryLanding";
import hero from "@/assets/cat-electronics.jpg";

const URL = "https://barabazar-finder.lovable.app/electronics-clearance";
const TITLE = "Electronics Clearance — Wholesale Surplus & Liquidation Stock";
const DESC = "Wholesale electronics clearance: speakers, smartwatches, accessories, small appliances. Verified Kolkata suppliers, bulk MOQs, factory-direct prices.";

const config: CategoryLandingConfig = {
  slug: "electronics-clearance",
  h1: "Electronics Clearance Stock",
  tagline: "Surplus speakers, smartwatches, accessories & small appliances.",
  intro:
    "Source consumer electronics at clearance prices from verified Kolkata wholesalers and importers. Browse live lots of bluetooth speakers, smartwatches, earbuds, chargers, kitchen gadgets and small appliances — all with disclosed condition, warranty and dispatch time.",
  heroImage: hero,
  search: { category: "electronics" },
  benefits: [
    { icon: "price", title: "Importer-direct pricing", body: "Buy at landed cost from verified importers." },
    { icon: "verified", title: "GST + warranty info", body: "Listings show GST status and warranty terms upfront." },
    { icon: "trust", title: "Condition transparent", body: "New, refurbished, or open-box — clearly labelled." },
    { icon: "fast", title: "Quick response", body: "Suppliers respond on WhatsApp within minutes." },
  ],
  faqs: [
    { q: "What's available in electronics clearance?", a: "Bluetooth speakers, neckbands, earbuds, smartwatches, chargers, power banks, kitchen appliances, lighting and accessories." },
    { q: "Is warranty included?", a: "Branded surplus typically carries manufacturer warranty. Generic and OEM lots are sold as-is — check the listing." },
    { q: "Can I get GST invoice?", a: "Yes — all GST-verified suppliers provide proper tax invoices for B2B buyers." },
    { q: "How is stock condition graded?", a: "A-grade = sealed new, B-grade = open-box, refurb = tested working. Each listing specifies condition." },
  ],
};

export const Route = createFileRoute("/electronics-clearance")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESC },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESC },
      { property: "og:url", content: URL },
      { property: "og:type", content: "website" },
    ],
    links: [{ rel: "canonical", href: URL }],
    scripts: [{ type: "application/ld+json", children: JSON.stringify(categoryJsonLd(config, URL)) }],
  }),
  component: () => <CategoryLanding config={config} />,
});
