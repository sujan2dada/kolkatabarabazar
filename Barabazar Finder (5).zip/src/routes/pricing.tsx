import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Check, X, Sparkles, Crown, Zap, ShieldCheck, MessageCircle, Eye, TrendingUp,
  Users, Package, BadgeCheck, Lock, Star, ChevronRight, Headphones, BarChart3,
  Rocket, Award, ArrowRight,
} from "lucide-react";
import { SiteHeader } from "@/components/SiteHeader";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { FadeIn, StaggerGrid, StaggerItem } from "@/components/motion/FadeIn";

const CANONICAL = "https://kolkatabarabazar.in/pricing";

const FAQS = [
  { q: "What is included in the Free plan?", a: "A business profile, basic product listings, buyer discovery, limited monthly leads, direct WhatsApp/call buttons and community support — at zero cost for the first month." },
  { q: "How do buyer leads work?", a: "When a verified buyer enquires about your stock via WhatsApp, call, or our enquiry form, the lead is routed instantly to your dashboard with buyer name, city, quantity required, and contact." },
  { q: "Can I upgrade or downgrade anytime?", a: "Yes. You can switch plans from your seller dashboard at any time. Unused days on yearly plans are credited pro-rata to the new plan." },
  { q: "Do you charge any commission on orders?", a: "Never. Kolkatabarabazar is a subscription marketplace — you keep 100% of your order value. Buyers contact you directly." },
  { q: "How does seller verification work?", a: "We verify GST, mobile number, and warehouse address. Verified suppliers receive a trust badge and rank higher in search results." },
  { q: "Can I cancel anytime?", a: "Yes, cancel from your dashboard anytime. Your listings stay live until the end of the billing period." },
  { q: "What payment methods are supported?", a: "UPI, all major debit/credit cards, net banking, and bank transfer for Enterprise plans." },
  { q: "Do you provide GST invoices?", a: "Yes — every payment generates a GST-compliant tax invoice downloadable from your dashboard." },
];

const COMPARISON: { label: string; free: string | boolean; growth: string | boolean; ent: string | boolean }[] = [
  { label: "Business Profile",        free: true,             growth: true,                ent: true },
  { label: "Product Listings",        free: "3",              growth: "200",               ent: "Unlimited" },
  { label: "Buyer Leads / month",     free: "Limited",        growth: "Unlimited",         ent: "Unlimited + routed" },
  { label: "Analytics Dashboard",     free: false,            growth: true,                ent: "Advanced" },
  { label: "Featured Placement",      free: false,            growth: true,                ent: "Homepage banner" },
  { label: "Verified Seller Badge",   free: false,            growth: true,                ent: "Priority verification" },
  { label: "Priority Search Ranking", free: false,            growth: true,                ent: "Top of category" },
  { label: "API Access",              free: false,            growth: false,               ent: true },
  { label: "Custom Branding",         free: false,            growth: false,               ent: true },
  { label: "Support",                 free: "Community",      growth: "Email",             ent: "Dedicated manager" },
];

const TESTIMONIALS = [
  { name: "Rohit Agarwal",  type: "Garment Manufacturer", city: "Howrah",      review: "Cleared 8 lakh worth of surplus stock in 6 weeks. Buyer enquiries on WhatsApp every single day." },
  { name: "Sunita Devi",     type: "Distributor",           city: "Burrabazar",  review: "Found 12 new retail partners in 2 months. The verified buyer leads are genuine and quality." },
  { name: "Mohammed Akhtar", type: "Mobile Accessories Wholesaler", city: "Kolkata", review: "Growth plan paid for itself in the first week. The Featured Placement is a game-changer." },
  { name: "Priya Sharma",    type: "Retailer",              city: "Salt Lake",   review: "Sourcing factory surplus is so easy now. Saved 40% on inventory costs this quarter." },
];

const WA = (msg: string) => `https://wa.me/917384414113?text=${encodeURIComponent(msg)}`;

export const Route = createFileRoute("/pricing")({
  head: () => ({
    meta: [
      { title: "Pricing Plans | Kolkata Barabazar Marketplace" },
      { name: "description", content: "Choose the best marketplace plan for your wholesale business. Connect with buyers, distributors, retailers and grow faster — Free, Growth ₹1999/mo, Enterprise." },
      { name: "keywords", content: "wholesale marketplace pricing, seller subscription India, B2B pricing plans, Kolkata Barabazar plans, distributor marketplace" },
      { property: "og:title", content: "Pricing Plans | Kolkata Barabazar Marketplace" },
      { property: "og:description", content: "Grow your wholesale business with verified buyer leads, WhatsApp enquiries, and zero commission. Plans starting Free." },
      { property: "og:url", content: CANONICAL },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: "Pricing Plans | Kolkata Barabazar" },
      { name: "twitter:description", content: "Verified buyers, WhatsApp leads, zero commission. Plans starting Free." },
    ],
    links: [{ rel: "canonical", href: CANONICAL }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "FAQPage",
          mainEntity: FAQS.map((f) => ({
            "@type": "Question", name: f.q,
            acceptedAnswer: { "@type": "Answer", text: f.a },
          })),
        }),
      },
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "BreadcrumbList",
          itemListElement: [
            { "@type": "ListItem", position: 1, name: "Home",    item: "https://kolkatabarabazar.in/" },
            { "@type": "ListItem", position: 2, name: "Pricing", item: CANONICAL },
          ],
        }),
      },
    ],
  }),
  component: PricingPage,
});

function PricingPage() {
  const [yearly, setYearly] = useState(false);
  const growthPrice = yearly ? 19199 : 1999;

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />

      {/* Breadcrumb */}
      <nav aria-label="Breadcrumb" className="container mx-auto px-4 pt-4">
        <ol className="flex items-center gap-1.5 text-xs text-muted-foreground">
          <li><Link to="/" className="hover:text-primary">Home</Link></li>
          <li><ChevronRight className="h-3 w-3" /></li>
          <li className="text-foreground font-medium">Pricing</li>
        </ol>
      </nav>

      <main>
        {/* ============ HERO ============ */}
        <section className="relative overflow-hidden">
          <div className="absolute inset-0 -z-10">
            <div className="absolute top-0 left-1/4 h-72 w-72 rounded-full bg-primary/20 blur-3xl" />
            <div className="absolute top-20 right-1/4 h-72 w-72 rounded-full bg-accent/20 blur-3xl" />
          </div>
          <div className="container mx-auto px-4 pt-10 pb-12 sm:pt-16 sm:pb-16 max-w-5xl text-center">
            <FadeIn>
              <div className="inline-flex items-center gap-1.5 rounded-full glass px-3 py-1 text-xs font-semibold text-primary">
                <Sparkles className="h-3.5 w-3.5" /> Seller subscriptions
              </div>
              <h1 className="mt-5 font-display text-4xl sm:text-5xl md:text-6xl tracking-tight">
                Grow Your Wholesale Business <span className="text-primary">Faster</span>
              </h1>
              <p className="mt-4 text-base sm:text-lg text-muted-foreground max-w-2xl mx-auto">
                Connect with verified buyers, distributors, retailers and business partners across India.
              </p>

              <ul className="mt-6 flex flex-wrap items-center justify-center gap-x-5 gap-y-2 text-sm">
                {[
                  { icon: BadgeCheck, t: "Verified Business Leads" },
                  { icon: MessageCircle, t: "Direct WhatsApp Enquiries" },
                  { icon: Eye,          t: "Unlimited Visibility" },
                  { icon: ShieldCheck,  t: "No Commission on Sales" },
                ].map((f) => (
                  <li key={f.t} className="flex items-center gap-1.5 text-foreground/80">
                    <f.icon className="h-4 w-4 text-whatsapp" /> {f.t}
                  </li>
                ))}
              </ul>

              <div className="mt-7 flex flex-col sm:flex-row items-center justify-center gap-3">
                <Button asChild size="lg" className="rounded-full px-7 h-12 text-base shadow-float">
                  <Link to="/signup">Start Free <ArrowRight className="h-4 w-4" /></Link>
                </Button>
                <Button asChild size="lg" variant="outline" className="rounded-full px-7 h-12 text-base">
                  <a href="#compare">Compare Plans</a>
                </Button>
              </div>
            </FadeIn>
          </div>
        </section>

        {/* ============ PRICING TOGGLE + CARDS ============ */}
        <section id="plans" className="container mx-auto px-4 pb-16 max-w-6xl">
          <FadeIn className="flex justify-center mb-8">
            <BillingToggle yearly={yearly} onChange={setYearly} />
          </FadeIn>

          <StaggerGrid className="grid md:grid-cols-3 gap-5">
            {/* FREE */}
            <StaggerItem>
              <PlanCard
                icon={Zap}
                name="Free"
                tagline="Get started at zero cost."
                price="₹0"
                period={yearly ? "for 1st month" : "1st month free"}
                features={[
                  "Business Profile",
                  "Basic Listings (3)",
                  "Buyer Discovery",
                  "Limited Leads",
                  "Community Support",
                ]}
                ctaLabel="Start Free"
                ctaTo="/signup"
              />
            </StaggerItem>

            {/* GROWTH */}
            <StaggerItem>
              <PlanCard
                icon={Sparkles}
                name="Growth"
                tagline="For active wholesalers running regular clearance."
                price={`₹${growthPrice.toLocaleString("en-IN")}`}
                period={yearly ? "per year" : "per month"}
                features={[
                  "200 Product Listings",
                  "Featured Placement",
                  "WhatsApp Buyer Leads",
                  "Verified Seller Badge",
                  "Analytics Dashboard",
                  "Priority Search Ranking",
                  "Lead Notifications",
                  "Email Support",
                ]}
                ctaLabel="Start Growing"
                ctaHref={WA("Hi, I'd like to subscribe to the Growth plan on Kolkatabarabazar.in.")}
                highlight
                badge="Most Popular"
                savings={yearly ? "You save ₹4,789 / year" : undefined}
              />
            </StaggerItem>

            {/* ENTERPRISE */}
            <StaggerItem>
              <PlanCard
                icon={Crown}
                name="Enterprise"
                tagline="Warehouses, exporters, liquidation aggregators."
                price="Custom"
                period="talk to sales"
                features={[
                  "Unlimited Listings",
                  "Multi-Branch Management",
                  "Dedicated Account Manager",
                  "Bulk Product Uploads",
                  "API Integration",
                  "Advanced Analytics",
                  "Custom Branding",
                  "Premium Promotion",
                  "Priority Support",
                ]}
                ctaLabel="Contact Sales"
                ctaHref={WA("Hi, I'm interested in the Enterprise plan on Kolkatabarabazar.in.")}
              />
            </StaggerItem>
          </StaggerGrid>
        </section>

        {/* ============ WHY UPGRADE ============ */}
        <section className="bg-secondary/40 border-y border-border/60">
          <div className="container mx-auto px-4 py-14 max-w-6xl">
            <FadeIn className="text-center max-w-2xl mx-auto">
              <h2 className="font-display text-3xl sm:text-4xl">Why Businesses Choose Growth</h2>
              <p className="mt-2 text-muted-foreground">Verified suppliers on Growth see measurable lift within the first 30 days.</p>
            </FadeIn>
            <StaggerGrid className="mt-8 grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {[
                { icon: TrendingUp, t: "3x More Profile Views",      d: "Featured placement boosts discovery." },
                { icon: MessageCircle, t: "4x More Buyer Enquiries", d: "WhatsApp + call leads routed instantly." },
                { icon: Award,         t: "2x Higher Conversion",    d: "Verified badge converts more enquiries." },
                { icon: Rocket,        t: "Priority Ranking",         d: "Top of relevant category searches." },
              ].map((s) => (
                <StaggerItem key={s.t}>
                  <div className="h-full rounded-2xl border border-border bg-card p-5 shadow-soft">
                    <div className="h-10 w-10 rounded-xl bg-primary/10 text-primary flex items-center justify-center">
                      <s.icon className="h-5 w-5" />
                    </div>
                    <div className="mt-3 font-display text-lg">{s.t}</div>
                    <div className="text-sm text-muted-foreground mt-1">{s.d}</div>
                  </div>
                </StaggerItem>
              ))}
            </StaggerGrid>
          </div>
        </section>

        {/* ============ COMPARISON TABLE ============ */}
        <section id="compare" className="container mx-auto px-4 py-16 max-w-6xl">
          <FadeIn className="text-center max-w-2xl mx-auto mb-8">
            <h2 className="font-display text-3xl sm:text-4xl">Compare every feature</h2>
            <p className="mt-2 text-muted-foreground">Side-by-side details so you can pick what fits your business stage.</p>
          </FadeIn>

          <FadeIn className="overflow-x-auto rounded-2xl border border-border bg-card shadow-soft">
            <table className="w-full min-w-[640px] text-sm">
              <thead className="bg-secondary/60">
                <tr>
                  <th scope="col" className="text-left p-4 font-semibold">Feature</th>
                  <th scope="col" className="p-4 font-semibold text-center">Free</th>
                  <th scope="col" className="p-4 font-semibold text-center text-primary">
                    Growth <Badge className="ml-1 bg-primary text-primary-foreground">Popular</Badge>
                  </th>
                  <th scope="col" className="p-4 font-semibold text-center">Enterprise</th>
                </tr>
              </thead>
              <tbody>
                {COMPARISON.map((row, i) => (
                  <tr key={row.label} className={i % 2 ? "bg-secondary/20" : ""}>
                    <th scope="row" className="text-left p-4 font-medium">{row.label}</th>
                    <Cell value={row.free} />
                    <Cell value={row.growth} primary />
                    <Cell value={row.ent} />
                  </tr>
                ))}
                <tr className="bg-secondary/60">
                  <td className="p-4" />
                  <td className="p-4 text-center">
                    <Button asChild size="sm" variant="outline" className="rounded-full"><Link to="/signup">Start Free</Link></Button>
                  </td>
                  <td className="p-4 text-center">
                    <Button asChild size="sm" className="rounded-full"><a href={WA("Hi, I'd like Growth plan.")}>Start Growing</a></Button>
                  </td>
                  <td className="p-4 text-center">
                    <Button asChild size="sm" variant="outline" className="rounded-full"><a href={WA("Hi, I'm interested in Enterprise.")}>Contact</a></Button>
                  </td>
                </tr>
              </tbody>
            </table>
          </FadeIn>
        </section>

        {/* ============ TRUST / COUNTERS ============ */}
        <section className="bg-gradient-to-br from-primary/5 to-accent/10 border-y border-border/60">
          <div className="container mx-auto px-4 py-12 max-w-6xl grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { icon: Users,       n: "10,000+", l: "Businesses" },
              { icon: Package,     n: "50,000+", l: "Live Products" },
              { icon: BadgeCheck,  n: "100%",    l: "Verified Suppliers" },
              { icon: Lock,        n: "Secure",  l: "Encrypted Platform" },
            ].map((s) => (
              <FadeIn key={s.l} className="text-center rounded-2xl bg-card border border-border p-5 shadow-soft">
                <s.icon className="h-6 w-6 text-primary mx-auto" />
                <div className="mt-2 font-display text-3xl">{s.n}</div>
                <div className="text-xs uppercase tracking-wider text-muted-foreground mt-1">{s.l}</div>
              </FadeIn>
            ))}
          </div>
        </section>

        {/* ============ TESTIMONIALS ============ */}
        <section className="container mx-auto px-4 py-16 max-w-6xl">
          <FadeIn className="text-center max-w-2xl mx-auto mb-8">
            <h2 className="font-display text-3xl sm:text-4xl">Trusted by Bharat's wholesalers</h2>
            <p className="mt-2 text-muted-foreground">Real stories from manufacturers, distributors, and retailers.</p>
          </FadeIn>
          <div className="-mx-4 px-4 overflow-x-auto snap-x snap-mandatory scrollbar-hide">
            <div className="flex gap-4 pb-2">
              {TESTIMONIALS.map((t) => (
                <FadeIn key={t.name} className="snap-start shrink-0 w-[88%] sm:w-[400px]">
                  <div className="h-full rounded-2xl border border-border bg-card p-5 shadow-soft flex flex-col">
                    <div className="flex items-center gap-1 text-accent">
                      {[0,1,2,3,4].map(i => <Star key={i} className="h-4 w-4 fill-current" />)}
                    </div>
                    <p className="mt-3 text-sm text-foreground/90 flex-1">"{t.review}"</p>
                    <div className="mt-4 flex items-center gap-3 pt-4 border-t border-border">
                      <div className="h-10 w-10 rounded-full bg-primary/15 text-primary flex items-center justify-center font-semibold">
                        {t.name[0]}
                      </div>
                      <div>
                        <div className="text-sm font-semibold">{t.name}</div>
                        <div className="text-[11px] text-muted-foreground">{t.type} · {t.city}</div>
                      </div>
                    </div>
                  </div>
                </FadeIn>
              ))}
            </div>
          </div>
        </section>

        {/* ============ FAQ ============ */}
        <section className="bg-secondary/40 border-t border-border/60">
          <div className="container mx-auto px-4 py-16 max-w-3xl">
            <FadeIn className="text-center mb-8">
              <h2 className="font-display text-3xl sm:text-4xl">Frequently asked questions</h2>
              <p className="mt-2 text-muted-foreground">Everything about plans, billing, leads, and verification.</p>
            </FadeIn>
            <FadeIn>
              <Accordion type="single" collapsible className="rounded-2xl border border-border bg-card divide-y divide-border shadow-soft">
                {FAQS.map((f, i) => (
                  <AccordionItem key={i} value={`q-${i}`} className="border-0 px-5">
                    <AccordionTrigger className="text-left text-base font-semibold hover:no-underline">{f.q}</AccordionTrigger>
                    <AccordionContent className="text-sm text-muted-foreground leading-relaxed">{f.a}</AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </FadeIn>
          </div>
        </section>

        {/* ============ FINAL CTA ============ */}
        <section className="container mx-auto px-4 py-16 max-w-5xl">
          <FadeIn>
            <div className="relative overflow-hidden rounded-3xl border border-border bg-gradient-to-br from-primary to-primary/80 p-8 sm:p-12 text-primary-foreground shadow-float">
              <div className="absolute -top-10 -right-10 h-48 w-48 rounded-full bg-accent/40 blur-3xl" />
              <div className="relative grid md:grid-cols-[1fr_auto] items-center gap-6">
                <div>
                  <div className="font-display text-3xl sm:text-4xl">Ready to clear stock faster?</div>
                  <p className="mt-2 opacity-90 max-w-xl">Join 10,000+ verified wholesalers on Kolkatabarabazar and start receiving WhatsApp buyer enquiries today.</p>
                </div>
                <div className="flex flex-col sm:flex-row gap-3">
                  <Button asChild size="lg" variant="secondary" className="rounded-full h-12 px-7"><Link to="/signup">Start Free</Link></Button>
                  <Button asChild size="lg" className="rounded-full h-12 px-7 bg-accent text-accent-foreground hover:bg-accent/90"><a href={WA("Talk to sales about Kolkatabarabazar plans.")}><Headphones className="h-4 w-4" />Talk to sales</a></Button>
                </div>
              </div>
            </div>
          </FadeIn>
        </section>
      </main>

      {/* Sticky mobile CTA */}
      <div className="md:hidden sticky bottom-0 inset-x-0 z-30 border-t border-border bg-background/95 backdrop-blur px-3 py-2.5 pb-[max(0.625rem,env(safe-area-inset-bottom))] flex gap-2 shadow-[0_-8px_24px_-12px_rgba(0,0,0,0.15)]">
        <Button asChild variant="outline" className="flex-1 rounded-full h-11"><Link to="/signup">Start Free</Link></Button>
        <Button asChild className="flex-[1.2] rounded-full h-11 bg-accent text-accent-foreground hover:bg-accent/90">
          <a href={WA("Hi, I want the Growth plan.")}><Sparkles className="h-4 w-4" />Start Growing</a>
        </Button>
      </div>
    </div>
  );
}

/* ===== Sub-components ===== */

function BillingToggle({ yearly, onChange }: { yearly: boolean; onChange: (v: boolean) => void }) {
  return (
    <div className="inline-flex items-center gap-2">
      <div role="tablist" aria-label="Billing period" className="relative inline-flex rounded-full bg-secondary p-1 border border-border">
        <motion.div
          layout
          transition={{ type: "spring", stiffness: 400, damping: 32 }}
          className="absolute top-1 bottom-1 rounded-full bg-card shadow-soft border border-border"
          style={{ width: "calc(50% - 4px)", left: yearly ? "calc(50% + 0px)" : "4px" }}
        />
        <button
          role="tab"
          aria-selected={!yearly}
          onClick={() => onChange(false)}
          className={`relative z-10 px-5 h-9 text-sm font-semibold rounded-full transition ${!yearly ? "text-foreground" : "text-muted-foreground"}`}
        >Monthly</button>
        <button
          role="tab"
          aria-selected={yearly}
          onClick={() => onChange(true)}
          className={`relative z-10 px-5 h-9 text-sm font-semibold rounded-full transition flex items-center gap-2 ${yearly ? "text-foreground" : "text-muted-foreground"}`}
        >
          Yearly
          <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-whatsapp text-white">Save 20%</span>
        </button>
      </div>
    </div>
  );
}

function PlanCard({
  icon: Icon, name, tagline, price, period, features, ctaLabel, ctaTo, ctaHref, highlight, badge, savings,
}: {
  icon: any; name: string; tagline: string; price: string; period: string;
  features: string[]; ctaLabel: string; ctaTo?: string; ctaHref?: string;
  highlight?: boolean; badge?: string; savings?: string;
}) {
  return (
    <div className={`relative h-full flex flex-col rounded-3xl border bg-card p-6 transition shadow-float
      ${highlight ? "border-primary ring-2 ring-primary/20 md:scale-[1.02]" : "border-border"}`}>
      {badge && (
        <div className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-discount text-white text-[10px] font-bold px-3 py-1 shadow-float uppercase tracking-wider whitespace-nowrap">
          {badge}
        </div>
      )}
      <div className={`h-11 w-11 rounded-xl flex items-center justify-center ${highlight ? "bg-primary text-primary-foreground" : "bg-primary/10 text-primary"}`}>
        <Icon className="h-5 w-5" />
      </div>
      <div className="mt-4 font-display text-2xl">{name}</div>
      <p className="text-sm text-muted-foreground mt-1 min-h-[40px]">{tagline}</p>

      <div className="mt-4 flex items-baseline gap-1.5">
        <AnimatePresence mode="wait" initial={false}>
          <motion.span
            key={price}
            initial={{ y: 8, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: -8, opacity: 0 }}
            transition={{ duration: 0.18 }}
            className="font-display text-4xl text-foreground"
          >
            {price}
          </motion.span>
        </AnimatePresence>
        <span className="text-xs text-muted-foreground">{period}</span>
      </div>
      {savings && (
        <div className="mt-1 text-xs font-semibold text-whatsapp">{savings}</div>
      )}

      <ul className="mt-5 space-y-2 text-sm flex-1">
        {features.map((f) => (
          <li key={f} className="flex items-start gap-2">
            <Check className="h-4 w-4 mt-0.5 text-whatsapp shrink-0" /><span>{f}</span>
          </li>
        ))}
      </ul>

      {ctaTo ? (
        <Button asChild className={`w-full mt-6 h-11 rounded-full ${highlight ? "" : "bg-foreground text-background hover:bg-foreground/90"}`}>
          <Link to={ctaTo as any}>{ctaLabel}</Link>
        </Button>
      ) : (
        <Button asChild className={`w-full mt-6 h-11 rounded-full ${highlight ? "" : "bg-foreground text-background hover:bg-foreground/90"}`}>
          <a href={ctaHref} target="_blank" rel="noopener noreferrer">{ctaLabel}</a>
        </Button>
      )}

      {highlight && (
        <div className="mt-3 flex items-center justify-center gap-1.5 text-[11px] text-muted-foreground">
          <ShieldCheck className="h-3.5 w-3.5 text-whatsapp" /> 7-day money-back guarantee
        </div>
      )}
    </div>
  );
}

function Cell({ value, primary }: { value: string | boolean; primary?: boolean }) {
  const base = `p-4 text-center text-sm ${primary ? "bg-primary/5" : ""}`;
  if (value === true)  return <td className={base}><Check className="h-5 w-5 text-whatsapp mx-auto" aria-label="Included" /></td>;
  if (value === false) return <td className={base}><X className="h-5 w-5 text-muted-foreground/50 mx-auto" aria-label="Not included" /></td>;
  return <td className={`${base} font-medium`}>{value}</td>;
}
