import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";
import { useEffect, type ReactNode } from "react";

import appCss from "../styles.css?url";
import { reportLovableError } from "../lib/lovable-error-reporting";
import { AuthProvider } from "@/lib/auth";
import { Toaster } from "@/components/ui/sonner";
import { AnimatePresence, motion } from "framer-motion";
import { MobileBottomNav } from "@/components/MobileBottomNav";
import { WishlistDrawer } from "@/components/WishlistDrawer";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="font-display text-7xl text-primary">404</h1>
        <h2 className="mt-4 text-xl font-semibold text-foreground">Page not found</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          The page you're looking for doesn't exist.
        </p>
        <div className="mt-6">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Go home
          </Link>
        </div>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error(error);
  const router = useRouter();
  useEffect(() => {
    reportLovableError(error, { boundary: "tanstack_root_error_component" });
  }, [error]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-xl font-semibold tracking-tight text-foreground">
          Something went wrong
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">{error.message}</p>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <button
            onClick={() => { router.invalidate(); reset(); }}
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Try again
          </button>
          <a
            href="/"
            className="inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent"
          >
            Go home
          </a>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "Kolkatabarabazar.in — Wholesale Clearance Marketplace" },
      { name: "description", content: "India's wholesale marketplace for factory surplus, liquidation stock & overstock inventory. Source wholesale apparel, electronics & more from verified suppliers." },
      { name: "keywords", content: "wholesale marketplace India, factory surplus stock, liquidation stock India, wholesale apparel suppliers, electronics wholesale India, wholesale garments, electronics clearance, factory surplus, liquidation inventory, distributor opportunities" },
      { name: "author", content: "Kolkatabarabazar.in" },
      { name: "robots", content: "index, follow, max-image-preview:large" },
      { property: "og:title", content: "Kolkatabarabazar.in — Wholesale Clearance Marketplace" },
      { name: "twitter:title", content: "Kolkatabarabazar.in — Wholesale Clearance Marketplace" },
      { property: "og:description", content: "Factory surplus, overstock & liquidation deals from verified Indian wholesale suppliers." },
      { name: "twitter:description", content: "Factory surplus, overstock & liquidation deals from verified Indian wholesale suppliers." },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:type", content: "website" },
      { property: "og:site_name", content: "Kolkatabarabazar.in" },
      { property: "og:locale", content: "en_IN" },
    ],
    links: [{ rel: "stylesheet", href: appCss }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@graph": [
            {
              "@type": "Organization",
              "@id": "https://kolkatabarabazar.in/#organization",
              name: "Kolkatabarabazar.in",
              url: "https://kolkatabarabazar.in",
              logo: "https://kolkatabarabazar.in/favicon.ico",
              description: "India's wholesale clearance marketplace for factory surplus, liquidation stock & overstock inventory.",
              areaServed: "IN",
              sameAs: [
                "https://www.facebook.com/kolkatabarabazar",
                "https://www.instagram.com/kolkatabarabazar",
                "https://www.youtube.com/@kolkatabarabazar",
              ],
            },
            {
              "@type": "WebSite",
              "@id": "https://kolkatabarabazar.in/#website",
              url: "https://kolkatabarabazar.in",
              name: "Kolkatabarabazar.in",
              publisher: { "@id": "https://kolkatabarabazar.in/#organization" },
              potentialAction: {
                "@type": "SearchAction",
                target: "https://kolkatabarabazar.in/search?q={search_term_string}",
                "query-input": "required name=search_term_string",
              },
            },
          ],
        }),
      },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <head><HeadContent /></head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();
  const router = useRouter();
  const key = router.state.location.pathname;

  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <AnimatePresence mode="wait" initial={false}>
          <motion.main
            key={key}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
          >
            <Outlet />
          </motion.main>
        </AnimatePresence>
        <MobileBottomNav />
        <WishlistDrawer />
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}
