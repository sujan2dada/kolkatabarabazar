import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useEffect } from "react";
import type * as React from "react";
import { ArrowLeft, MapPin, Phone, MessageCircle, ExternalLink, Flame, Package, FileText, Shield, Truck, BadgeCheck, Store } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { SiteHeader } from "@/components/SiteHeader";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { EnquiryDialog } from "@/components/EnquiryDialog";
import { ReportButton } from "@/components/ReportButton";
import { TrustBadges } from "@/components/TrustBadges";
import { TrustScoreBadge } from "@/components/TrustScore";
import { BuyerConfidenceBox } from "@/components/BuyerConfidenceBox";
import { InventoryFreshness } from "@/components/InventoryFreshness";
import { StockAlertButton } from "@/components/StockAlertButton";
import { PriceAlertButton } from "@/components/PriceAlertButton";
import { ProductFavoriteButton } from "@/components/ProductFavoriteButton";
import { ProductGallery } from "@/components/ProductGallery";
import { pushRecent } from "@/lib/recently-viewed";
import { AIPriceIntelligence } from "@/components/AIPriceIntelligence";
import { freshnessLabel, stockLabel, telUrl, whatsappUrl, directionsUrl } from "@/lib/format";
import { trustScore } from "@/lib/trust";
import catApparel from "@/assets/cat-apparel.jpg";

export const Route = createFileRoute("/product/$slug")({
  loader: async ({ params }) => {
    const { data: product } = await supabase
      .from("products")
      .select("name, slug, description, image_url, categories(name)")
      .eq("slug", params.slug)
      .maybeSingle();
    const { data: offers } = product
      ? await supabase
          .from("shop_products")
          .select("price, stock_status, shops(name)")
          .eq("product_id", (product as any).id ?? "")
          .order("price", { ascending: true })
          .limit(20)
      : { data: null };
    return { product, offers: offers ?? [] };
  },
  head: ({ params, loaderData }) => {
    const p: any = loaderData?.product;
    const name = p?.name ?? params.slug;
    const cat = p?.categories?.name ?? "wholesale";
    const title = `${name} — Wholesale & Liquidation Suppliers in India | Kolkatabarabazar.in`;
    const desc = p?.description
      ? String(p.description).slice(0, 160)
      : `Buy ${name} wholesale from verified Indian ${cat} suppliers. Compare MOQ, factory surplus & liquidation stock prices on Kolkatabarabazar.in.`;
    const url = `https://kolkatabarabazar.in/product/${params.slug}`;
    const offers: any[] = (loaderData?.offers as any[]) ?? [];
    const prices = offers.map((o) => Number(o.price)).filter((n) => Number.isFinite(n) && n > 0);
    const lowPrice = prices.length ? Math.min(...prices) : undefined;
    const highPrice = prices.length ? Math.max(...prices) : undefined;
    return {
      meta: [
        { title },
        { name: "description", content: desc },
        { property: "og:title", content: title },
        { property: "og:description", content: desc },
        { property: "og:url", content: url },
        { property: "og:type", content: "product" },
        ...(p?.image_url ? [{ property: "og:image", content: p.image_url as string }, { name: "twitter:image", content: p.image_url as string }] : []),
      ],
      links: [{ rel: "canonical", href: url }],
      scripts: p
        ? [
            {
              type: "application/ld+json",
              children: JSON.stringify({
                "@context": "https://schema.org",
                "@type": "Product",
                name,
                description: desc,
                image: p.image_url ?? undefined,
                category: cat,
                brand: { "@type": "Brand", name: cat },
                offers: prices.length
                  ? {
                      "@type": "AggregateOffer",
                      priceCurrency: "INR",
                      lowPrice,
                      highPrice,
                      offerCount: offers.length,
                      availability: "https://schema.org/InStock",
                    }
                  : undefined,
              }),
            },
          ]
        : undefined,
    };
  },
  component: ProductPage,
  errorComponent: ({ error }) => <div className="p-8">Error: {error.message}</div>,
  notFoundComponent: () => <div className="p-8">Product not found.</div>,
});

function SpecRow({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div>
      <dt className="text-xs uppercase tracking-wider text-muted-foreground">{label}</dt>
      <dd className="mt-0.5 font-medium text-foreground">{value}</dd>
    </div>
  );
}

function ProductPage() {
  const { slug } = Route.useParams();

  const { data: product } = useQuery({
    queryKey: ["product", slug],
    queryFn: async () => (await supabase.from("products").select("*, categories(id, name, slug)").eq("slug", slug).maybeSingle()).data,
  });

  useEffect(() => {
    if (product) pushRecent({
      slug: product.slug,
      name: product.name,
      image_url: (product as any).image_url ?? null,
      category: (product as any).categories?.name ?? null,
    });
  }, [product]);

  const { data: offers } = useQuery({
    enabled: !!product?.id,
    queryKey: ["product-offers", product?.id],
    queryFn: async () => {
      const { data } = await supabase.from("shop_products")
        .select("id, price, stock, moq, stock_status, updated_at, condition, brand, lot_size, dispatch_time, mrp, shops(id, name, slug, address, area, phone, whatsapp, lat, lng, verified, approved, gst_verified, mobile_verified, warehouse_verified, top_seller, fast_responder, response_rate, avg_response_minutes, years_in_business, photos, description, logo_url, created_at, last_active_at, total_views, category_id)")
        .eq("product_id", product!.id).order("price", { ascending: true });
      return (data ?? []).filter((o: any) => o.shops?.approved);
    },
  });

  const categoryId = (product as any)?.categories?.id ?? (product as any)?.category_id;

  const { data: similar } = useQuery({
    enabled: !!categoryId && !!product?.id,
    queryKey: ["similar-products", categoryId, product?.id],
    queryFn: async () => {
      const { data } = await supabase
        .from("products")
        .select("id, slug, name, image_url, shop_products(price)")
        .eq("category_id", categoryId)
        .neq("id", product!.id)
        .limit(8);
      return data ?? [];
    },
  });

  const { data: relatedShops } = useQuery({
    enabled: !!categoryId,
    queryKey: ["related-shops", categoryId],
    queryFn: async () => {
      const { data } = await supabase
        .from("shops")
        .select("id, name, slug, area, address, logo_url, photos, verified, gst_verified, mobile_verified, warehouse_verified, top_seller, fast_responder, response_rate, avg_response_minutes, years_in_business, total_views, last_active_at, created_at")
        .eq("category_id", categoryId)
        .eq("approved", true)
        .limit(6);
      return data ?? [];
    },
  });

  if (!product) return <div className="min-h-screen"><SiteHeader /><div className="p-8 text-muted-foreground">Loading…</div></div>;

  const best = offers?.[0];
  const prices = (offers ?? []).map((o: any) => Number(o.price));
  const min = prices.length ? Math.min(...prices) : 0;
  const max = prices.length ? Math.max(...prices) : 0;
  const discountPct = max > min ? Math.round(((max - min) / max) * 100) : null;

  // Build gallery: product image + supplier photos (deduped), fallback to category
  const galleryImages: string[] = Array.from(new Set([
    product.image_url,
    ...((best?.shops as any)?.photos ?? []),
    ...((offers ?? []).flatMap((o: any) => (o.shops?.photos ?? []) as string[])),
  ].filter(Boolean) as string[]));
  if (galleryImages.length === 0) galleryImages.push(catApparel);

  const totalStock = (offers ?? []).reduce((sum: number, o: any) => sum + (o.stock || 0), 0);
  const minMoq = (offers ?? []).reduce((m: number, o: any) => Math.min(m, o.moq || Infinity), Infinity);

  return (
    <div className="min-h-screen">
      <SiteHeader />
      <main className="container mx-auto px-4 py-6 max-w-6xl">
        {/* Breadcrumb */}
        <nav className="text-sm text-muted-foreground mb-4 flex items-center gap-1.5 flex-wrap">
          <Link to="/" className="hover:text-primary inline-flex items-center gap-1"><ArrowLeft className="h-4 w-4" />Home</Link>
          {(product as any).categories?.slug && (
            <>
              <span>/</span>
              <Link to="/search" search={{ q: (product as any).categories.name } as any} className="hover:text-primary">{(product as any).categories.name}</Link>
            </>
          )}
          <span>/</span>
          <span className="text-foreground truncate">{product.name}</span>
        </nav>

        <div className="grid lg:grid-cols-[1.1fr_1fr] gap-6 mb-8">
          {/* GALLERY */}
          <div className="relative">
            <ProductGallery images={galleryImages} alt={product.name} />
            {discountPct && discountPct > 0 && (
              <div className="absolute top-4 left-24 z-10 rounded-2xl bg-discount text-white px-4 py-2 shadow-float rotate-[-3deg] pointer-events-none">
                <div className="text-[10px] uppercase tracking-wider opacity-90">Up to</div>
                <div className="font-display text-2xl leading-none">{discountPct}% OFF</div>
              </div>
            )}
            {/* Trust micro-strip */}
            <div className="mt-4 grid grid-cols-3 gap-2 text-xs">
              <div className="rounded-xl bg-card border border-border p-3 flex items-center gap-2"><Shield className="h-4 w-4 text-primary" /><span><div className="font-semibold text-foreground">Verified</div><div className="text-muted-foreground">Suppliers</div></span></div>
              <div className="rounded-xl bg-card border border-border p-3 flex items-center gap-2"><Truck className="h-4 w-4 text-primary" /><span><div className="font-semibold text-foreground">Fast</div><div className="text-muted-foreground">Dispatch</div></span></div>
              <div className="rounded-xl bg-card border border-border p-3 flex items-center gap-2"><BadgeCheck className="h-4 w-4 text-primary" /><span><div className="font-semibold text-foreground">Trade</div><div className="text-muted-foreground">Assured</div></span></div>
            </div>
          </div>

          {/* DETAILS */}
          <div className="flex flex-col">
            {(product as any).categories?.name && (
              <Badge variant="outline" className="self-start mb-3">{(product as any).categories.name}</Badge>
            )}
            <h1 className="font-display text-3xl sm:text-4xl lg:text-5xl text-foreground leading-tight">{product.name}</h1>
            {product.description && <p className="mt-3 text-muted-foreground">{product.description}</p>}

            <div className="mt-5 rounded-2xl glass p-5 border border-border">
              <div className="text-xs uppercase tracking-wider text-muted-foreground">Wholesale price range</div>
              <div className="mt-1 font-display text-3xl text-primary">
                ₹{min.toFixed(0)} <span className="text-muted-foreground text-xl">– ₹{max.toFixed(0)}</span>
                <span className="text-sm text-muted-foreground font-sans"> / unit</span>
              </div>
              <div className="text-xs text-muted-foreground mt-1">Across {offers?.length ?? 0} verified supplier{(offers?.length ?? 0) === 1 ? "" : "s"}</div>

              <div className="mt-4 grid grid-cols-3 gap-2 text-center">
                <div className="rounded-lg bg-background/60 p-2 border border-border">
                  <div className="text-[10px] uppercase tracking-wider text-muted-foreground">MOQ from</div>
                  <div className="font-display text-lg text-foreground">{Number.isFinite(minMoq) ? minMoq : 1}</div>
                </div>
                <div className="rounded-lg bg-background/60 p-2 border border-border">
                  <div className="text-[10px] uppercase tracking-wider text-muted-foreground">In stock</div>
                  <div className="font-display text-lg text-foreground">{totalStock.toLocaleString()}</div>
                </div>
                <div className="rounded-lg bg-background/60 p-2 border border-border">
                  <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Suppliers</div>
                  <div className="font-display text-lg text-foreground">{offers?.length ?? 0}</div>
                </div>
              </div>
            </div>

            {min > 0 && (
              <div className="mt-3">
                <AIPriceIntelligence
                  productName={product.name}
                  category={(product as any).categories?.name}
                  bestPrice={min}
                  offerCount={offers?.length ?? 0}
                />
              </div>
            )}

            {best && (
              <div className="mt-4 flex flex-wrap gap-2">
                {best.shops.whatsapp && (
                  <Button asChild size="lg" className="bg-whatsapp hover:bg-whatsapp/90 text-white">
                    <a href={whatsappUrl(best.shops.whatsapp, `Hi ${best.shops.name}, I'd like to enquire about ${product.name}.`)} target="_blank" rel="noopener noreferrer">
                      <MessageCircle className="h-4 w-4 mr-1" />WhatsApp Seller
                    </a>
                  </Button>
                )}
                <EnquiryDialog shopId={best.shops.id} productId={product.id} productName={product.name}
                  trigger={<Button size="lg" className="bg-primary hover:bg-primary/90"><FileText className="h-4 w-4 mr-1" />Request Quotation</Button>} />
                {best.shops.phone && (
                  <Button asChild size="lg" variant="outline">
                    <a href={telUrl(best.shops.phone)}><Phone className="h-4 w-4 mr-1" />Call</a>
                  </Button>
                )}
                <EnquiryDialog shopId={best.shops.id} productId={product.id} productName={product.name}
                  trigger={<Button size="lg" variant="outline"><Package className="h-4 w-4 mr-1" />Bulk enquiry</Button>} />
              </div>
            )}

            {best && (
              <div className="mt-4">
                <InventoryFreshness updatedAt={best.updated_at} shop={best.shops as any} />
              </div>
            )}

            <div className="mt-4 flex flex-wrap gap-2">
              <ProductFavoriteButton productId={product.id} shopId={best?.shops?.id ?? null} />
              <StockAlertButton productId={product.id} productName={product.name} shopId={best?.shops?.id ?? null} />
              <PriceAlertButton productId={product.id} productName={product.name} shopId={best?.shops?.id ?? null} currentPrice={best ? Number(best.price) : null} />
              <ReportButton targetType="product" targetId={product.id} />
            </div>
          </div>
        </div>

        {best && (
          <div className="grid lg:grid-cols-2 gap-4 mb-8">
            <section className="rounded-2xl border border-border bg-card p-5 shadow-float">
              <h2 className="font-display text-xl mb-4">Product Details</h2>
              <dl className="grid grid-cols-2 gap-x-4 gap-y-3 text-sm">
                <SpecRow label="Available Quantity" value={best.stock ? `${best.stock} units` : stockLabel(best.stock_status).text} />
                <SpecRow label="MOQ" value={`${best.moq} ${best.moq === 1 ? "unit" : "units"}`} />
                <SpecRow label="Condition" value={(best as any).condition ?? "New"} />
                <SpecRow label="Brand" value={(best as any).brand ?? "Assorted"} />
                <SpecRow label="Lot Size" value={(best as any).lot_size ? `${(best as any).lot_size} pcs` : "Mixed lot"} />
                <SpecRow label="Location" value={best.shops.area ?? best.shops.address} />
                <SpecRow label="Dispatch Time" value={(best as any).dispatch_time ?? "2-4 days"} />
              </dl>
            </section>
            <section className="rounded-2xl border border-border bg-card p-5 shadow-float">
              <h2 className="font-display text-xl mb-4">Supplier Details</h2>
              <div className="flex items-start gap-3 mb-4">
                {best.shops.logo_url ? (
                  <img src={best.shops.logo_url} alt={best.shops.name} className="h-14 w-14 rounded-xl object-cover ring-1 ring-border" />
                ) : (
                  <div className="h-14 w-14 rounded-xl bg-primary/10 flex items-center justify-center"><Store className="h-6 w-6 text-primary" /></div>
                )}
                <div className="min-w-0 flex-1">
                  <Link to="/shop/$slug" params={{ slug: best.shops.slug }} className="font-display text-lg text-foreground hover:text-primary block truncate">{best.shops.name}</Link>
                  <div className="text-xs text-muted-foreground flex items-center gap-1"><MapPin className="h-3 w-3" />{best.shops.area ?? best.shops.address}</div>
                </div>
                <TrustScoreBadge shop={best.shops as any} size="sm" />
              </div>
              <dl className="grid grid-cols-2 gap-x-4 gap-y-3 text-sm">
                <SpecRow label="Trust Score" value={`${trustScore(best.shops as any)} / 100`} />
                <SpecRow label="Response Rate" value={`${best.shops.response_rate ?? 0}%`} />
                <SpecRow label="Years Active" value={best.shops.years_in_business != null ? `${best.shops.years_in_business} yr${best.shops.years_in_business === 1 ? "" : "s"}` : "—"} />
                <SpecRow label="Profile Views" value={(best.shops.total_views ?? 0).toLocaleString()} />
              </dl>
              <div className="mt-4"><TrustBadges shop={best.shops as any} max={4} /></div>
              <Button asChild variant="outline" className="mt-4 w-full">
                <Link to="/shop/$slug" params={{ slug: best.shops.slug }}>Visit store <ExternalLink className="h-3.5 w-3.5 ml-1" /></Link>
              </Button>
            </section>
          </div>
        )}

        {best && (
          <div className="mb-8">
            <BuyerConfidenceBox shop={best.shops as any} lastListingUpdate={best.updated_at} />
          </div>
        )}


        <h2 className="font-display text-2xl mb-3">Compare {offers?.length ?? 0} supplier{(offers?.length ?? 0) === 1 ? "" : "s"}</h2>

        {(!offers || offers.length === 0) ? (
          <div className="rounded-2xl border-2 border-dashed border-border p-12 text-center text-muted-foreground">
            Not currently stocked by any supplier.
          </div>
        ) : (
          <ul className="space-y-3">
            {offers.map((o: any) => {
              const isBest = o.id === best!.id;
              const stock = stockLabel(o.stock_status);
              const msg = `Hi ${o.shops.name}, I'd like to enquire about ${product.name}. Please share availability and best price.`;
              return (
                <li key={o.id} className="rounded-2xl border border-border bg-card p-4 hover:ring-1 hover:ring-primary/30 transition shadow-float">
                  <div className="flex items-start justify-between gap-4">
                    <Link to="/shop/$slug" params={{ slug: o.shops.slug }} className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-semibold text-foreground">{o.shops.name}</span>
                        <TrustScoreBadge shop={o.shops} size="sm" />
                        {isBest && <Badge className="bg-discount text-white hover:bg-discount"><Flame className="h-3 w-3 mr-1" />Best price</Badge>}
                        <span className={`px-1.5 py-0.5 rounded border text-[10px] ${stock.cls}`}>{stock.text}</span>
                      </div>
                      <div className="mt-1.5"><TrustBadges shop={o.shops} max={3} compact /></div>
                      <div className="text-xs text-muted-foreground mt-1.5 flex flex-wrap gap-3">
                        <span className="flex items-center gap-1"><MapPin className="h-3 w-3" />{o.shops.area ?? o.shops.address}</span>
                        <span>MOQ {o.moq}</span>
                        <span>{freshnessLabel(o.updated_at)}</span>
                      </div>
                    </Link>
                    <div className="font-display text-2xl text-primary shrink-0">₹{Number(o.price).toFixed(0)}</div>
                  </div>
                  <div className="mt-2"><InventoryFreshness updatedAt={o.updated_at} shop={o.shops} compact /></div>
                  <div className="mt-3 flex flex-wrap gap-2">
                    {o.shops.whatsapp && <Button size="sm" asChild className="bg-whatsapp hover:bg-whatsapp/90 text-white"><a href={whatsappUrl(o.shops.whatsapp, msg)} target="_blank" rel="noopener noreferrer"><MessageCircle className="h-3.5 w-3.5 mr-1" />WhatsApp</a></Button>}
                    {o.shops.phone && <Button size="sm" variant="outline" asChild><a href={telUrl(o.shops.phone)}><Phone className="h-3.5 w-3.5 mr-1" />Call</a></Button>}
                    {o.shops.lat != null && o.shops.lng != null && <Button size="sm" variant="ghost" asChild><a href={directionsUrl(o.shops.lat, o.shops.lng)} target="_blank" rel="noopener noreferrer"><ExternalLink className="h-3.5 w-3.5 mr-1" />Map</a></Button>}
                    <EnquiryDialog shopId={o.shops.id} productId={product.id} productName={product.name}
                      trigger={<Button size="sm" variant="outline">Enquire</Button>} />
                  </div>
                </li>
              );
            })}
          </ul>
        )}

        {/* Similar Products */}
        {similar && similar.length > 0 && (
          <section className="mt-12">
            <div className="flex items-end justify-between mb-4">
              <h2 className="font-display text-2xl">Similar products</h2>
              {(product as any).categories?.name && (
                <Link to="/search" search={{ q: (product as any).categories.name } as any} className="text-sm text-primary hover:underline">View all →</Link>
              )}
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
              {similar.map((p: any) => {
                const minP = (p.shop_products ?? []).reduce((m: number, sp: any) => Math.min(m, Number(sp.price)), Infinity);
                return (
                  <Link key={p.id} to="/product/$slug" params={{ slug: p.slug }}
                    className="group rounded-2xl border border-border bg-card overflow-hidden shadow-float hover:-translate-y-1 hover:shadow-lg transition-all">
                    <div className="aspect-square bg-muted overflow-hidden">
                      <img src={p.image_url || catApparel} alt={p.name} className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-300" />
                    </div>
                    <div className="p-3">
                      <div className="font-medium text-sm line-clamp-2 min-h-[2.5rem]">{p.name}</div>
                      {Number.isFinite(minP) && (
                        <div className="mt-1 text-primary font-display text-lg">₹{minP.toFixed(0)}</div>
                      )}
                    </div>
                  </Link>
                );
              })}
            </div>
          </section>
        )}

        {/* Related Suppliers */}
        {relatedShops && relatedShops.length > 0 && (
          <section className="mt-12 mb-8">
            <div className="flex items-end justify-between mb-4">
              <h2 className="font-display text-2xl">Related suppliers</h2>
              <Link to="/search" className="text-sm text-primary hover:underline">Browse all →</Link>
            </div>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {relatedShops.map((s: any) => (
                <Link key={s.id} to="/shop/$slug" params={{ slug: s.slug }}
                  className="rounded-2xl border border-border bg-card p-4 shadow-float hover:ring-1 hover:ring-primary/40 hover:-translate-y-0.5 transition-all">
                  <div className="flex items-start gap-3">
                    {s.logo_url ? (
                      <img src={s.logo_url} alt={s.name} className="h-12 w-12 rounded-xl object-cover ring-1 ring-border shrink-0" />
                    ) : (
                      <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center shrink-0"><Store className="h-5 w-5 text-primary" /></div>
                    )}
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <div className="font-semibold truncate">{s.name}</div>
                        <TrustScoreBadge shop={s} size="sm" />
                      </div>
                      <div className="text-xs text-muted-foreground flex items-center gap-1 mt-0.5"><MapPin className="h-3 w-3" />{s.area ?? s.address}</div>
                      <div className="mt-2"><TrustBadges shop={s} max={3} compact /></div>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </section>
        )}
      </main>
    </div>
  );
}
