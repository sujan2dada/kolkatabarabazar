import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Bookmark, Trash2, Search as SearchIcon, MessageCircle, Mail, Bell } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { SiteHeader } from "@/components/SiteHeader";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/lib/auth";
import { useEffect } from "react";

export const Route = createFileRoute("/saved-searches")({
  head: () => ({ meta: [{ title: "Saved searches — Kolkatabarabazar.in" }] }),
  component: SavedSearchesPage,
});

const CH_ICONS: Record<string, any> = { whatsapp: MessageCircle, email: Mail, push: Bell };

function SavedSearchesPage() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const qc = useQueryClient();

  useEffect(() => { if (!loading && !user) navigate({ to: "/login" }); }, [loading, user, navigate]);

  const { data } = useQuery({
    queryKey: ["saved-searches", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data } = await supabase.from("saved_searches")
        .select("*").eq("user_id", user!.id).order("created_at", { ascending: false });
      return data ?? [];
    },
  });

  const remove = async (id: string) => {
    const { error } = await supabase.from("saved_searches").delete().eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Removed");
    qc.invalidateQueries({ queryKey: ["saved-searches", user?.id] });
  };

  const list = data ?? [];

  return (
    <div className="min-h-screen">
      <SiteHeader />
      <main className="container mx-auto px-4 py-8 max-w-4xl">
        <div className="flex items-center gap-3 mb-6">
          <Bookmark className="h-7 w-7 text-primary" />
          <h1 className="font-display text-3xl text-foreground">Saved searches</h1>
        </div>

        {list.length === 0 ? (
          <div className="rounded-2xl border-2 border-dashed border-border p-12 text-center">
            <p className="text-muted-foreground mb-4">No saved searches yet.</p>
            <Button asChild><Link to="/search" search={{ q: "" }}>Browse stock</Link></Button>
          </div>
        ) : (
          <ul className="space-y-3">
            {list.map((s: any) => {
              const f = s.filters ?? {};
              const chips = [
                s.category_slug && `Category: ${s.category_slug}`,
                f.area && `Area: ${f.area}`,
                f.maxMoq != null && `MOQ ≤ ${f.maxMoq}`,
                f.maxPrice != null && `Under ₹${f.maxPrice}`,
                f.minPrice != null && `From ₹${f.minPrice}`,
                f.verifiedOnly && "Verified only",
                f.inStockOnly && "In stock",
              ].filter(Boolean) as string[];
              return (
                <li key={s.id} className="rounded-2xl border border-border bg-card p-4 shadow-float">
                  <div className="flex items-start justify-between gap-3 flex-wrap">
                    <div className="min-w-0">
                      <div className="font-semibold text-foreground">{s.name}</div>
                      {s.query && <div className="text-xs text-muted-foreground mt-0.5">"{s.query}"</div>}
                      <div className="mt-2 flex flex-wrap gap-1.5">
                        {chips.map((c) => (
                          <span key={c} className="text-[11px] rounded-full bg-secondary px-2 py-0.5 text-muted-foreground">{c}</span>
                        ))}
                      </div>
                      <div className="mt-2 flex items-center gap-2 text-xs text-muted-foreground">
                        Alerts:
                        {(s.alert_channels?.length ? s.alert_channels : ["—"]).map((c: string) => {
                          const Icon = CH_ICONS[c];
                          return (
                            <span key={c} className="inline-flex items-center gap-1 capitalize">
                              {Icon && <Icon className="h-3 w-3 text-primary" />}{c}
                            </span>
                          );
                        })}
                      </div>
                    </div>
                    <div className="flex gap-2 shrink-0">
                      <Button asChild size="sm" variant="outline" className="rounded-full gap-1">
                        <Link to="/search" search={{ q: s.query ?? "", category: s.category_slug ?? undefined }}>
                          <SearchIcon className="h-3.5 w-3.5" /> Run
                        </Link>
                      </Button>
                      <Button size="sm" variant="ghost" onClick={() => remove(s.id)} className="text-destructive">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </main>
    </div>
  );
}
