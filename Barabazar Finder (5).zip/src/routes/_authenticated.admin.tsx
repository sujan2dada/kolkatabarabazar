import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { SiteHeader } from "@/components/SiteHeader";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";
import { toast } from "sonner";
import {
  Users, Store, Package, CreditCard, Megaphone, ShieldCheck,
  AlertOctagon, BarChart3, Inbox, ShieldAlert,
} from "lucide-react";

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({ meta: [{ title: "Super Admin · Kolkatabarabazar.in" }] }),
  component: AdminPage,
});

function AdminPage() {
  const { isAdmin, loading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!loading && !isAdmin) navigate({ to: "/dashboard" });
  }, [loading, isAdmin, navigate]);

  if (loading) return <Shell><div className="p-8 text-muted-foreground">Loading…</div></Shell>;
  if (!isAdmin) return <Shell><div className="p-8 text-muted-foreground">Admin only.</div></Shell>;

  return (
    <Shell>
      <main className="container mx-auto px-4 py-8 max-w-7xl">
        <div className="flex items-center gap-3 mb-6">
          <div className="h-12 w-12 rounded-2xl bg-primary/10 grid place-items-center">
            <ShieldCheck className="h-6 w-6 text-primary" />
          </div>
          <div>
            <h1 className="font-display text-3xl md:text-4xl text-foreground leading-tight">Super Admin</h1>
            <p className="text-sm text-muted-foreground">Approve, moderate, and grow the marketplace.</p>
          </div>
        </div>

        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="flex flex-wrap h-auto gap-1 bg-secondary/50">
            <TabsTrigger value="overview"><BarChart3 className="h-4 w-4 mr-1.5" />Overview</TabsTrigger>
            <TabsTrigger value="suppliers"><Store className="h-4 w-4 mr-1.5" />Suppliers</TabsTrigger>
            <TabsTrigger value="products"><Package className="h-4 w-4 mr-1.5" />Products</TabsTrigger>
            <TabsTrigger value="users"><Users className="h-4 w-4 mr-1.5" />Users & Roles</TabsTrigger>
            <TabsTrigger value="subs"><CreditCard className="h-4 w-4 mr-1.5" />Subscriptions</TabsTrigger>
            <TabsTrigger value="ads"><Megaphone className="h-4 w-4 mr-1.5" />Ads</TabsTrigger>
            <TabsTrigger value="complaints"><AlertOctagon className="h-4 w-4 mr-1.5" />Complaints</TabsTrigger>
            <TabsTrigger value="leads"><Inbox className="h-4 w-4 mr-1.5" />Buyer Leads</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="mt-6"><Overview /></TabsContent>
          <TabsContent value="suppliers" className="mt-6"><SuppliersPanel /></TabsContent>
          <TabsContent value="products" className="mt-6"><ProductsPanel /></TabsContent>
          <TabsContent value="users" className="mt-6"><UsersPanel /></TabsContent>
          <TabsContent value="subs" className="mt-6"><SubscriptionsPanel /></TabsContent>
          <TabsContent value="ads" className="mt-6"><AdsPanel /></TabsContent>
          <TabsContent value="complaints" className="mt-6"><ComplaintsPanel /></TabsContent>
          <TabsContent value="leads" className="mt-6"><LeadsPanel /></TabsContent>
        </Tabs>
      </main>
    </Shell>
  );
}

function Shell({ children }: { children: React.ReactNode }) {
  return <div className="min-h-screen"><SiteHeader />{children}</div>;
}

function Card({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return <div className={`rounded-xl border-2 border-border bg-card overflow-hidden ${className}`}>{children}</div>;
}

function StatCard({ icon: Icon, label, value, hint }: { icon: any; label: string; value: number | string; hint?: string }) {
  return (
    <div className="rounded-xl border-2 border-border bg-card p-5">
      <div className="flex items-center justify-between mb-2">
        <div className="text-sm text-muted-foreground">{label}</div>
        <Icon className="h-4 w-4 text-muted-foreground" />
      </div>
      <div className="font-display text-3xl text-foreground">{value}</div>
      {hint && <div className="text-xs text-muted-foreground mt-1">{hint}</div>}
    </div>
  );
}

/* ─────────────── Overview ─────────────── */
function Overview() {
  const { data } = useQuery({
    queryKey: ["admin-overview"],
    queryFn: async () => {
      const counts = await Promise.all([
        supabase.from("shops").select("id, approved, verified", { count: "exact", head: false }),
        supabase.from("products").select("id, approved", { count: "exact", head: false }),
        supabase.from("profiles").select("id", { count: "exact", head: true }),
        supabase.from("enquiries").select("id", { count: "exact", head: true }),
        supabase.from("buyer_requirements").select("id", { count: "exact", head: true }),
        supabase.from("reports").select("id", { count: "exact", head: true }),
        supabase.from("feedback").select("id", { count: "exact", head: true }),
        supabase.from("subscriptions").select("id, status, plan"),
        supabase.from("advertisements").select("id, active"),
      ]);
      const shops = counts[0].data ?? [];
      const products = counts[1].data ?? [];
      const subs = counts[7].data ?? [];
      const ads = counts[8].data ?? [];
      return {
        shopsTotal: shops.length,
        shopsPending: shops.filter((s: any) => !s.approved).length,
        shopsVerified: shops.filter((s: any) => s.verified).length,
        productsTotal: products.length,
        productsPending: products.filter((p: any) => !p.approved).length,
        users: counts[2].count ?? 0,
        enquiries: counts[3].count ?? 0,
        leads: counts[4].count ?? 0,
        reports: counts[5].count ?? 0,
        feedback: counts[6].count ?? 0,
        activeSubs: subs.filter((s: any) => s.status === "active").length,
        activeAds: ads.filter((a: any) => a.active).length,
      };
    },
  });

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
      <StatCard icon={Store} label="Suppliers" value={data?.shopsTotal ?? "—"} hint={`${data?.shopsPending ?? 0} pending approval`} />
      <StatCard icon={ShieldCheck} label="Verified shops" value={data?.shopsVerified ?? "—"} />
      <StatCard icon={Package} label="Products" value={data?.productsTotal ?? "—"} hint={`${data?.productsPending ?? 0} pending`} />
      <StatCard icon={Users} label="Users" value={data?.users ?? "—"} />
      <StatCard icon={Inbox} label="Buyer leads" value={data?.leads ?? "—"} />
      <StatCard icon={Inbox} label="Enquiries" value={data?.enquiries ?? "—"} />
      <StatCard icon={CreditCard} label="Active subscriptions" value={data?.activeSubs ?? "—"} />
      <StatCard icon={Megaphone} label="Live ads" value={data?.activeAds ?? "—"} />
      <StatCard icon={AlertOctagon} label="Open reports" value={data?.reports ?? "—"} />
      <StatCard icon={ShieldAlert} label="Feedback msgs" value={data?.feedback ?? "—"} />
    </div>
  );
}

/* ─────────────── Suppliers ─────────────── */
function SuppliersPanel() {
  const qc = useQueryClient();
  const [filter, setFilter] = useState<"all" | "pending" | "approved">("all");
  const [q, setQ] = useState("");

  const { data: shops } = useQuery({
    queryKey: ["admin-shops-full"],
    queryFn: async () =>
      (await supabase.from("shops").select("*, categories(name)").order("created_at", { ascending: false })).data ?? [],
  });

  const filtered = (shops ?? []).filter((s: any) => {
    if (filter === "pending" && s.approved) return false;
    if (filter === "approved" && !s.approved) return false;
    if (q && !`${s.name} ${s.address ?? ""} ${s.area ?? ""}`.toLowerCase().includes(q.toLowerCase())) return false;
    return true;
  });

  const update = async (id: string, patch: Record<string, any>) => {
    const { error } = await (supabase.from("shops") as any).update(patch).eq("id", id);
    if (error) toast.error(error.message);
    else { toast.success("Updated"); qc.invalidateQueries({ queryKey: ["admin-shops-full"] }); qc.invalidateQueries({ queryKey: ["admin-overview"] }); }
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-2 items-center">
        <Input placeholder="Search shops…" value={q} onChange={(e) => setQ(e.target.value)} className="max-w-xs" />
        <Select value={filter} onValueChange={(v: any) => setFilter(v)}>
          <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All</SelectItem>
            <SelectItem value="pending">Pending</SelectItem>
            <SelectItem value="approved">Approved</SelectItem>
          </SelectContent>
        </Select>
        <div className="text-sm text-muted-foreground ml-auto">{filtered.length} shops</div>
      </div>

      <Card>
        <div className="overflow-x-auto">
          <table className="w-full text-sm min-w-[820px]">
            <thead className="bg-secondary/50 text-left">
              <tr>
                <th className="p-3">Shop</th>
                <th className="p-3">Approved</th>
                <th className="p-3">Verified</th>
                <th className="p-3">GST</th>
                <th className="p-3">Mobile</th>
                <th className="p-3">Warehouse</th>
                <th className="p-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {filtered.map((s: any) => (
                <tr key={s.id}>
                  <td className="p-3">
                    <Link to="/shop/$slug" params={{ slug: s.slug }} className="font-medium hover:text-primary">{s.name}</Link>
                    <div className="text-xs text-muted-foreground">{s.area ?? s.address}</div>
                  </td>
                  <td className="p-3">
                    {s.approved
                      ? <Badge className="bg-accent text-accent-foreground hover:bg-accent">Yes</Badge>
                      : <Badge variant="outline" className="text-destructive border-destructive">Pending</Badge>}
                  </td>
                  <td className="p-3"><Switch checked={s.verified} onCheckedChange={(v) => update(s.id, { verified: v })} /></td>
                  <td className="p-3"><Switch checked={s.gst_verified} onCheckedChange={(v) => update(s.id, { gst_verified: v })} /></td>
                  <td className="p-3"><Switch checked={s.mobile_verified} onCheckedChange={(v) => update(s.id, { mobile_verified: v })} /></td>
                  <td className="p-3"><Switch checked={s.warehouse_verified} onCheckedChange={(v) => update(s.id, { warehouse_verified: v })} /></td>
                  <td className="p-3 text-right space-x-2 whitespace-nowrap">
                    <Button size="sm" variant="outline" onClick={() => update(s.id, { approved: !s.approved })}>
                      {s.approved ? "Unapprove" : "Approve"}
                    </Button>
                  </td>
                </tr>
              ))}
              {!filtered.length && <tr><td colSpan={7} className="p-6 text-center text-muted-foreground">No shops match.</td></tr>}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}

/* ─────────────── Products ─────────────── */
function ProductsPanel() {
  const qc = useQueryClient();
  const [q, setQ] = useState("");
  const { data: products } = useQuery({
    queryKey: ["admin-products"],
    queryFn: async () =>
      (await supabase.from("products").select("id, name, slug, approved, image_url, created_at, categories(name)").order("created_at", { ascending: false }).limit(500)).data ?? [],
  });

  const filtered = (products ?? []).filter((p: any) => !q || p.name.toLowerCase().includes(q.toLowerCase()));

  const toggleApprove = async (p: any) => {
    const { error } = await supabase.from("products").update({ approved: !p.approved } as any).eq("id", p.id);
    if (error) toast.error(error.message);
    else { toast.success("Updated"); qc.invalidateQueries({ queryKey: ["admin-products"] }); }
  };

  const remove = async (p: any) => {
    if (!confirm(`Delete product "${p.name}"?`)) return;
    const { error } = await supabase.from("products").delete().eq("id", p.id);
    if (error) toast.error(error.message);
    else { toast.success("Deleted"); qc.invalidateQueries({ queryKey: ["admin-products"] }); }
  };

  return (
    <div className="space-y-4">
      <Input placeholder="Search products…" value={q} onChange={(e) => setQ(e.target.value)} className="max-w-xs" />
      <Card>
        <div className="overflow-x-auto">
          <table className="w-full text-sm min-w-[640px]">
            <thead className="bg-secondary/50 text-left">
              <tr>
                <th className="p-3">Product</th>
                <th className="p-3">Category</th>
                <th className="p-3">Status</th>
                <th className="p-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {filtered.map((p: any) => (
                <tr key={p.id}>
                  <td className="p-3">
                    <div className="flex items-center gap-3">
                      {p.image_url && <img src={p.image_url} alt="" className="h-10 w-10 rounded-md object-cover" />}
                      <div>
                        <div className="font-medium">{p.name}</div>
                        <div className="text-xs text-muted-foreground">{p.slug}</div>
                      </div>
                    </div>
                  </td>
                  <td className="p-3">{p.categories?.name ?? "—"}</td>
                  <td className="p-3">
                    {p.approved
                      ? <Badge className="bg-accent text-accent-foreground hover:bg-accent">Approved</Badge>
                      : <Badge variant="outline" className="text-destructive border-destructive">Pending</Badge>}
                  </td>
                  <td className="p-3 text-right space-x-2 whitespace-nowrap">
                    <Button size="sm" variant="outline" onClick={() => toggleApprove(p)}>{p.approved ? "Unapprove" : "Approve"}</Button>
                    <Button size="sm" variant="ghost" className="text-destructive" onClick={() => remove(p)}>Delete</Button>
                  </td>
                </tr>
              ))}
              {!filtered.length && <tr><td colSpan={4} className="p-6 text-center text-muted-foreground">No products.</td></tr>}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}

/* ─────────────── Users & Roles ─────────────── */
const ROLES = ["admin", "moderator", "owner"] as const;

function UsersPanel() {
  const qc = useQueryClient();
  const [q, setQ] = useState("");

  const { data: profiles } = useQuery({
    queryKey: ["admin-profiles"],
    queryFn: async () => (await supabase.from("profiles").select("*").order("created_at", { ascending: false }).limit(500)).data ?? [],
  });
  const { data: roles } = useQuery({
    queryKey: ["admin-roles"],
    queryFn: async () => (await supabase.from("user_roles").select("*")).data ?? [],
  });

  const rolesByUser = new Map<string, string[]>();
  (roles ?? []).forEach((r: any) => {
    const arr = rolesByUser.get(r.user_id) ?? [];
    arr.push(r.role);
    rolesByUser.set(r.user_id, arr);
  });

  const filtered = (profiles ?? []).filter((p: any) => !q || `${p.full_name ?? ""} ${p.phone ?? ""}`.toLowerCase().includes(q.toLowerCase()));

  const grant = async (userId: string, role: string) => {
    const { error } = await supabase.from("user_roles").insert({ user_id: userId, role } as any);
    if (error) toast.error(error.message);
    else { toast.success(`Granted ${role}`); qc.invalidateQueries({ queryKey: ["admin-roles"] }); }
  };
  const revoke = async (userId: string, role: string) => {
    const { error } = await supabase.from("user_roles").delete().eq("user_id", userId).eq("role", role as any);
    if (error) toast.error(error.message);
    else { toast.success(`Revoked ${role}`); qc.invalidateQueries({ queryKey: ["admin-roles"] }); }
  };

  return (
    <div className="space-y-4">
      <Input placeholder="Search users…" value={q} onChange={(e) => setQ(e.target.value)} className="max-w-xs" />
      <Card>
        <div className="overflow-x-auto">
          <table className="w-full text-sm min-w-[720px]">
            <thead className="bg-secondary/50 text-left">
              <tr>
                <th className="p-3">User</th>
                <th className="p-3">Phone</th>
                <th className="p-3">Roles</th>
                <th className="p-3 text-right">Grant role</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {filtered.map((p: any) => {
                const userRoles = rolesByUser.get(p.id) ?? [];
                return (
                  <tr key={p.id}>
                    <td className="p-3">
                      <div className="font-medium">{p.full_name ?? "—"}</div>
                      <div className="text-xs text-muted-foreground font-mono">{p.id.slice(0, 8)}…</div>
                    </td>
                    <td className="p-3">{p.phone ?? "—"}</td>
                    <td className="p-3">
                      <div className="flex flex-wrap gap-1">
                        {userRoles.length ? userRoles.map((r) => (
                          <Badge key={r} variant="outline" className="cursor-pointer hover:bg-destructive/10" onClick={() => revoke(p.id, r)} title="Click to revoke">
                            {r} ✕
                          </Badge>
                        )) : <span className="text-xs text-muted-foreground">no roles</span>}
                      </div>
                    </td>
                    <td className="p-3 text-right">
                      <Select onValueChange={(v) => grant(p.id, v)}>
                        <SelectTrigger className="w-32 ml-auto"><SelectValue placeholder="+ role" /></SelectTrigger>
                        <SelectContent>
                          {ROLES.filter((r) => !userRoles.includes(r)).map((r) => <SelectItem key={r} value={r}>{r}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}

/* ─────────────── Subscriptions ─────────────── */
function SubscriptionsPanel() {
  const qc = useQueryClient();
  const { data: subs } = useQuery({
    queryKey: ["admin-subs"],
    queryFn: async () =>
      (await supabase.from("subscriptions").select("*, shops(name, slug)").order("created_at", { ascending: false })).data ?? [],
  });
  const { data: shops } = useQuery({
    queryKey: ["admin-shops-min"],
    queryFn: async () => (await supabase.from("shops").select("id, name, owner_id")).data ?? [],
  });

  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<any>({ shop_id: "", plan: "growth", status: "active", amount: 1999, billing_cycle: "monthly" });

  const create = async () => {
    const shop = (shops ?? []).find((s: any) => s.id === form.shop_id);
    if (!shop) { toast.error("Pick a shop"); return; }
    const { error } = await supabase.from("subscriptions").insert({
      shop_id: shop.id, owner_id: shop.owner_id,
      plan: form.plan, status: form.status, amount: Number(form.amount) || null,
      billing_cycle: form.billing_cycle,
    } as any);
    if (error) toast.error(error.message);
    else { toast.success("Subscription created"); setOpen(false); qc.invalidateQueries({ queryKey: ["admin-subs"] }); }
  };

  const updateStatus = async (id: string, status: string) => {
    const { error } = await supabase.from("subscriptions").update({ status } as any).eq("id", id);
    if (error) toast.error(error.message);
    else qc.invalidateQueries({ queryKey: ["admin-subs"] });
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="text-sm text-muted-foreground">{subs?.length ?? 0} subscriptions</div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild><Button>New subscription</Button></DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>Add subscription</DialogTitle></DialogHeader>
            <div className="space-y-3">
              <Select value={form.shop_id} onValueChange={(v) => setForm({ ...form, shop_id: v })}>
                <SelectTrigger><SelectValue placeholder="Select shop" /></SelectTrigger>
                <SelectContent>{(shops ?? []).map((s: any) => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}</SelectContent>
              </Select>
              <Select value={form.plan} onValueChange={(v) => setForm({ ...form, plan: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="free">Free</SelectItem>
                  <SelectItem value="growth">Growth</SelectItem>
                  <SelectItem value="enterprise">Enterprise</SelectItem>
                </SelectContent>
              </Select>
              <Input type="number" placeholder="Amount (INR)" value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} />
              <Select value={form.billing_cycle} onValueChange={(v) => setForm({ ...form, billing_cycle: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="monthly">Monthly</SelectItem>
                  <SelectItem value="yearly">Yearly</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <DialogFooter><Button onClick={create}>Create</Button></DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <div className="overflow-x-auto">
          <table className="w-full text-sm min-w-[720px]">
            <thead className="bg-secondary/50 text-left">
              <tr>
                <th className="p-3">Shop</th>
                <th className="p-3">Plan</th>
                <th className="p-3">Cycle</th>
                <th className="p-3">Amount</th>
                <th className="p-3">Status</th>
                <th className="p-3">Started</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {(subs ?? []).map((s: any) => (
                <tr key={s.id}>
                  <td className="p-3 font-medium">{s.shops?.name ?? "—"}</td>
                  <td className="p-3 capitalize">{s.plan}</td>
                  <td className="p-3 capitalize">{s.billing_cycle}</td>
                  <td className="p-3">{s.amount ? `₹${s.amount}` : "—"}</td>
                  <td className="p-3">
                    <Select value={s.status} onValueChange={(v) => updateStatus(s.id, v)}>
                      <SelectTrigger className="w-32"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="active">Active</SelectItem>
                        <SelectItem value="trialing">Trialing</SelectItem>
                        <SelectItem value="past_due">Past due</SelectItem>
                        <SelectItem value="canceled">Canceled</SelectItem>
                      </SelectContent>
                    </Select>
                  </td>
                  <td className="p-3 text-xs text-muted-foreground">{new Date(s.started_at).toLocaleDateString()}</td>
                </tr>
              ))}
              {!subs?.length && <tr><td colSpan={6} className="p-6 text-center text-muted-foreground">No subscriptions yet.</td></tr>}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}

/* ─────────────── Ads ─────────────── */
function AdsPanel() {
  const qc = useQueryClient();
  const { data: ads } = useQuery({
    queryKey: ["admin-ads"],
    queryFn: async () => (await supabase.from("advertisements").select("*").order("priority", { ascending: false })).data ?? [],
  });

  const [open, setOpen] = useState(false);
  const blank = { title: "", image_url: "", link_url: "", placement: "home_hero", priority: 0, advertiser_name: "", active: true };
  const [form, setForm] = useState<any>(blank);
  const [editId, setEditId] = useState<string | null>(null);

  const save = async () => {
    if (!form.title) return toast.error("Title required");
    if (editId) {
      const { error } = await supabase.from("advertisements").update(form as any).eq("id", editId);
      if (error) return toast.error(error.message);
    } else {
      const { error } = await supabase.from("advertisements").insert(form as any);
      if (error) return toast.error(error.message);
    }
    toast.success("Saved");
    setOpen(false); setEditId(null); setForm(blank);
    qc.invalidateQueries({ queryKey: ["admin-ads"] });
  };

  const remove = async (id: string) => {
    if (!confirm("Delete ad?")) return;
    const { error } = await supabase.from("advertisements").delete().eq("id", id);
    if (error) toast.error(error.message);
    else { toast.success("Deleted"); qc.invalidateQueries({ queryKey: ["admin-ads"] }); }
  };

  const toggle = async (a: any) => {
    const { error } = await supabase.from("advertisements").update({ active: !a.active } as any).eq("id", a.id);
    if (error) toast.error(error.message);
    else qc.invalidateQueries({ queryKey: ["admin-ads"] });
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="text-sm text-muted-foreground">{ads?.length ?? 0} ads</div>
        <Dialog open={open} onOpenChange={(v) => { setOpen(v); if (!v) { setEditId(null); setForm(blank); } }}>
          <DialogTrigger asChild><Button onClick={() => { setEditId(null); setForm(blank); }}>New ad</Button></DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>{editId ? "Edit ad" : "New ad"}</DialogTitle></DialogHeader>
            <div className="space-y-3">
              <Input placeholder="Title" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
              <Input placeholder="Image URL" value={form.image_url} onChange={(e) => setForm({ ...form, image_url: e.target.value })} />
              <Input placeholder="Link URL" value={form.link_url} onChange={(e) => setForm({ ...form, link_url: e.target.value })} />
              <Input placeholder="Advertiser" value={form.advertiser_name} onChange={(e) => setForm({ ...form, advertiser_name: e.target.value })} />
              <Select value={form.placement} onValueChange={(v) => setForm({ ...form, placement: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="home_hero">Home hero</SelectItem>
                  <SelectItem value="home_banner">Home banner</SelectItem>
                  <SelectItem value="search_top">Search top</SelectItem>
                  <SelectItem value="sidebar">Sidebar</SelectItem>
                </SelectContent>
              </Select>
              <Input type="number" placeholder="Priority" value={form.priority} onChange={(e) => setForm({ ...form, priority: Number(e.target.value) })} />
              <div className="flex items-center gap-2"><Switch checked={form.active} onCheckedChange={(v) => setForm({ ...form, active: v })} /><span className="text-sm">Active</span></div>
            </div>
            <DialogFooter><Button onClick={save}>Save</Button></DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {(ads ?? []).map((a: any) => (
          <div key={a.id} className="rounded-xl border-2 border-border bg-card overflow-hidden">
            {a.image_url ? <img src={a.image_url} alt={a.title} className="w-full h-32 object-cover" /> : <div className="h-32 bg-muted" />}
            <div className="p-3 space-y-2">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="font-semibold">{a.title}</div>
                  <div className="text-xs text-muted-foreground">{a.placement} · priority {a.priority}</div>
                </div>
                <Switch checked={a.active} onCheckedChange={() => toggle(a)} />
              </div>
              {a.advertiser_name && <div className="text-xs text-muted-foreground">By {a.advertiser_name}</div>}
              <div className="flex gap-2 pt-1">
                <Button size="sm" variant="outline" onClick={() => { setEditId(a.id); setForm(a); setOpen(true); }}>Edit</Button>
                <Button size="sm" variant="ghost" className="text-destructive" onClick={() => remove(a.id)}>Delete</Button>
              </div>
            </div>
          </div>
        ))}
        {!ads?.length && <div className="text-sm text-muted-foreground col-span-full text-center py-8">No ads yet. Create your first.</div>}
      </div>
    </div>
  );
}

/* ─────────────── Complaints ─────────────── */
function ComplaintsPanel() {
  const { data: reports } = useQuery({
    queryKey: ["admin-reports"],
    queryFn: async () => (await supabase.from("reports").select("*").order("created_at", { ascending: false }).limit(200)).data ?? [],
  });
  const { data: feedback } = useQuery({
    queryKey: ["admin-feedback"],
    queryFn: async () => (await supabase.from("feedback").select("*").order("created_at", { ascending: false }).limit(200)).data ?? [],
  });

  return (
    <div className="grid lg:grid-cols-2 gap-4">
      <Card>
        <div className="p-3 border-b border-border bg-secondary/50 font-semibold">Reports ({reports?.length ?? 0})</div>
        <div className="divide-y divide-border max-h-[600px] overflow-auto">
          {(reports ?? []).map((r: any) => (
            <div key={r.id} className="p-3">
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>{r.target_type} · {r.target_id.slice(0, 8)}…</span>
                <span>{new Date(r.created_at).toLocaleDateString()}</span>
              </div>
              <div className="text-sm mt-1">{r.reason}</div>
              {r.reporter_contact && <div className="text-xs text-muted-foreground mt-1">{r.reporter_contact}</div>}
            </div>
          ))}
          {!reports?.length && <div className="p-6 text-center text-sm text-muted-foreground">No reports.</div>}
        </div>
      </Card>

      <Card>
        <div className="p-3 border-b border-border bg-secondary/50 font-semibold">Feedback ({feedback?.length ?? 0})</div>
        <div className="divide-y divide-border max-h-[600px] overflow-auto">
          {(feedback ?? []).map((f: any) => (
            <div key={f.id} className="p-3">
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>{f.name} · {f.email}</span>
                <span>{new Date(f.created_at).toLocaleDateString()}</span>
              </div>
              {f.subject && <div className="font-medium text-sm mt-1">{f.subject}</div>}
              <div className="text-sm mt-1 whitespace-pre-wrap">{f.message}</div>
            </div>
          ))}
          {!feedback?.length && <div className="p-6 text-center text-sm text-muted-foreground">No feedback.</div>}
        </div>
      </Card>
    </div>
  );
}

/* ─────────────── Leads ─────────────── */
function LeadsPanel() {
  const { data: leads } = useQuery({
    queryKey: ["admin-buyer-leads"],
    queryFn: async () => (await supabase.from("buyer_requirements").select("*").order("created_at", { ascending: false }).limit(100)).data ?? [],
  });

  return (
    <Card>
      <div className="overflow-x-auto">
        <table className="w-full text-sm min-w-[720px]">
          <thead className="bg-secondary/50 text-left">
            <tr>
              <th className="p-3">When</th>
              <th className="p-3">Buyer</th>
              <th className="p-3">Requirement</th>
              <th className="p-3">Matched</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {(leads ?? []).map((l: any) => (
              <tr key={l.id}>
                <td className="p-3 whitespace-nowrap text-xs text-muted-foreground">{new Date(l.created_at).toLocaleString()}</td>
                <td className="p-3">
                  <div className="font-medium">{l.buyer_name}</div>
                  <div className="text-xs text-muted-foreground">{l.buyer_phone}{l.buyer_city ? ` · ${l.buyer_city}` : ""}</div>
                </td>
                <td className="p-3 max-w-md">
                  <div className="text-foreground">{l.raw_query}</div>
                  <div className="text-xs text-muted-foreground mt-1">
                    {l.normalized_product || "—"}
                    {l.quantity ? ` · ${l.quantity} units` : ""}
                    {l.max_price ? ` · ≤₹${l.max_price}` : ""}
                  </div>
                </td>
                <td className="p-3 text-center"><Badge variant="outline">{(l.matched_shop_ids ?? []).length}</Badge></td>
              </tr>
            ))}
            {!leads?.length && <tr><td colSpan={4} className="p-6 text-center text-muted-foreground">No leads yet.</td></tr>}
          </tbody>
        </table>
      </div>
    </Card>
  );
}
