import { createFileRoute } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { z } from "zod";
import { Mail, Send } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { SiteHeader } from "@/components/SiteHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";

export const Route = createFileRoute("/write-to-us")({
  head: () => ({
    meta: [
      { title: "Write to us — Kolkatabarabazar.in" },
      { name: "description", content: "Send us your feedback, complaints or suggestions. We'd love to hear from you." },
    ],
  }),
  component: WriteToUs,
});

const schema = z.object({
  name: z.string().trim().min(1, "Name required").max(100),
  email: z.string().trim().email("Invalid email").max(255),
  subject: z.string().trim().max(150).optional(),
  message: z.string().trim().min(5, "Message too short").max(2000),
});

const RECEIVER = "kolkatabarabazar@gmail.com";

function WriteToUs() {
  const [form, setForm] = useState({ name: "", email: "", subject: "", message: "" });
  const [busy, setBusy] = useState(false);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const parsed = schema.safeParse(form);
    if (!parsed.success) {
      toast.error(parsed.error.errors[0].message);
      return;
    }
    setBusy(true);
    try {
      const { error } = await supabase.from("feedback").insert({
        name: parsed.data.name,
        email: parsed.data.email,
        subject: parsed.data.subject || null,
        message: parsed.data.message,
      });
      if (error) throw error;
      toast.success("Thanks! Your message has been received.");
      // Also open mailto so it lands in inbox right away
      const body = encodeURIComponent(`From: ${parsed.data.name} <${parsed.data.email}>\n\n${parsed.data.message}`);
      const subject = encodeURIComponent(parsed.data.subject || "Feedback from Kolkatabarabazar.in");
      window.location.href = `mailto:${RECEIVER}?subject=${subject}&body=${body}`;
      setForm({ name: "", email: "", subject: "", message: "" });
    } catch (err: any) {
      toast.error(err.message ?? "Failed to send");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="min-h-screen">
      <SiteHeader />
      <main className="container mx-auto px-4 py-10 max-w-2xl">
        <h1 className="font-display text-4xl text-foreground">Write to us</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Complaints, feedback, partnership ideas — send a note and we'll reply to{" "}
          <a href={`mailto:${RECEIVER}`} className="text-primary underline">{RECEIVER}</a>.
        </p>

        <form onSubmit={submit} className="mt-6 space-y-4 rounded-xl border-2 border-border bg-card p-6">
          <div className="grid sm:grid-cols-2 gap-4">
            <div><Label>Your name</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required maxLength={100} /></div>
            <div><Label>Email</Label><Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} required maxLength={255} /></div>
          </div>
          <div><Label>Subject (optional)</Label><Input value={form.subject} onChange={(e) => setForm({ ...form, subject: e.target.value })} maxLength={150} /></div>
          <div><Label>Message</Label><Textarea rows={6} value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} required maxLength={2000} /></div>
          <Button type="submit" disabled={busy} className="w-full">
            {busy ? "Sending…" : <><Send className="h-4 w-4 mr-2" />Send message</>}
          </Button>
          <p className="text-xs text-muted-foreground flex items-center gap-1">
            <Mail className="h-3 w-3" /> Goes to {RECEIVER}
          </p>
        </form>
      </main>
    </div>
  );
}
