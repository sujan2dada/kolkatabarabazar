import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { SiteHeader } from "@/components/SiteHeader";
import { OpportunityCard, type OpportunityRow } from "@/components/OpportunityCard";
import { FadeIn } from "@/components/motion/FadeIn";

const CATEGORIES = ["all", "food", "tea", "fashion", "education", "pharmacy", "beauty", "fitness", "qsr"] as const;

export const Route = createFileRoute("/franchise-opportunities")({
  head: () => ({
    meta: [
      { title: "Franchise Opportunities in Kolkata & India — Food, Fashion, Tea, Pharmacy" },
      { name: "description", content: "Browse 100+ verified franchise opportunities across India. Food, tea, fashion, education, pharmacy & more. Low to high investment ranges. Apply online." },
      { property: "og:title", content: "Franchise Opportunities in India" },
      { property: "og:description", content: "Verified franchise opportunities across food, fashion, education, pharmacy and more." },
      { rel: "canonical", href: "/franchise-opportunities" },
    ],
  }),
  component: FranchisePage,
});

function FranchisePage() {
  const [cat, setCat] = useState<typeof CATEGORIES[number]>("all");
  const { data: opps } = useQuery({
    queryKey: ["opps", "franchise", cat],
    queryFn: async () => {
      let q = supabase.from("opportunities")
        .select("id, slug, title, type, category, investment_min, investment_max, margin_min, margin_max, territory, image_url, featured, brands(name, slug, logo_url, verified)")
        .eq("type", "franchise").eq("approved", true).order("featured", { ascending: false });
      if (cat !== "all") q = q.eq("category", cat);
      const { data } = await q;
      return (data ?? []) as unknown as OpportunityRow[];
    },
  });

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <section className="container mx-auto px-4 py-8">
        <FadeIn>
          <h1 className="font-display text-3xl sm:text-4xl">Franchise Opportunities in India</h1>
          <p className="text-muted-foreground mt-2 max-w-2xl">Start your own outlet with India's most trusted brands. Compare investment, margin and territory across food, fashion, education and more.</p>
        </FadeIn>
        <div className="mt-5 flex gap-2 overflow-x-auto pb-2">
          {CATEGORIES.map((c) => (
            <button key={c} onClick={() => setCat(c)}
              className={`shrink-0 rounded-full px-4 py-1.5 text-sm capitalize border transition ${cat === c ? "bg-primary text-primary-foreground border-primary" : "bg-card border-border hover:border-primary/40"}`}>
              {c === "qsr" ? "QSR" : c}
            </button>
          ))}
        </div>
        <div className="mt-6 grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {(opps ?? []).map((o) => <OpportunityCard key={o.id} o={o} />)}
        </div>
        {opps && opps.length === 0 && (
          <div className="py-20 text-center text-muted-foreground">No opportunities in this category yet.</div>
        )}
      </section>
    </div>
  );
}
