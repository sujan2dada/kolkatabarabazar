import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useRef, useState, type FormEvent, type DragEvent } from "react";
import { ArrowLeft, Plus, Trash2, RefreshCw, Upload, ImageIcon, X, Sparkles, Loader2, Pencil, IndianRupee } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { SiteHeader } from "@/components/SiteHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { slugify } from "@/lib/slug";
import { freshnessLabel } from "@/lib/format";
import { toast } from "sonner";
import {
  aiGenerateProductDescription,
  aiUpdateProductDescription,
  aiSuggestProductPrice,
} from "@/lib/product-ai.functions";
import { CategoryPicker } from "@/components/CategoryPicker";

async function uploadProductImage(file: File, shopId: string): Promise<string> {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) throw new Error("Please sign in to upload images.");
  const ext = file.name.split(".").pop()?.toLowerCase() ?? "jpg";
  // Storage RLS on shop-photos requires the first folder to equal auth.uid()
  const path = `${user.id}/products/${shopId}/${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
  const { error } = await supabase.storage.from("shop-photos").upload(path, file, { cacheControl: "3600", upsert: false, contentType: file.type });
  if (error) throw error;
  const { data } = supabase.storage.from("shop-photos").getPublicUrl(path);
  return data.publicUrl;
}

export const Route = createFileRoute("/_authenticated/shops/$id/products")({
  head: () => ({ meta: [{ title: "Manage products — Digital Barabazar" }] }),
  component: ManageProducts,
});

function ManageProducts() {
  const { id: shopId } = Route.useParams();
  const qc = useQueryClient();

  const { data: shop } = useQuery({
    queryKey: ["shop-meta", shopId],
    queryFn: async () => (await supabase.from("shops").select("name, slug").eq("id", shopId).maybeSingle()).data,
  });

  const { data: items } = useQuery({
    queryKey: ["my-shop-products", shopId],
    queryFn: async () => (await supabase
      .from("shop_products")
      .select("id, price, stock, moq, stock_status, updated_at, products(id, name, slug, image_url, description)")
      .eq("shop_id", shopId).order("created_at", { ascending: false })).data ?? [],
  });

  const { data: catalog } = useQuery({
    queryKey: ["product-catalog"],
    queryFn: async () => (await supabase.from("products").select("id, name").order("name")).data ?? [],
  });

  const genDesc = useServerFn(aiGenerateProductDescription);
  const updateDesc = useServerFn(aiUpdateProductDescription);
  const suggestPrice = useServerFn(aiSuggestProductPrice);

  const [productId, setProductId] = useState("");
  const [newProductName, setNewProductName] = useState("");
  const [categoryId, setCategoryId] = useState<string | null>(null);
  const [description, setDescription] = useState("");
  const [aiBusy, setAiBusy] = useState(false);
  const [rowAiBusy, setRowAiBusy] = useState<string | null>(null);
  const [priceAiBusy, setPriceAiBusy] = useState(false);
  const [rowPriceAiBusy, setRowPriceAiBusy] = useState<string | null>(null);
  const [editingRow, setEditingRow] = useState<string | null>(null);
  const [rowPrice, setRowPrice] = useState<Record<string, string>>({});
  const [price, setPrice] = useState("");
  const [stock, setStock] = useState("");
  const [moq, setMoq] = useState("1");
  const [stockStatus, setStockStatus] = useState<"available" | "low" | "out">("available");
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [dragActive, setDragActive] = useState(false);
  const [busy, setBusy] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleGenerateDescription = async () => {
    const name =
      newProductName.trim() ||
      catalog?.find((p: any) => p.id === productId)?.name ||
      "";
    if (!name) {
      toast.error("Pick a catalog product or type a new product name first");
      return;
    }
    setAiBusy(true);
    try {
      const out = await genDesc({ data: { name } });
      setDescription(out.description);
      toast.success("AI description generated");
    } catch (err: any) {
      toast.error(err.message ?? "Could not generate description");
    } finally {
      setAiBusy(false);
    }
  };

  const handleUpdateCatalogDesc = async (productId: string, overwrite: boolean) => {
    setRowAiBusy(productId);
    try {
      const out = await updateDesc({ data: { productId, overwrite } });
      toast.success(out.skipped ? "Existing description kept" : "Catalog description updated");
      qc.invalidateQueries({ queryKey: ["my-shop-products", shopId] });
    } catch (err: any) {
      toast.error(err.message ?? "Could not update");
    } finally {
      setRowAiBusy(null);
    }
  };

  const handleSuggestPriceForForm = async () => {
    const name =
      newProductName.trim() ||
      catalog?.find((p: any) => p.id === productId)?.name ||
      "";
    if (!name) {
      toast.error("Pick a catalog product or type a new product name first");
      return;
    }
    setPriceAiBusy(true);
    try {
      const out = await suggestPrice({ data: { name } });
      setPrice(String(out.suggested_price));
      if (out.suggested_moq && (!moq || moq === "1")) setMoq(String(out.suggested_moq));
      toast.success(`AI suggests ₹${out.suggested_price} (range ₹${out.min_price}–₹${out.max_price})`);
    } catch (err: any) {
      toast.error(err.message ?? "Could not suggest price");
    } finally {
      setPriceAiBusy(false);
    }
  };

  const handleSuggestPriceForRow = async (it: any) => {
    setRowPriceAiBusy(it.id);
    try {
      const out = await suggestPrice({ data: { name: it.products.name } });
      setRowPrice((m) => ({ ...m, [it.id]: String(out.suggested_price) }));
      setEditingRow(it.id);
      toast.success(`AI suggests ₹${out.suggested_price} — review and save`);
    } catch (err: any) {
      toast.error(err.message ?? "Could not suggest price");
    } finally {
      setRowPriceAiBusy(null);
    }
  };

  const saveRowPrice = async (it: any) => {
    const v = Number(rowPrice[it.id]);
    if (!v || v <= 0) { toast.error("Enter a valid price"); return; }
    if (v === Number(it.price)) { setEditingRow(null); return; }
    const { error } = await supabase.from("shop_products").update({ price: v }).eq("id", it.id);
    if (error) { toast.error(error.message); return; }
    toast.success("Price updated");
    setEditingRow(null);
    qc.invalidateQueries({ queryKey: ["my-shop-products", shopId] });
  };

  const pickFile = (file: File | null) => {
    if (!file) return;
    if (!file.type.startsWith("image/")) { toast.error("Please choose an image file"); return; }
    if (file.size > 5 * 1024 * 1024) { toast.error("Image must be under 5MB"); return; }
    setImageFile(file);
    setImagePreview(URL.createObjectURL(file));
  };

  const onDrop = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault(); setDragActive(false);
    pickFile(e.dataTransfer.files?.[0] ?? null);
  };

  const refreshAll = async () => {
    if (!items) return;
    const ids = items.map((i: any) => i.id);
    const { error } = await supabase.from("shop_products").update({ updated_at: new Date().toISOString() }).in("id", ids);
    if (error) toast.error(error.message); else toast.success("All listings refreshed");
    qc.invalidateQueries({ queryKey: ["my-shop-products", shopId] });
  };

  const add = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    try {
      let pid = productId;
      let uploadedUrl: string | null = null;
      if (imageFile) {
        uploadedUrl = await uploadProductImage(imageFile, shopId);
      }
      const desc = description.trim();
      if (!pid && newProductName.trim()) {
        const slug = slugify(newProductName);
        const { data: existing } = await supabase.from("products").select("id, image_url, description").eq("slug", slug).maybeSingle();
        if (existing) {
          pid = existing.id;
          if (uploadedUrl && !existing.image_url) {
            await supabase.from("products").update({ image_url: uploadedUrl }).eq("id", pid);
          }
          if (desc && !existing.description) {
            // policy blocks direct UPDATE for non-admins → use server fn (admin client)
            try { await updateDesc({ data: { productId: pid, overwrite: true } }); } catch {}
          }
        } else {
          const { data: created, error } = await supabase.from("products")
            .insert({ name: newProductName.trim(), slug, image_url: uploadedUrl, description: desc || null, category_id: categoryId })
            .select("id").single();
          if (error) throw error;
          pid = created!.id;
        }
      } else if (pid) {
        const { data: existing } = await supabase.from("products").select("image_url, description").eq("id", pid).maybeSingle();
        if (existing && uploadedUrl && !existing.image_url) {
          await supabase.from("products").update({ image_url: uploadedUrl }).eq("id", pid);
        }
        if (existing && desc && !existing.description) {
          try { await updateDesc({ data: { productId: pid, overwrite: true } }); } catch {}
        }
      }
      if (!pid) { toast.error("Pick a product or enter a new name"); return; }
      const { error } = await supabase.from("shop_products").insert({
        shop_id: shopId, product_id: pid,
        price: Number(price), stock: Number(stock) || 0,
        moq: Number(moq) || 1, stock_status: stockStatus,
      });
      if (error) throw error;
      toast.success("Product added");
      setProductId(""); setNewProductName(""); setCategoryId(null); setDescription(""); setPrice(""); setStock(""); setMoq("1"); setStockStatus("available");
      setImageFile(null); setImagePreview(null);
      if (fileInputRef.current) fileInputRef.current.value = "";
      qc.invalidateQueries({ queryKey: ["my-shop-products", shopId] });
      qc.invalidateQueries({ queryKey: ["product-catalog"] });
    } catch (err: any) {
      toast.error(err.message);
    } finally { setBusy(false); }
  };

  return (
    <div className="min-h-screen">
      <SiteHeader />
      <main className="container mx-auto px-4 py-8 max-w-5xl">
        <Link to="/dashboard" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-primary mb-4">
          <ArrowLeft className="h-4 w-4" />Dashboard
        </Link>
        <div className="flex items-center justify-between flex-wrap gap-3">
          <h1 className="font-display text-4xl text-foreground">{shop?.name ?? "Shop"} — Products</h1>
          <Button variant="outline" onClick={refreshAll}><RefreshCw className="h-4 w-4 mr-1" />Refresh all listings</Button>
        </div>

        <div className="grid lg:grid-cols-5 gap-6 mt-6">
          <form onSubmit={add} className="lg:col-span-2 rounded-xl border-2 border-border bg-card p-5 space-y-3 h-fit">
            <h2 className="font-display text-xl">Add product</h2>
            <div>
              <Label>From catalog</Label>
              <select value={productId} onChange={(e) => setProductId(e.target.value)} className="w-full h-10 rounded-md border border-input bg-background px-3 text-sm">
                <option value="">— Pick existing —</option>
                {catalog?.map((p: any) => <option key={p.id} value={p.id}>{p.name}</option>)}
              </select>
            </div>
            <div className="text-center text-xs text-muted-foreground">or</div>
            <div>
              <Label>New product name</Label>
              <Input value={newProductName} onChange={(e) => setNewProductName(e.target.value)} placeholder="e.g. Turmeric Powder 200g" />
            </div>
            <CategoryPicker value={categoryId} onChange={(leafId) => setCategoryId(leafId)} />

            <div className="grid grid-cols-2 gap-3">
              <div>
                <div className="flex items-center justify-between gap-2">
                  <Label>Price (₹)</Label>
                  <Button type="button" size="sm" variant="outline" onClick={handleSuggestPriceForForm} disabled={priceAiBusy} className="h-6 px-2 text-[10px]">
                    {priceAiBusy ? <Loader2 className="h-3 w-3 mr-1 animate-spin" /> : <Sparkles className="h-3 w-3 mr-1" />}
                    {priceAiBusy ? "…" : "AI suggest"}
                  </Button>
                </div>
                <Input type="number" step="0.01" min="0" value={price} onChange={(e) => setPrice(e.target.value)} required />
              </div>
              <div><Label>Stock</Label><Input type="number" min="0" value={stock} onChange={(e) => setStock(e.target.value)} /></div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>MOQ</Label><Input type="number" min="1" value={moq} onChange={(e) => setMoq(e.target.value)} /></div>
              <div>
                <Label>Status</Label>
                <select value={stockStatus} onChange={(e) => setStockStatus(e.target.value as any)} className="w-full h-10 rounded-md border border-input bg-background px-3 text-sm">
                  <option value="available">In stock</option>
                  <option value="low">Low stock</option>
                  <option value="out">Out of stock</option>
                </select>
              </div>
            </div>
            <div>
              <div className="flex items-center justify-between gap-2">
                <Label>SEO description</Label>
                <Button type="button" size="sm" variant="outline" onClick={handleGenerateDescription} disabled={aiBusy} className="h-7 px-2 text-xs">
                  {aiBusy ? <Loader2 className="h-3 w-3 mr-1 animate-spin" /> : <Sparkles className="h-3 w-3 mr-1" />}
                  {aiBusy ? "Generating…" : "Generate with AI"}
                </Button>
              </div>
              <Textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Short SEO-friendly description for buyers. Use AI to auto-fill."
                rows={5}
                className="mt-1"
              />
              <p className="mt-1 text-[10px] text-muted-foreground">AI writes a wholesale-focused description and keywords for Burrabazar buyers.</p>
            </div>
            <div>
              <Label>Product image</Label>
              <div
                onDragOver={(e) => { e.preventDefault(); setDragActive(true); }}
                onDragLeave={() => setDragActive(false)}
                onDrop={onDrop}
                onClick={() => fileInputRef.current?.click()}
                className={`mt-1 cursor-pointer rounded-md border-2 border-dashed p-3 text-center text-xs transition ${dragActive ? "border-primary bg-primary/5" : "border-input hover:border-primary/50"}`}
              >
                {imagePreview ? (
                  <div className="relative">
                    <img src={imagePreview} alt="Preview" className="mx-auto max-h-32 rounded" />
                    <button type="button" onClick={(e) => { e.stopPropagation(); setImageFile(null); setImagePreview(null); if (fileInputRef.current) fileInputRef.current.value = ""; }}
                      className="absolute top-1 right-1 rounded-full bg-background/90 p-1 shadow">
                      <X className="h-3 w-3" />
                    </button>
                  </div>
                ) : (
                  <div className="flex flex-col items-center gap-1 py-3 text-muted-foreground">
                    <Upload className="h-5 w-5" />
                    <span>Drag &amp; drop or click to upload</span>
                    <span className="text-[10px]">PNG/JPG up to 5MB</span>
                  </div>
                )}
                <input ref={fileInputRef} type="file" accept="image/*" className="hidden"
                  onChange={(e) => pickFile(e.target.files?.[0] ?? null)} />
              </div>
            </div>
            <Button type="submit" className="w-full" disabled={busy}><Plus className="h-4 w-4 mr-1" />{busy ? "Saving…" : "Add"}</Button>
          </form>

          <div className="lg:col-span-3 rounded-xl border-2 border-border bg-card p-5">
            <h2 className="font-display text-xl mb-3">Your listings ({items?.length ?? 0})</h2>
            {(!items || items.length === 0) ? (
              <p className="text-sm text-muted-foreground">No products listed yet.</p>
            ) : (
              <ul className="divide-y divide-border">
                {items.map((it: any) => (
                  <li key={it.id} className="py-3 space-y-2">
                    <div className="flex items-center justify-between gap-3">
                      <div className="flex items-center gap-3 min-w-0">
                        {it.products.image_url ? (
                          <img src={it.products.image_url} alt={it.products.name} className="h-12 w-12 rounded-md object-cover border border-border" />
                        ) : (
                          <div className="h-12 w-12 rounded-md bg-muted flex items-center justify-center text-muted-foreground">
                            <ImageIcon className="h-5 w-5" />
                          </div>
                        )}
                        <div className="min-w-0">
                          <div className="font-medium truncate">{it.products.name}</div>
                          <div className="text-xs text-muted-foreground">{freshnessLabel(it.updated_at)}</div>
                        </div>
                      </div>
                      <div className="flex items-center gap-1">
                        <Button size="sm" variant="outline" className="h-8 px-2 text-xs" onClick={() => {
                          setEditingRow(editingRow === it.id ? null : it.id);
                          setRowPrice((m) => ({ ...m, [it.id]: m[it.id] ?? String(it.price) }));
                        }}>
                          <Pencil className="h-3.5 w-3.5 mr-1" />{editingRow === it.id ? "Close" : "Edit"}
                        </Button>
                        <Button size="sm" variant="ghost" onClick={async () => {
                          if (!confirm("Remove this listing?")) return;
                          await supabase.from("shop_products").delete().eq("id", it.id);
                          qc.invalidateQueries({ queryKey: ["my-shop-products", shopId] });
                        }}><Trash2 className="h-4 w-4" /></Button>
                      </div>
                    </div>
                    <div className="grid grid-cols-3 gap-2">
                      <div>
                        <div className="flex items-center justify-between gap-1">
                          <Label className="text-xs flex items-center gap-1"><IndianRupee className="h-3 w-3" />Price</Label>
                          <Button type="button" size="sm" variant="ghost" className="h-5 px-1 text-[10px]"
                            disabled={rowPriceAiBusy === it.id}
                            onClick={() => handleSuggestPriceForRow(it)}>
                            {rowPriceAiBusy === it.id
                              ? <Loader2 className="h-3 w-3 animate-spin" />
                              : <><Sparkles className="h-3 w-3 mr-0.5" />AI</>}
                          </Button>
                        </div>
                        <div className="flex gap-1">
                          <Input type="number" step="0.01" min="0"
                            value={rowPrice[it.id] ?? String(it.price)}
                            onChange={(e) => setRowPrice((m) => ({ ...m, [it.id]: e.target.value }))}
                            onBlur={() => { if (editingRow !== it.id) saveRowPrice(it); }} />
                          {editingRow === it.id && (
                            <Button type="button" size="sm" className="h-9 px-2 text-xs" onClick={() => saveRowPrice(it)}>Save</Button>
                          )}
                        </div>
                      </div>
                      <div>
                        <Label className="text-xs">MOQ</Label>
                        <Input type="number" min="1" defaultValue={it.moq}
                          onBlur={async (e) => {
                            const v = Number(e.target.value) || 1;
                            if (v === it.moq) return;
                            await supabase.from("shop_products").update({ moq: v }).eq("id", it.id);
                            qc.invalidateQueries({ queryKey: ["my-shop-products", shopId] });
                          }} />
                      </div>
                      <div>
                        <Label className="text-xs">Status</Label>
                        <select defaultValue={it.stock_status}
                          onChange={async (e) => {
                            await supabase.from("shop_products").update({ stock_status: e.target.value as "available" | "low" | "out" }).eq("id", it.id);
                            qc.invalidateQueries({ queryKey: ["my-shop-products", shopId] });
                          }}
                          className="w-full h-9 rounded-md border border-input bg-background px-2 text-xs">
                          <option value="available">In stock</option>
                          <option value="low">Low stock</option>
                          <option value="out">Out of stock</option>
                        </select>
                      </div>
                    </div>
                    <div className="rounded-md bg-muted/40 p-2">
                      <div className="flex items-center justify-between gap-2 mb-1">
                        <span className="text-[11px] font-medium text-muted-foreground uppercase tracking-wide">SEO description</span>
                        <Button
                          type="button"
                          size="sm"
                          variant="ghost"
                          className="h-6 px-2 text-[11px]"
                          disabled={rowAiBusy === it.products.id}
                          onClick={() => handleUpdateCatalogDesc(it.products.id, !!it.products.description)}
                        >
                          {rowAiBusy === it.products.id
                            ? <Loader2 className="h-3 w-3 mr-1 animate-spin" />
                            : <Sparkles className="h-3 w-3 mr-1" />}
                          {it.products.description ? "Regenerate" : "Auto-fill with AI"}
                        </Button>
                      </div>
                      <p className="text-xs text-foreground/80 line-clamp-3">
                        {it.products.description || <span className="italic text-muted-foreground">No description yet — let AI write one for SEO.</span>}
                      </p>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
