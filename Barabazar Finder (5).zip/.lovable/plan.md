# Business Opportunity Marketplace — Phased Plan

Big scope. I'll ship in 3 phases so we can review between. Approve to start **Phase 1**.

## Phase 1 — Core opportunity directory + lead capture (this turn)

**Database**
- New enum `opportunity_type`: `franchise | distributor | dealer | super_stockist | cnf_agent | wholesale_supplier | brand_partnership`
- New `brands` table: `id, slug, name, logo_url, category, description, verified, featured, created_at`
- New `opportunities` table:
  `id, brand_id, type (opportunity_type), title, slug, category (food/fashion/fmcg/electrical/hardware/stationery/packaging/education/pharmacy/...), investment_min, investment_max, margin_min, margin_max, territory, area_required_sqft, experience_required, description, highlights (text[]), approved, featured, created_at`
- New `opportunity_leads` table:
  `id, opportunity_id, brand_id, name, city, phone, email, investment_capacity, business_experience, message, status (new/contacted/converted/rejected), created_at`
  - Public INSERT, only brand owner / admin can SELECT.

All tables get GRANTs + RLS. Brand owners join via existing `user_roles` admin or a new `brand_owners` map (kept simple this phase: admin-only create; sellers later).

**Routes**
- `/opportunities` — landing hub with 4 tiles (Franchise / Distributor / Dealer / Wholesale Supplier).
- `/franchise-opportunities` — filter by category (food, tea, fashion, education, pharmacy), investment range slider, search.
- `/distributor-opportunities` — filter by industry (FMCG, electrical, hardware, stationery, packaging, consumer goods).
- `/dealer-opportunities` — "Become a Dealer" page template with apply form.
- `/brands` — directory of brands.
- `/brand/$slug` — brand profile with all their opportunities + inquiry form.
- `/opportunity/$slug` — single opportunity detail: investment, margin, territory, highlights, **Apply / Submit Inquiry** form + WhatsApp button.

**Components**
- `OpportunityCard.tsx` — image, brand, investment range, margin, territory chip.
- `OpportunityFilters.tsx` — type, category, investment range, territory.
- `LeadInquiryForm.tsx` — Zod-validated (name, city, phone, email, investment, experience, message). Inserts into `opportunity_leads` + opens prefilled WhatsApp to brand or central number.
- `BusinessOpportunityHub.tsx` — homepage section linking to the 4 verticals.

**Homepage**
- Add a new "Business Opportunities" section above the footer with the 4 tiles + CTAs.
- Add nav link in `SiteHeader` and `MobileBottomNav` (replace something less-used or add to overflow).

**SEO**
- Per-route `head()` with high-intent titles: "Franchise Opportunities in Kolkata & India", "Distributor Wanted — FMCG, Electrical, Hardware", "Become a Dealer", etc.
- JSON-LD `Organization` + `Offer` on brand and opportunity pages.

## Phase 2 — Seller/brand dashboard + lead inbox
- Brand onboarding form; brand owner role; brand can post & manage their opportunities.
- Lead inbox for brands (paid feature tie-in with Growth/Enterprise plans).
- Lead export CSV.
- Featured brand slots (homepage carousel) — manual flag for now.

## Phase 3 — Monetization + content
- Pay-per-lead unlocking (mask phone until brand has credits/subscription).
- Featured brand subscription billing (tie into existing pricing tiers).
- `/business-news` blog (markdown-driven).
- Verified-brand badge workflow (GST + cheque copy upload, admin approval).

---

Approve **Phase 1** to start, or tell me to reorder/trim (e.g. "skip Wholesale Supplier route, it duplicates existing search").

